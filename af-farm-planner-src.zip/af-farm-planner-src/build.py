import os
BASE=os.path.dirname(os.path.abspath(__file__))
import base64,json,io
from PIL import Image
t=open(os.path.join(BASE,'template.html')).read()
d=json.load(open(os.path.join(BASE,'data/farm_data.json'))); d.update(json.load(open(os.path.join(BASE,'data/game_graph2.json'))))
for k in ('ss','ls','wp'): d.pop(k,None)
icons={}
import os
have=sorted(int(f.split('.')[0]) for f in os.listdir(os.path.join(BASE,'icons')) if f.split('.')[0].isdigit())
iconOf={}
for tid in have:
    u=d['ut'].get(str(tid))
    if u: iconOf.setdefault(u['n'],{})[str(u['f'])]=tid
d['iconOf']=iconOf
for tid in sorted({u[0] for a in d['arm'] for u in a['u']}|set(have)):
    im=Image.open(os.path.join(BASE,'icons',f'{tid}.png')).convert('RGBA'); im.thumbnail((60,68),Image.LANCZOS)
    b=io.BytesIO(); im.save(b,'WEBP',quality=82,method=6); icons[tid]='data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode()
d['icons']=icons
full=json.load(open(os.path.join(BASE,'data/dtg_cow_units.json')))['unitTypes']
for k,u in d['ut'].items():
    fu=full.get(k,{})
    uf=fu.get('unitFeatures') or {}
    u['uf']={kk:uf[kk] for kk in ('0','1','2','4','5','7') if kk in uf}
    u['dt']=fu.get('damageTypes') or {}
    u['vw']=fu.get('viewWidths') or {}   # air view width = patrol radius
    u['rc']=uf.get('70',0)   # CUSTOM_REINFORCEMENT_COST: War Bonds weight of one unit per heal
    u['bt']=fu.get('buildTime',0); u['cs']=fu.get('costs') or {}; u['rq']=[int(x) for x in (fu.get('requiredUpgrades') or {})]; u['sf']=uf.get('71',1)
prem=json.load(open(os.path.join(BASE,'data/premium_state.json')))['result']['offers']
# buildings (all levels) and the War Bonds speed-up price curves
_all=json.load(open(os.path.join(BASE,'data/dtg_cow_units.json'))); _up=_all['upgrades']; _cb=_all['completeGameData']['buildings']
bld=[]
for name,b in _cb.items():
    if name=='Capitol': continue
    ds=b['description']; where='urban' if 'only be constructed in urban' in ds else 'rural' if 'only be constructed in rural' in ds else 'all'
    coast='coastal' in ds.split('constructed in')[-1]
    lv=[]
    for L in sorted(b['allLevels'],key=lambda x:x['level']):
        u=_up[str(L['id'])]; f=u['features']
        lv.append({'id':L['id'],'bt':u['buildTime'],'cs':u['costs'],'fac':f.get('3',0),'sf':f.get('42',1)})
    bld.append({'n':name,'w':where,'c':coast,'lv':lv})
bld.sort(key=lambda x:x['n'])
d['bld']=bld
def _pf(name):
    o=next(o for o in prem.values() if o.get('resourceId')==22 and any(p.get('name')==name for p in o.get('pm',{}).values()))
    return {'d':o['d'],'pf':sorted([[float(k),v] for k,v in o['pf'].items()])}
d['spd']={'u':_pf('Production speedup'),'b':_pf('Building speedup'),'r':_pf('Speedup research')}
# research: per unit, per level, per doctrine (ids come in blocks: base, Axis, Allies, Comintern, Pan-Asian)
rs={}
for name,x in _all['completeGameData']['research'].items():
    tiers={}
    for tt in x['allTiers']: tiers.setdefault(tt['tier'],[]).append(tt)
    out=[]
    for tier in sorted(tiers):
        v=sorted(tiers[tier],key=lambda q:q['id']); out.append({'t':tier,'v':[{'bt':q['buildTime'],'cs':q['costs'],'day':q.get('dayAvailable',1)} for q in v]})
    rs[name]=out
d['rs']=rs
d['healPrice']=next(o['pr'] for o in prem.values() if '22663' in o.get('pm',{}))   # soft currency Army Reinforcement offer
# province shapes (exact game borders) as SVG paths in page px, same order as d['prov']
import struct
geo=json.load(open(os.path.join(BASE,'data/map_geometry.json'))); GA=geo['scale_to_full_image']
def tp(x,y): return (0.6*(x*GA[0][0]+y*GA[1][0]+GA[2][0]), 0.6*(x*GA[0][1]+y*GA[1][1]+GA[2][1]))
polys=[]
for pr in d['prov']:
    g=geo['provinces'].get(pr['n']); path=''
    if g and g.get('border'):
        b=base64.b64decode(g['border']); v=struct.unpack('>%dH'%(len(b)//2),b)
        pts=[tp(v[i],v[i+1]) for i in range(0,len(v)-1,2)]
        path='M'+'L'.join(f'{x:.1f} {y:.1f}' for x,y in pts)+'Z'
    polys.append(path)
d['poly']=polys
# crisp borders: province borders inside a country, country borders (different start owners) and coastlines, chained into polylines
own={pr['n']:pr['o'] for pr in d['prov']}
seg={}
for nm,g in geo['provinces'].items():
    b=base64.b64decode(g['border']); v=struct.unpack('>%dH'%(len(b)//2),b); pts=[(v[i],v[i+1]) for i in range(0,len(v)-1,2)]
    for i in range(len(pts)):
        a,c=pts[i],pts[(i+1)%len(pts)]
        if a==c: continue
        seg.setdefault((a,c) if a<c else (c,a),[]).append(nm)
cls={'prov':[], 'nat':[], 'coast':[]}
for k,ns in seg.items():
    if len(ns)==1: cls['coast'].append(k)
    elif own.get(ns[0])==own.get(ns[1]): cls['prov'].append(k)
    else: cls['nat'].append(k)
def chain(segs):
    adj={}
    for a,c in segs: adj.setdefault(a,[]).append(c); adj.setdefault(c,[]).append(a)
    used=set(); out=[]
    def take(a,c): used.add((a,c) if a<c else (c,a))
    def free(a,c): return ((a,c) if a<c else (c,a)) not in used
    for a,c in segs:
        if not free(a,c): continue
        line=[a,c]; take(a,c)
        for end in (1,0):
            while True:
                cur=line[-1] if end else line[0]; nxt=next((x for x in adj[cur] if free(cur,x)),None)
                if nxt is None: break
                take(cur,nxt)
                if end: line.append(nxt)
                else: line.insert(0,nxt)
        out.append('M'+'L'.join('%.1f %.1f'%tp(*q) for q in line))
    return ''.join(out)
d['borders']={k:chain(v) for k,v in cls.items()}
ds=json.dumps(d,separators=(',',':'),ensure_ascii=False)
b='data:image/jpeg;base64,'+base64.b64encode(open(os.path.join(BASE,'data/base_live.jpg'),'rb').read()).decode()
l='data:image/png;base64,'+base64.b64encode(open(os.path.join(BASE,'data/logo.png'),'rb').read()).decode()
_C=os.path.join(BASE,'calc')+'/'
_js=lambda f: open(_C+f).read().replace('</script','<\\/script')
t=t.replace('__CALCCSS__',open(_C+'calc_scoped.css').read()).replace('__REACT__',_js('react.production.min.js')).replace('__REACTDOM__',_js('react-dom.production.min.js')).replace('__CALCJS__',_js('calc_app.js'))
open(os.path.join(BASE,'farm_planner.html'),'w').write(t.replace('__BASE__',b).replace('__LOGO__',l).replace('__WB__',open(os.path.join(BASE,'wb_icon.txt')).read()).replace('__DATA__',ds.replace('</','<\\/')))
print('icons',len(icons),sum(len(v) for v in icons.values())//1024,'KB')
