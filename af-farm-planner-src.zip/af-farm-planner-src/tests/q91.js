const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800);
 const D=await p.evaluate(()=>{ const D=JSON.parse(document.getElementById('data').textContent); const i=D.arm.findIndex(a=>D.nat[a.o].n==='Russian Empire'&&a.u.length==2); return {i,o:D.arm[i].o,p:D.arm[i].p, pi:D.prov.findIndex(x=>Math.hypot(x.p[0]-D.arm[i].p[0],x.p[1]-D.arm[i].p[1])<3)}; });
 console.log(D);
 // old situation: army route + separately placed AC in the same province
 await p.evaluate(D=>{ localStorage.clear(); localStorage.setItem('afp_routes',JSON.stringify([{id:1,name:'Russian Empire',color:'#38bdf8',wps:[D.pi],doc:4,me:D.o,unit:'Infantry',lvl:1,tr:1,stack:[[8507,1],[8559,1]],army:D.i,sh:0},{id:2,name:'AC',color:'#f0b429',wps:[D.pi],doc:4,me:D.o,unit:'Armored Car',lvl:1,tr:1,cnt:1,sh:0}])); },D);
 await p.reload(); await p.waitForTimeout(1000);
 const R=async l=>console.log(l, JSON.stringify(await p.evaluate(()=>JSON.parse(localStorage.getItem('afp_routes')).map(r=>[r.name,r.stack||r.cnt,r.split||false]))));
 await R('after load:');
 // place another AC there via Place unit
 const at=async(q)=>p.evaluate(q=>{const m=document.getElementById('stage').style.transform.match(/translate\(([-\d.]+)px, ([-\d.]+)px\) scale\(([-\d.]+)\)/); const r=document.getElementById('map').getBoundingClientRect(); return [r.left+ +m[1]+q[0]*m[3], r.top+ +m[2]+q[1]*m[3]];},q);
 await p.evaluate(()=>{ const s=document.getElementById('me'); }); await p.selectOption('#me', String(D.o)); await p.selectOption('#unit','Armored Car');
 await p.click('#placeUnit'); const pp=await p.evaluate(pi=>JSON.parse(document.getElementById('data').textContent).prov[pi].p,D.pi); const [x,y]=await at(pp); await p.mouse.click(x,y); await p.waitForTimeout(400); await R('after place:');
 // split and check that it stays split after reload
 await p.click('#rbar [data-b="split"]'); await p.waitForTimeout(200); await p.click('#pop [data-sp="0"]'); await p.click('#spOk'); await p.waitForTimeout(300); await p.keyboard.press('Escape'); await R('after split:');
 await p.reload(); await p.waitForTimeout(1000); await R('after reload:');
 console.log(errs); await b.close(); })();
