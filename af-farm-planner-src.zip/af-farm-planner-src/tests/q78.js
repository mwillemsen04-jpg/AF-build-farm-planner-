const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(1000);
 await p.evaluate(()=>localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
 // pick Hamburg (index 0) via click on its centre
 const scr=async q=>p.evaluate(q=>{const m=document.getElementById('stage').style.transform.match(/translate\(([-\d.]+)px, ([-\d.]+)px\) scale\(([-\d.]+)\)/); const r=document.getElementById('map').getBoundingClientRect(); return [r.left+ +m[1]+q[0]*m[3], r.top+ +m[2]+q[1]*m[3]];},q);
 const ham=await p.evaluate(()=>JSON.parse(document.getElementById('data').textContent).prov[0].p);
 await p.click('#prodPick'); const [x,y]=await scr(ham); await p.mouse.click(x,y); await p.waitForTimeout(300);
 const txt=async()=>p.evaluate(()=>document.getElementById('prod').innerText.replace(/\n+/g,' | '));
 console.log('picked:',(await txt()).slice(0,300));
 await p.selectOption('[data-lv="Barracks"]','1'); await p.click('[data-bld="Barracks"]'); await p.waitForTimeout(100);
 await p.selectOption('#pUnit','Infantry'); await p.fill('#pCnt','3'); await p.click('#pAdd'); await p.waitForTimeout(100);
 await p.selectOption('#pUnit','Interceptor'); await p.click('#pAdd'); await p.waitForTimeout(100);
 await p.click('[data-bld="Aircraft Factory"]'); await p.waitForTimeout(100);
 console.log('queue:',await txt());
 // WB on infantry
 const wbs=await p.$$('[data-wb]'); await p.selectOption('[data-wb="1"]','-1'); await p.waitForTimeout(100);
 {const t=await txt(); const i=t.indexOf('Infantry L1'); console.log('wb:',t.slice(i,i+200));}
 await p.click('[data-map="1"]'); await p.waitForTimeout(300);
 console.log('route:',await p.evaluate(()=>{ const r=JSON.parse(localStorage.getItem('afp_routes'))[0]; return [r.name,r.sh,r.born,r.cnt]; }));
 await p.selectOption('[data-wb="1"]',''); await p.waitForTimeout(300);
 console.log('route after wb off:',await p.evaluate(()=>{ const r=JSON.parse(localStorage.getItem('afp_routes'))[0]; return [r.name,r.sh,r.born]; }));
 await p.evaluate(()=>__farmT.set(1)); await p.waitForTimeout(300); console.log('movers t=1', await p.evaluate(()=>__farmSim.dbg().mov.length));
 await p.evaluate(()=>__farmT.set(20)); await p.waitForTimeout(300); console.log('movers t=20', await p.evaluate(()=>__farmSim.dbg().mov.length));
 console.log(errs); await b.close(); })();
