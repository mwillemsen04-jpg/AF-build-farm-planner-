const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800); await p.evaluate(()=>localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
 await p.evaluate(()=>AFBridge.save([{id:1,name:'Spain',doctrine:'Axis',cities:[{name:'Madrid',res:'metal',buildings:[]}],buildings:[{id:5,name:'Barracks',lvl:3,qty:1,type:'building',label:'Madrid: Barracks Lv1→3',cityName:'Madrid',day:1,hour:0}],items:[{id:7,label:'Infantry Lv1',qty:2,type:'production',city:'Madrid',day:2,hour:0,cost:{}}]}]));
 await p.waitForTimeout(600);
 console.log(await p.evaluate(()=>[AFBridge.info(5),AFBridge.info(7)]));
 console.log(await p.evaluate(()=>JSON.parse(localStorage.getItem('afp_routes')).map(r=>[r.name,r.cnt,r.born])));
 // remove the unit in calculator -> route disappears
 await p.evaluate(()=>AFBridge.save([{id:1,name:'Spain',doctrine:'Axis',cities:[],buildings:[],items:[]}])); await p.waitForTimeout(600);
 console.log('after remove', await p.evaluate(()=>JSON.parse(localStorage.getItem('afp_routes')).length), await p.evaluate(()=>JSON.stringify(JSON.parse(localStorage.getItem('afp_settings')).prod||{}).length));
 console.log(errs); await b.close(); })();
