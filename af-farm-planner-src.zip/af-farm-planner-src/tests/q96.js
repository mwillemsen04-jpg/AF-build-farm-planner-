const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800);
 await p.evaluate(()=>{ localStorage.clear(); localStorage.setItem('afp_settings',JSON.stringify({calc:[{id:1,name:'Spain',doctrine:'Axis',tab:'cities',cities:[{name:'Madrid',res:'metal',warbond:1,buildings:[{id:5,name:'Barracks',lvl:2,qty:1,type:'building',label:'Madrid: Barracks Lv1→2',cityName:'Madrid',cost:{money:8400,food:5250,metal:3150}}]},{name:'Sevilla',res:'food',buildings:[]}],buildings:[{id:5,name:'Barracks',lvl:2,qty:1,type:'building',label:'Madrid: Barracks Lv1→2',cityName:'Madrid',cost:{money:8400,food:5250,metal:3150}}],items:[{id:7,label:'Infantry Lv1',qty:3,type:'production',city:'Madrid',day:1,hour:0,cost:{money:2640,food:3630,metal:840,manpower:3150}},{id:8,researchId:'INF2',label:'Research: Infantry 2',qty:1,type:'research',cost:{money:2850,food:2050,metal:450}}],capitals:[],selDay:0}]})); });
 for(const tab of ['cities','production','research']){
  await p.evaluate(tab=>{ const s=JSON.parse(localStorage.getItem('afp_settings')); s.calc[0].tab=tab; localStorage.setItem('afp_settings',JSON.stringify(s)); sessionStorage.setItem('afp_view','calc'); },tab);
  await p.reload(); await p.waitForTimeout(1500);
  const over=await p.evaluate(()=>{ const W=document.documentElement.clientWidth; const out=[]; document.querySelectorAll('#calcView *').forEach(e=>{ const r=e.getBoundingClientRect(); if(r.width>0&&(r.right>W+1)) out.push((e.className&&e.className.baseVal===undefined?e.className:'')+'|'+e.tagName+'|'+Math.round(r.left)+'-'+Math.round(r.right)+'|'+(e.textContent||'').slice(0,25)); }); return [W,document.documentElement.scrollWidth,document.getElementById('calcView').scrollWidth,out.slice(0,12)]; });
  console.log(tab, JSON.stringify(over,null,0));
  await p.screenshot({path:`/tmp/claude-0/m_${tab}.png`,fullPage:false});
 }
 console.log(errs); await b.close(); })();
