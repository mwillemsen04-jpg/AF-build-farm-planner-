const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.setContent('<!doctype html><meta charset="utf-8"><style>[hidden]{display:none!important}</style>'+require('fs').readFileSync('farm_planner.html','utf8'),{waitUntil:'load'}); await p.waitForTimeout(400);
 await p.selectOption('#doc','2'); await p.selectOption('#unit','Tactical Bomber'); await p.selectOption('#lvl','1'); await p.fill('#cnt','3'); await p.dispatchEvent('#cnt','change');
 for(let i=0;i<2;i++) await p.click('#zin');
 const pos=async n=>p.evaluate(n=>{const D=JSON.parse(document.getElementById('data').textContent); const m=document.getElementById('stage').style.transform.match(/translate\(([-\d.]+)px, ([-\d.]+)px\) scale\(([-\d.]+)\)/); const r=document.getElementById('map').getBoundingClientRect(); const pp=D.prov.find(x=>x.n===n).p; return [r.left+ +m[1]+pp[0]*m[3], r.top+ +m[2]+pp[1]*m[3]];},n);
 let [x,y]=await pos('Toulouse'); const c=await p.evaluate(()=>{const b=document.getElementById('map').getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]});
 await p.mouse.move(c[0],c[1]); await p.mouse.down(); await p.mouse.move(c[0]+(c[0]-x),c[1]+(c[1]-y),{steps:8}); await p.mouse.up();
 await p.click('#newRoute'); [x,y]=await pos('Toulouse'); await p.mouse.click(x,y); await p.keyboard.press('Enter');
 await p.click('#rbar [data-b="pat"]'); [x,y]=await pos('Girona'); await p.mouse.click(x,y); await p.waitForTimeout(200);
 await p.click('.route.act [data-nextpat]'); [x,y]=await pos('Barcelona'); await p.mouse.click(x,y); await p.waitForTimeout(300);
 console.log((await p.evaluate(()=>document.querySelector('.route.act .pat').innerText)).replace(/\n/g,' | '));
 await p.fill('.route.act [data-stay="1"]','30'); await p.dispatchEvent('.route.act [data-stay="1"]','change'); await p.waitForTimeout(300);
 console.log('---30min:', (await p.evaluate(()=>document.querySelector('.route.act .pat').innerText)).replace(/\n/g,' | ').slice(0,700));
 const sh=await p.evaluate(()=>window.__farmSim.active().sh);
 for(const dt of [0.3,1.0,1.3,2]){ await p.evaluate(s=>window.__farmT.set(s),sh+dt); await p.waitForTimeout(200); console.log(dt, await p.evaluate(()=>{const m=[...document.querySelectorAll('#gMov .mv')].pop(); return m.getAttribute('transform').slice(0,40)+' '+m.textContent+' corr:'+document.querySelectorAll('.corr').length;})); }
 console.log('wedge', await p.evaluate(()=>document.querySelector('.corr').getAttribute('d').slice(0,40))); await p.screenshot({path:'/tmp/claude-0/multi.png'}); console.log(errs); await b.close(); })();
