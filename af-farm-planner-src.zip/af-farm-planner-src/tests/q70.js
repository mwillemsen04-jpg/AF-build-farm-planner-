const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const ctx=await b.newContext({viewport:{width:1400,height:900}});
 // fake db + user in the page, shared across pages via a node-side store
 const MEM={}; await ctx.exposeFunction('__dbop',(op,path,body)=>{ if(op==='set'){MEM[path]=body;return null;} if(op==='get') return MEM[path]||null; if(op==='del'){delete MEM[path];return null;} if(op==='list'){ return Object.keys(MEM).filter(k=>k.startsWith(path+'/')&&!k.slice(path.length+1).includes('/')).map(k=>({id:k.slice(path.length+1),d:MEM[k]})); } });
 const fake=()=>{ if(!window.__useDb) return; const doc=path=>({get:async()=>{const d=await __dbop('get',path); return {exists:!!d,data:()=>d,id:path.split('/').pop()};},set:async x=>__dbop('set',path,x),delete:async()=>__dbop('del',path)});
   window.claude={use:async n=>n==='db'?{doc,collection:path=>({get:async()=>{const l=await __dbop('list',path); return {docs:l.map(o=>({id:o.id,exists:true,data:()=>o.d}))};}})}:n==='user'?{id:async()=>'u1'}:null}; };
 const open=async(useDb)=>{ const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); await p.addInitScript(`window.__useDb=${useDb}`); await p.addInitScript(fake); await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800); p.errs=errs; return p; };
 let p=await open(true);
 const place=async()=>{ await p.click('#placeUnit'); const box=await p.$eval('#map',e=>{const r=e.getBoundingClientRect(); return [r.left+r.width/2,r.top+r.height/2];}); await p.mouse.click(box[0],box[1]); await p.waitForTimeout(200); await p.keyboard.press('Escape'); };
 await place(); await p.fill('#farmName','Spain farm'); await p.dispatchEvent('#farmName','change'); await p.waitForTimeout(2000);
 const st=async l=>console.log(l, JSON.stringify(await p.evaluate(()=>({n:document.querySelectorAll('#routes .route').length, name:document.getElementById('farmName').value, st:document.getElementById('farmSt').textContent, list:[...document.querySelectorAll('#farmList option')].map(o=>o.textContent)}))));
 await st('after place:');
 await p.click('#farmNew'); await p.waitForTimeout(500); await st('after new:');
 await place(); await place(); await p.waitForTimeout(2000); await st('new farm 2 units:');
 await p.selectOption('#farmList',{label:'Spain farm'}); await p.click('#farmLoad'); await p.waitForTimeout(500); await st('open spain:');
 console.log('db keys',Object.keys(MEM));
 // other device: fresh browser storage, same account
 const ctx2=ctx; await p.evaluate(()=>localStorage.clear()); await p.close(); p=await open(true); await p.waitForTimeout(800); await st('fresh device:');
 await p.click('#farmCopy'); await p.waitForTimeout(500); await st('copy:');
 console.log('errs',p.errs); await b.close(); })();
