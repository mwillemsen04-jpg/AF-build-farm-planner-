const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800);
 // realistic farm: 12 routes with 3-5 waypoints, teams, calculator with production
 await p.evaluate(()=>{ localStorage.clear(); const D=JSON.parse(document.getElementById('data').textContent); const P=D.prov; const pick=n=>P.findIndex(x=>x.n===n);
   const R=[]; const trips=[['Paris','Cologne','Berlin'],['Madrid','Bordeaux','Paris'],['Rome','Milan','Munich'],['Warsaw','Kiev','Kharkov'],['London','Birmingham','Manchester'],['Hamburg','Berlin','Warsaw'],['Vienna','Budapest','Belgrad'],['Istanbul','Ankara'],['Oslo','Stockholm'],['Algiers','Tunis'],['Cairo','Alexandria'],['Moscow','Smolensk','Minsk']];
   trips.forEach((t,k)=>{ const w=t.map(pick).filter(x=>x>=0); if(w.length<2) return; R.push({id:100+k,name:'R'+k,color:'#f0b429',wps:w,doc:1,me:P[w[0]].o,unit:'Infantry',lvl:1,tr:1,cnt:3,sh:k*2}); });
   localStorage.setItem('afp_routes',JSON.stringify(R));
   localStorage.setItem('afp_settings',JSON.stringify({teamMe:['1','2','','',''],teamEn:['3','4','','',''],calc:[{id:1,name:'Spain',doctrine:'Axis',cities:[{name:'Madrid',res:'metal',buildings:[]}],buildings:[{id:5,name:'Barracks',lvl:3,qty:1,type:'building',label:'x',cityName:'Madrid',day:1}],items:[1,2,3,4,5,6].map(i=>({id:10+i,label:'Infantry Lv1',qty:2,type:'production',city:'Madrid',day:1+(i%3),hour:i,cost:{}}))}]})); });
 await p.reload(); await p.waitForTimeout(2500);
 const t=await p.evaluate(()=>{ const T=f=>{ const a=performance.now(); f(); return Math.round(performance.now()-a); }; const r=__farmSim.active; 
   return { renderRoutes: T(()=>window.__farmT&&document.querySelector('#newRoute')&&0), }; });
 const c=await p.context().newCDPSession(p); await c.send('Performance.enable');
 const m=async()=>{ const r=(await c.send('Performance.getMetrics')).metrics; const o={}; r.forEach(x=>o[x.name]=x.value); return o; };
 const diff=(a,b)=>['TaskDuration','ScriptDuration','LayoutDuration','RecalcStyleDuration'].map(k=>k.replace('Duration','')+'='+Math.round((b[k]-a[k])*1000)).join(' ');
 let a=await m(); await p.waitForTimeout(3000); console.log('idle 3s:',diff(a,await m()));
 // click a route card (select) 5 times
 a=await m(); for(let i=0;i<5;i++){ await p.click('#routes .route >> nth='+i); await p.waitForTimeout(50);} console.log('5 selects:',diff(a,await m()));
 a=await m(); await p.click('#tlPlay'); await p.waitForTimeout(3000); await p.click('#tlPlay'); console.log('play 3s:',diff(a,await m()));
 a=await m(); await p.click('#vCalc'); await p.waitForTimeout(1500); console.log('open calc:',diff(a,await m()));
 a=await m(); await p.selectOption('#calcView select[title="Start hour"] >> nth=0','5'); await p.waitForTimeout(1000); console.log('calc edit:',diff(a,await m()));
 console.log(errs); await b.close(); })();
