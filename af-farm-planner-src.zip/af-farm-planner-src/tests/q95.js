const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800); await p.evaluate(()=>localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
 const mk=wb=>[{id:1,name:'Spain',doctrine:'Axis',cities:[{name:'Madrid',res:'metal',warbond:wb,buildings:[]}],buildings:[{id:5,name:'Barracks',lvl:2,qty:1,type:'building',label:'x',cityName:'Madrid',day:1,hour:0}],items:[{id:7,label:'Infantry Lv1',qty:1,type:'production',city:'Madrid',day:1,hour:6,cost:{}},{id:8,label:'Infantry Lv1',qty:1,type:'production',city:'Madrid',day:2,hour:0,cost:{}}]}];
 for(const wb of [0,1]){ await p.evaluate(c=>AFBridge.save(c),mk(wb)); await p.waitForTimeout(600); console.log('warbond',wb, await p.evaluate(()=>[AFBridge.info(5),AFBridge.info(7),AFBridge.info(8)])); }
 console.log(errs); await b.close(); })();
