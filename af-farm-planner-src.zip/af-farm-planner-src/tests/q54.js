const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.setContent('<!doctype html><meta charset="utf-8"><style>[hidden]{display:none!important}</style>'+require('fs').readFileSync('farm_planner.html','utf8'),{waitUntil:'load'}); await p.waitForTimeout(400);
 for(let i=0;i<3;i++) await p.click('#zin');
 // find a 2-unit AI army and click it
 const i=await p.evaluate(()=>{const D=JSON.parse(document.getElementById('data').textContent); return D.arm.findIndex(a=>a.u.length==2&&D.nat[a.o].n==='Russian Empire');});
 const q=await p.evaluate(i=>JSON.parse(document.getElementById('data').textContent).arm[i].p,i);
 const at=async(q)=>p.evaluate(q=>{const m=document.getElementById('stage').style.transform.match(/translate\(([-\d.]+)px, ([-\d.]+)px\) scale\(([-\d.]+)\)/); const r=document.getElementById('map').getBoundingClientRect(); return [r.left+ +m[1]+q[0]*m[3], r.top+ +m[2]+q[1]*m[3]];},q);
 let [x,y]=await at(q); const c=await p.evaluate(()=>{const b=document.getElementById('map').getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]});
 await p.mouse.move(c[0],c[1]); await p.mouse.down(); await p.mouse.move(c[0]+(c[0]-x),c[1]+(c[1]-y),{steps:8}); await p.mouse.up();
 [x,y]=await at(q); await p.mouse.click(x,y); await p.waitForTimeout(200); console.log((await p.innerText('#pop')).replace(/\n/g,' | '));
 if(await p.$('#pop [data-pick]')){ await p.click('#pop [data-pick]'); await p.waitForTimeout(150); console.log((await p.innerText('#pop')).replace(/\n/g,' | ')); }
 await p.click('#dSplit'); await p.waitForTimeout(200); console.log('SPLIT POP:', (await p.innerText('#pop')).replace(/\n/g,' | '));
 await p.click('#pop [data-sp="0"]'); await p.click('#spOk'); await p.waitForTimeout(200);
 console.log(await p.evaluate(()=>[...document.querySelectorAll('.route .rh')].map(e=>e.innerText.replace(/\n/g,' ')).join(' || ')));
 console.log('bar', (await p.innerText('#rbar')).replace(/\n/g,' | '));
 console.log(errs); await b.close(); })();
