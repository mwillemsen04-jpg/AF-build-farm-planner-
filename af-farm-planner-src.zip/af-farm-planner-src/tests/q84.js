const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800); await p.evaluate(()=>localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
 for(let i=0;i<2;i++) await p.click('#zin');
 const at=async(q)=>p.evaluate(q=>{const m=document.getElementById('stage').style.transform.match(/translate\(([-\d.]+)px, ([-\d.]+)px\) scale\(([-\d.]+)\)/); const r=document.getElementById('map').getBoundingClientRect(); return [r.left+ +m[1]+q[0]*m[3], r.top+ +m[2]+q[1]*m[3]];},q);
 const D=await p.evaluate(()=>{const D=JSON.parse(document.getElementById('data').textContent); return {prov:D.prov.map(x=>x.p), a:D.arm.map(a=>a.p)};});
 // click a bit away from the centre (armies stand on centres)
 let [x,y]=await at(D.prov[0]); await p.mouse.click(x+22,y+22); await p.waitForTimeout(400);
 console.log('pop:', (await p.innerText('#pop')).replace(/\n+/g,' | ').slice(0,200), '| side:', (await p.innerText('#prod')).slice(0,60));
await p.screenshot({path:'/tmp/claude-0/pop.png'});
 await p.click('#popProd [data-bld="Airstrip"]'); await p.waitForTimeout(200);
 console.log('queue in pop:', (await p.innerText('#popProd')).includes('Airstrip'), (await p.innerText('#pUnit')).slice(0,40).replace(/\n/g,','), 'scroll', await p.evaluate(()=>[scrollY, document.querySelector('aside').scrollTop]));
 await p.screenshot({path:'/tmp/claude-0/pop.png'});
 await p.click('#dClose'); await p.waitForTimeout(200); console.log('closed; side:', (await p.innerText('#prod')).slice(0,60).replace(/\n/g,' '));
 [x,y]=await at(D.a[0]); await p.mouse.click(x,y); await p.waitForTimeout(300); console.log('army pop wide?', await p.evaluate(()=>document.getElementById('pop').className));
 console.log(errs); await b.close(); })();
