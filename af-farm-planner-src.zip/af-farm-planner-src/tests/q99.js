const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const res={};
 for(const f of ['fp_old.html','fp_new.html']){ const p=await b.newPage(); await p.goto('http://localhost:8765/'+f); await p.waitForTimeout(1500);
  res[f]=await p.evaluate(()=>{ const D=JSON.parse(document.getElementById('data').textContent); const P=D.prov; const out=[]; let seed=7; const rnd=()=>{ seed=(seed*16807)%2147483647; return seed/2147483647; };
    for(let k=0;k<40;k++){ const a=Math.floor(rnd()*P.length), b2=Math.floor(rnd()*P.length), c2=Math.floor(rnd()*P.length); const r={id:1,wps:[a,b2,c2],doc:1+(k%4),me:P[a].o,unit:['Infantry','Armored Car','Cruiser','Motorized Infantry'][k%4],lvl:1,tr:1,cnt:2,sh:(k%3)*10,fm:k%5==0};
      const c=__farmSim.computeRoute(r); out.push(c.ok?c.total.toFixed(6):'x'); } return out; });
  await p.close(); }
 const d=res['fp_old.html'].filter((x,i)=>x!==res['fp_new.html'][i]).length; console.log('diffs',d,'of',res['fp_old.html'].length, res['fp_old.html'].slice(0,6), res['fp_new.html'].slice(0,6)); await b.close(); })();
