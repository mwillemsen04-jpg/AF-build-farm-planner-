const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1400,height:900}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('http://localhost:8765/farm_planner.html'); await p.waitForTimeout(800); await p.evaluate(()=>localStorage.clear()); await p.reload(); await p.waitForTimeout(1000);
 const R=async l=>console.log(l, JSON.stringify(await p.evaluate(()=>{ const P=JSON.parse(document.getElementById('data').textContent).prov; return JSON.parse(localStorage.getItem('afp_routes')).map(r=>({n:r.name,at:P[r.wps[0]].n,army:r.army,stack:r.stack,cnt:r.cnt,unit:r.unit,adds:(r.adds||[]).map(a=>a.t),born:r.born})); })));
 // Madrid has a Spanish AI army at the start?
 console.log('AI in Madrid:', await p.evaluate(()=>{ const D=JSON.parse(document.getElementById('data').textContent); const pi=D.prov.findIndex(x=>x.n==='Madrid'); return D.arm.filter(a=>Math.hypot(a.p[0]-D.prov[pi].p[0],a.p[1]-D.prov[pi].p[1])<5).map(a=>a.u); }));
 await p.evaluate(()=>AFBridge.save([{id:1,name:'Spain',doctrine:'Axis',cities:[{name:'Madrid',res:'metal',buildings:[]}],buildings:[{id:5,name:'Barracks',lvl:1,qty:1,type:'building',label:'x',cityName:'Madrid',day:1,hour:0},{id:6,name:'Naval Base',lvl:1,qty:1,type:'building',label:'y',cityName:'Malaga',day:1,hour:0}],
   items:[{id:7,label:'Infantry Lv1',qty:2,type:'production',city:'Madrid',day:1,hour:0,cost:{}},{id:8,label:'Infantry Lv1',qty:1,type:'production',city:'Madrid',day:1,hour:6,cost:{}},{id:9,label:'Cruiser Lv1',qty:1,type:'production',city:'Malaga',day:1,hour:0,cost:{}}]}]));
 await p.waitForTimeout(700); await R('after:');
 console.log(await p.evaluate(()=>[AFBridge.info(7),AFBridge.info(8),AFBridge.info(9)]));
 for(const T of [0,3,6,12]){ await p.evaluate(T=>__farmT.set(T),T); await p.waitForTimeout(250); console.log('t',T, await p.evaluate(()=>[...document.querySelectorAll('#gMov text')].map(t=>t.textContent).join(','))); }
 console.log(errs); await b.close(); })();
