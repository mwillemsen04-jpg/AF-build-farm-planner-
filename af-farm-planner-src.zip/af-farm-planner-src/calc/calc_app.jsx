
const{useState}=React;
const DOCTRINES=["Pan-Asian","Axis","Allies","Comintern"];
const DOCTRINE_COLORS={"Pan-Asian":"#e53935","Axis":"#455a64","Allies":"#1565c0","Comintern":"#16a34a"};
const COUNTRY_COLORS={
  "Algeria":"#f59e0b","Canada":"#ef4444","Caucasus":"#8b5cf6",
  "Communist Russia":"#dc2626","Egypt":"#d97706","France":"#3b82f6",
  "Germany":"#6b7280","Greater Finland":"#06b6d4","Greater Romania":"#84cc16",
  "Italy":"#10b981","Libya":"#f97316","Morocco":"#eab308",
  "Northern States of America":"#60a5fa","Poland":"#e879f9","Russian Empire":"#a855f7",
  "Southern United States":"#fb923c","Spain":"#f43f5e","Sweden":"#2dd4bf",
  "Turkey":"#fbbf24","United Kingdom":"#38bdf8","Ukraine":"#facc15","Yugoslavia":"#4ade80",
};

const MAPS={
  "EU22":"22 Player EU map",
};

const COUNTRIES=[
  {name:"Algeria",doctrine:"Allies",map:"EU22"},{name:"Canada",doctrine:"Allies",map:"EU22"},{name:"Caucasus",doctrine:"Comintern",map:"EU22"},
  {name:"Communist Russia",doctrine:"Comintern",map:"EU22"},{name:"Egypt",doctrine:"Allies",map:"EU22"},{name:"France",doctrine:"Allies",map:"EU22"},
  {name:"Germany",doctrine:"Axis",map:"EU22"},{name:"Greater Finland",doctrine:"Axis",map:"EU22"},{name:"Greater Romania",doctrine:"Comintern",map:"EU22"},
  {name:"Italy",doctrine:"Axis",map:"EU22"},{name:"Libya",doctrine:"Pan-Asian",map:"EU22"},{name:"Morocco",doctrine:"Allies",map:"EU22"},
  {name:"Northern States of America",doctrine:"Allies",map:"EU22"},{name:"Poland",doctrine:"Comintern",map:"EU22"},
  {name:"Russian Empire",doctrine:"Pan-Asian",map:"EU22"},{name:"Southern United States",doctrine:"Pan-Asian",map:"EU22"},
  {name:"Spain",doctrine:"Axis",map:"EU22"},{name:"Sweden",doctrine:"Axis",map:"EU22"},{name:"Turkey",doctrine:"Comintern",map:"EU22"},
  {name:"United Kingdom",doctrine:"Allies",map:"EU22"},{name:"Ukraine",doctrine:"Axis",map:"EU22"},{name:"Yugoslavia",doctrine:"Comintern",map:"EU22"},
];

const BUILDINGS=[
  {name:"Barracks",maxLvl:5,res:["money","food","metal"],costs:[[3600,2250,1350],[4800,3000,1800],[6400,4000,2400],[8500,5300,3200],[11300,7050,4250]]},
  {name:"Ordnance Foundry",maxLvl:5,res:["money","food","oil"],costs:[[3600,1200,2400],[4800,1600,3200],[6400,2150,4250],[8500,2850,5650],[11300,3800,7500]]},
  {name:"Tank Plant",maxLvl:5,res:["money","metal","oil"],costs:[[3600,2100,1500],[4800,2800,2000],[6400,3700,2700],[8500,4900,3500],[11300,6500,4650]]},
  {name:"Aircraft Factory",maxLvl:5,res:["money","food","oil"],costs:[[3600,1250,2350],[4800,1650,3150],[6400,2200,4200],[8500,2950,5600],[11300,3900,7450]]},
  {name:"Naval Base",maxLvl:5,res:["money","food","metal"],costs:[[3600,1450,2150],[4800,1950,2850],[6400,2600,3800],[8500,3450,5050],[11300,4600,6700]]},
  {name:"Secret Lab",maxLvl:5,res:["money","metal","oil"],costs:[[3600,1400,2200],[4800,1850,2950],[6400,2450,3900],[8500,3250,5200],[11300,4300,6900]]},
  {name:"Industry",maxLvl:5,res:["money","metal","oil"],costs:[[3000,1400,1600],[4000,1850,2150],[5300,2450,2850],[7050,3250,3800],[9400,4300,5050]]},
  {name:"Bunkers",maxLvl:5,res:["money","metal","oil"],costs:[[1500,850,650],[2000,1150,850],[2700,1550,1150],[3500,2050,1550],[4650,2750,2050]]},
  {name:"Recruiting Station",maxLvl:3,res:["money","food","metal"],costs:[[2700,1600,1100],[3600,2150,1450],[4800,2850,1950]]},
  {name:"Propaganda Office",maxLvl:3,res:["money","food","oil"],costs:[[1800,1000,800],[2400,1350,1050],[3200,1800,1400]]},
  {name:"Infrastructure",maxLvl:3,res:["money","metal","oil"],costs:[[1000,600,400],[1200,700,500],[1450,850,600]]},
  {name:"Airfield",maxLvl:3,res:["money","food","metal"],costs:[[1500,500,1000],[2000,650,1400],[2700,850,1800]]},
  {name:"Local Industry",maxLvl:3,res:["money","food","metal"],costs:[[3200,1400,1800],[4500,1950,2500],[6300,2800,3500]]},
  {name:"Fort",maxLvl:3,res:["money","food","metal"],costs:[[1500,600,900],[2000,800,1200],[2700,1100,1600]]},
  {name:"Harbor",maxLvl:2,res:["money","metal","oil"],costs:[[700,450,250],[850,550,300]]},
  {name:"Capitol",maxLvl:1,res:["money","food","metal"],costs:[[2500,1250,1250]]},
];

// Production costs per doctrine — full unit data with all levels
const PRODUCTION = {
  "Axis": {
    "Aircraft Carrier Lv1":{money:2310,food:1320,metal:1160,oil:0,manpower:1650},
    "Aircraft Carrier Lv2":{money:2480,food:1430,metal:1270,oil:0,manpower:1650},
    "Aircraft Carrier Lv3":{money:2860,food:1650,metal:1430,oil:0,manpower:1710},
    "Aircraft Carrier Lv4":{money:3250,food:1870,metal:1600,oil:0,manpower:1760},
    "Aircraft Carrier Lv5":{money:3800,food:2150,metal:1870,oil:0,manpower:1820},
    "Aircraft Carrier Lv6":{money:4180,food:2370,metal:2090,oil:0,manpower:1870},
    "Anti Air Lv1":{money:940,food:1100,metal:660,oil:0,manpower:940},
    "Anti Air Lv2":{money:990,food:1210,metal:720,oil:0,manpower:990},
    "Anti Air Lv3":{money:1100,food:1320,metal:770,oil:0,manpower:990},
    "Anti Air Lv4":{money:1270,food:1540,metal:880,oil:0,manpower:1050},
    "Anti Air Lv5":{money:1430,food:1710,metal:990,oil:0,manpower:1050},
    "Anti Air Lv6":{money:1600,food:1870,metal:1100,oil:0,manpower:1100},
    "Anti Tank Lv1":{money:880,food:1160,metal:610,oil:0,manpower:830},
    "Anti Tank Lv2":{money:990,food:1270,metal:660,oil:0,manpower:830},
    "Anti Tank Lv3":{money:1100,food:1380,metal:770,oil:0,manpower:880},
    "Anti Tank Lv4":{money:1210,food:1600,metal:880,oil:0,manpower:880},
    "Anti Tank Lv5":{money:1380,food:1760,metal:940,oil:0,manpower:940},
    "Anti Tank Lv6":{money:1540,food:1980,metal:1050,oil:0,manpower:940},
    "Armored Car Lv1":{money:1930,food:0,metal:1210,oil:1100,manpower:1160},
    "Armored Car Lv2":{money:2040,food:0,metal:1320,oil:1160,manpower:1160},
    "Armored Car Lv3":{money:2310,food:0,metal:1490,oil:1320,manpower:1210},
    "Armored Car Lv4":{money:2750,food:0,metal:1760,oil:1600,manpower:1210},
    "Armored Car Lv5":{money:3250,food:0,metal:2090,oil:1870,manpower:1270},
    "Artillery Lv1":{money:1540,food:1980,metal:830,oil:0,manpower:1210},
    "Artillery Lv2":{money:1710,food:2150,metal:940,oil:0,manpower:1210},
    "Artillery Lv3":{money:1870,food:2420,metal:1050,oil:0,manpower:1210},
    "Artillery Lv4":{money:2150,food:2750,metal:1160,oil:0,manpower:1270},
    "Artillery Lv5":{money:2420,food:3080,metal:1320,oil:0,manpower:1320},
    "Artillery Lv6":{money:2640,food:3410,metal:1430,oil:0,manpower:1320},
    "Attack Bomber Lv1":{money:1600,food:1160,metal:0,oil:1710,manpower:1160},
    "Attack Bomber Lv2":{money:1820,food:1320,metal:0,oil:1980,manpower:1210},
    "Attack Bomber Lv3":{money:2090,food:1490,metal:0,oil:2260,manpower:1210},
    "Attack Bomber Lv4":{money:2480,food:1760,metal:0,oil:2700,manpower:1270},
    "Attack Bomber Lv5":{money:2700,food:1980,metal:0,oil:2970,manpower:1320},
    "Battleship Lv1":{money:1980,food:990,metal:2970,oil:0,manpower:1820},
    "Battleship Lv2":{money:2150,food:1050,metal:3190,oil:0,manpower:1820},
    "Battleship Lv3":{money:2480,food:1210,metal:3690,oil:0,manpower:1870},
    "Battleship Lv4":{money:2750,food:1380,metal:4180,oil:0,manpower:1930},
    "Battleship Lv5":{money:3250,food:1650,metal:4900,oil:0,manpower:1980},
    "Battleship Lv6":{money:3580,food:1760,metal:5340,oil:0,manpower:2040},
    "Commandos Lv1":{money:2370,food:2370,metal:0,oil:1100,manpower:1160},
    "Commandos Lv2":{money:2700,food:2700,metal:0,oil:1270,manpower:1210},
    "Commandos Lv3":{money:3030,food:3030,metal:0,oil:1430,manpower:1210},
    "Commandos Lv4":{money:3520,food:3520,metal:0,oil:1650,manpower:1270},
    "Cruiser Lv1":{money:1490,food:2090,metal:1210,oil:0,manpower:1100},
    "Cruiser Lv2":{money:1600,food:2260,metal:1270,oil:0,manpower:1100},
    "Cruiser Lv3":{money:1820,food:2530,metal:1430,oil:0,manpower:1160},
    "Cruiser Lv4":{money:2040,food:2860,metal:1650,oil:0,manpower:1160},
    "Cruiser Lv5":{money:2420,food:3360,metal:1930,oil:0,manpower:1210},
    "Cruiser Lv6":{money:2640,food:3740,metal:2150,oil:0,manpower:1270},
    "Destroyer Lv1":{money:1430,food:1100,metal:1320,oil:0,manpower:880},
    "Destroyer Lv2":{money:1600,food:1210,metal:1430,oil:0,manpower:940},
    "Destroyer Lv3":{money:1760,food:1320,metal:1600,oil:0,manpower:940},
    "Destroyer Lv4":{money:1980,food:1490,metal:1820,oil:0,manpower:940},
    "Destroyer Lv5":{money:2370,food:1760,metal:2150,oil:0,manpower:990},
    "Destroyer Lv6":{money:2590,food:1980,metal:2420,oil:0,manpower:1050},
    "Flame Tank Lv1":{money:2250,food:0,metal:2050,oil:2050,manpower:1550},
    "Flame Tank Lv2":{money:2550,food:0,metal:2350,oil:2350,manpower:1600},
    "Flame Tank Lv3":{money:2950,food:0,metal:2700,oil:2700,manpower:1650},
    "Flying Bomb Lv1":{money:830,food:0,metal:830,oil:440,manpower:220},
    "Heavy Tank Lv1":{money:2860,food:0,metal:2310,oil:3360,manpower:1430},
    "Heavy Tank Lv2":{money:3250,food:0,metal:2640,oil:3800,manpower:1490},
    "Heavy Tank Lv3":{money:3800,food:0,metal:3140,oil:4510,manpower:1540},
    "Heavy Tank Lv4":{money:4400,food:0,metal:3630,oil:5230,manpower:1600},
    "Infantry Lv1":{money:880,food:1210,metal:280,oil:0,manpower:1050},
    "Infantry Lv2":{money:880,food:1270,metal:280,oil:0,manpower:1050},
    "Infantry Lv3":{money:940,food:1320,metal:280,oil:0,manpower:1050},
    "Infantry Lv4":{money:990,food:1380,metal:280,oil:0,manpower:1100},
    "Infantry Lv5":{money:1100,food:1540,metal:330,oil:0,manpower:1100},
    "Infantry Lv6":{money:1270,food:1760,metal:390,oil:0,manpower:1160},
    "Infantry Lv7":{money:1380,food:1930,metal:440,oil:0,manpower:1160},
    "Interceptor Lv1":{money:1650,food:1050,metal:0,oil:1050,manpower:880},
    "Interceptor Lv2":{money:1760,food:1100,metal:0,oil:1100,manpower:880},
    "Interceptor Lv3":{money:1870,food:1210,metal:0,oil:1210,manpower:880},
    "Interceptor Lv4":{money:2150,food:1380,metal:0,oil:1380,manpower:940},
    "Interceptor Lv5":{money:2420,food:1540,metal:0,oil:1540,manpower:940},
    "Interceptor Lv6":{money:2700,food:1760,metal:0,oil:1760,manpower:990},
    "Interceptor Lv7":{money:2970,food:1930,metal:0,oil:1930,manpower:990},
    "Light Tank Lv1":{money:1210,food:0,metal:1650,oil:1490,manpower:990},
    "Light Tank Lv2":{money:1320,food:0,metal:1760,oil:1600,manpower:1050},
    "Light Tank Lv3":{money:1490,food:0,metal:1980,oil:1820,manpower:1050},
    "Light Tank Lv4":{money:1760,food:0,metal:2370,oil:2200,manpower:1100},
    "Light Tank Lv5":{money:2090,food:0,metal:2810,oil:2530,manpower:1160},
    "Mechanized Infantry Lv1":{money:1760,food:0,metal:1600,oil:1430,manpower:1380},
    "Mechanized Infantry Lv2":{money:2040,food:0,metal:1870,oil:1650,manpower:1430},
    "Mechanized Infantry Lv3":{money:2310,food:0,metal:2090,oil:1870,manpower:1430},
    "Mechanized Infantry Lv4":{money:2590,food:0,metal:2370,oil:2090,manpower:1490},
    "Mechanized Infantry Lv5":{money:2860,food:0,metal:2590,oil:2310,manpower:1540},
    "Medium Tank Lv1":{money:1930,food:0,metal:1930,oil:2090,manpower:1490},
    "Medium Tank Lv2":{money:2150,food:0,metal:2150,oil:2310,manpower:1540},
    "Medium Tank Lv3":{money:2420,food:0,metal:2420,oil:2640,manpower:1600},
    "Medium Tank Lv4":{money:2700,food:0,metal:2700,oil:2970,manpower:1600},
    "Medium Tank Lv5":{money:3030,food:0,metal:3030,oil:3300,manpower:1650},
    "Medium Tank Lv6":{money:3300,food:0,metal:3300,oil:3630,manpower:1710},
    "Militia Lv1":{money:660,food:550,metal:220,oil:0,manpower:880},
    "Militia Lv2":{money:720,food:610,metal:280,oil:0,manpower:940},
    "Militia Lv3":{money:830,food:720,metal:330,oil:0,manpower:940},
    "Militia Lv4":{money:990,food:830,metal:390,oil:0,manpower:990},
    "Motorized Infantry Lv1":{money:1380,food:1100,metal:0,oil:1650,manpower:1270},
    "Motorized Infantry Lv2":{money:1430,food:1160,metal:0,oil:1710,manpower:1270},
    "Motorized Infantry Lv3":{money:1600,food:1270,metal:0,oil:1930,manpower:1270},
    "Motorized Infantry Lv4":{money:1820,food:1430,metal:0,oil:2200,manpower:1320},
    "Motorized Infantry Lv5":{money:2040,food:1650,metal:0,oil:2420,manpower:1380},
    "Motorized Infantry Lv6":{money:2260,food:1820,metal:0,oil:2700,manpower:1380},
    "Naval Bomber Lv1":{money:1210,food:1320,metal:0,oil:1430,manpower:770},
    "Naval Bomber Lv2":{money:1270,food:1380,metal:0,oil:1490,manpower:770},
    "Naval Bomber Lv3":{money:1320,food:1490,metal:0,oil:1600,manpower:770},
    "Naval Bomber Lv4":{money:1540,food:1710,metal:0,oil:1820,manpower:830},
    "Naval Bomber Lv5":{money:1760,food:1930,metal:0,oil:2090,manpower:830},
    "Naval Bomber Lv6":{money:1930,food:2150,metal:0,oil:2310,manpower:880},
    "Naval Bomber Lv7":{money:2150,food:2370,metal:0,oil:2530,manpower:880},
    "Nuclear Bomber Lv1":{money:23160,food:3850,metal:3850,oil:10290,manpower:6270},
    "Nuclear Bomber Lv2":{money:24260,food:4070,metal:4070,oil:10780,manpower:6380},
    "Nuclear Bomber Lv3":{money:25410,food:4240,metal:4240,oil:11280,manpower:6440},
    "Nuclear Rocket Lv1":{money:26730,food:7430,metal:7430,oil:8910,manpower:5010},
    "Paratroopers Lv1":{money:2810,food:1490,metal:0,oil:1320,manpower:1490},
    "Paratroopers Lv2":{money:3190,food:1710,metal:0,oil:1490,manpower:1540},
    "Paratroopers Lv3":{money:3580,food:1930,metal:0,oil:1650,manpower:1600},
    "Paratroopers Lv4":{money:4180,food:2200,metal:0,oil:1930,manpower:1650},
    "Railroad Gun Lv1":{money:4460,food:0,metal:3740,oil:2040,manpower:2920},
    "Railroad Gun Lv2":{money:6110,food:0,metal:5170,oil:2810,manpower:3140},
    "Rocket Lv1":{money:2420,food:0,metal:880,oil:1160,manpower:500},
    "Rocket Lv2":{money:2750,food:0,metal:990,oil:1320,manpower:500},
    "Rocket Lv3":{money:3080,food:0,metal:1160,oil:1490,manpower:550},
    "Rocket Lv4":{money:3410,food:0,metal:1270,oil:1650,manpower:550},
    "Rocket Artillery Lv1":{money:1490,food:1380,metal:1930,oil:0,manpower:1100},
    "Rocket Artillery Lv2":{money:1760,food:1540,metal:2260,oil:0,manpower:1100},
    "Rocket Artillery Lv3":{money:2200,food:1980,metal:2860,oil:0,manpower:1160},
    "Rocket Fighter Lv1":{money:1490,food:1210,metal:0,oil:2200,manpower:830},
    "Rocket Fighter Lv2":{money:1870,food:1540,metal:0,oil:2860,manpower:880},
    "SP Anti Air Lv1":{money:1540,food:990,metal:0,oil:1820,manpower:1100},
    "SP Anti Air Lv2":{money:1760,food:1160,metal:0,oil:2090,manpower:1100},
    "SP Anti Air Lv3":{money:2040,food:1270,metal:0,oil:2370,manpower:1160},
    "SP Anti Air Lv4":{money:2260,food:1430,metal:0,oil:2640,manpower:1160},
    "SP Anti Air Lv5":{money:2480,food:1600,metal:0,oil:2920,manpower:1210},
    "SP Artillery Lv1":{money:2420,food:0,metal:1980,oil:1820,manpower:1540},
    "SP Artillery Lv2":{money:2750,food:0,metal:2310,oil:2090,manpower:1600},
    "SP Artillery Lv3":{money:3140,food:0,metal:2590,oil:2370,manpower:1600},
    "SP Artillery Lv4":{money:3470,food:0,metal:2920,oil:2590,manpower:1650},
    "SP Artillery Lv5":{money:3850,food:0,metal:3190,oil:2860,manpower:1710},
    "SP Rocket Artillery Lv1":{money:2090,food:0,metal:2090,oil:2090,manpower:1710},
    "SP Rocket Artillery Lv2":{money:2700,food:0,metal:2700,oil:2700,manpower:1760},
    "Strategic Bomber Lv1":{money:1980,food:1760,metal:0,oil:1760,manpower:2150},
    "Strategic Bomber Lv2":{money:2150,food:1930,metal:0,oil:1930,manpower:2200},
    "Strategic Bomber Lv3":{money:2310,food:2090,metal:0,oil:2090,manpower:2200},
    "Strategic Bomber Lv4":{money:2640,food:2370,metal:0,oil:2370,manpower:2310},
    "Strategic Bomber Lv5":{money:2920,food:2640,metal:0,oil:2640,manpower:2370},
    "Strategic Bomber Lv6":{money:3250,food:2920,metal:0,oil:2920,manpower:2420},
    "Strategic Bomber Lv7":{money:3580,food:3190,metal:0,oil:3190,manpower:2480},
    "Submarine Lv1":{money:1760,food:1050,metal:0,oil:1050,manpower:770},
    "Submarine Lv2":{money:1870,food:1160,metal:0,oil:1160,manpower:770},
    "Submarine Lv3":{money:2090,food:1270,metal:0,oil:1270,manpower:770},
    "Submarine Lv4":{money:2420,food:1430,metal:0,oil:1430,manpower:830},
    "Submarine Lv5":{money:2810,food:1710,metal:0,oil:1710,manpower:830},
    "Submarine Lv6":{money:3140,food:1870,metal:0,oil:1870,manpower:880},
    "Tactical Bomber Lv1":{money:1760,food:2310,metal:0,oil:1430,manpower:1430},
    "Tactical Bomber Lv2":{money:1930,food:2480,metal:0,oil:1540,manpower:1430},
    "Tactical Bomber Lv3":{money:2040,food:2640,metal:0,oil:1650,manpower:1490},
    "Tactical Bomber Lv4":{money:2310,food:3030,metal:0,oil:1870,manpower:1540},
    "Tactical Bomber Lv5":{money:2590,food:3410,metal:0,oil:2090,manpower:1540},
    "Tactical Bomber Lv6":{money:2860,food:3740,metal:0,oil:2310,manpower:1600},
    "Tactical Bomber Lv7":{money:3190,food:4130,metal:0,oil:2530,manpower:1650},
    "Tank Destroyer Lv1":{money:2260,food:0,metal:2090,oil:1210,manpower:1210},
    "Tank Destroyer Lv2":{money:2530,food:0,metal:2310,oil:1380,manpower:1270},
    "Tank Destroyer Lv3":{money:2860,food:0,metal:2640,oil:1540,manpower:1270},
    "Tank Destroyer Lv4":{money:3250,food:0,metal:2970,oil:1760,manpower:1320},
    "Tank Destroyer Lv5":{money:3580,food:0,metal:3300,oil:1930,manpower:1320},
    "Tank Destroyer Lv6":{money:3910,food:0,metal:3630,oil:2090,manpower:1380},
  },
  "Allies": {
    "Aircraft Carrier Lv1":{money:2100,food:1200,metal:1050,oil:0,manpower:1500},
    "Aircraft Carrier Lv2":{money:2250,food:1300,metal:1150,oil:0,manpower:1500},
    "Aircraft Carrier Lv3":{money:2600,food:1500,metal:1300,oil:0,manpower:1550},
    "Aircraft Carrier Lv4":{money:2950,food:1700,metal:1450,oil:0,manpower:1600},
    "Aircraft Carrier Lv5":{money:3450,food:1950,metal:1700,oil:0,manpower:1650},
    "Aircraft Carrier Lv6":{money:3800,food:2150,metal:1900,oil:0,manpower:1700},
    "Anti Air Lv1":{money:850,food:1000,metal:600,oil:0,manpower:850},
    "Anti Air Lv2":{money:900,food:1100,metal:650,oil:0,manpower:900},
    "Anti Air Lv3":{money:1000,food:1200,metal:700,oil:0,manpower:900},
    "Anti Air Lv4":{money:1150,food:1400,metal:800,oil:0,manpower:950},
    "Anti Air Lv5":{money:1300,food:1550,metal:900,oil:0,manpower:950},
    "Anti Air Lv6":{money:1450,food:1700,metal:1000,oil:0,manpower:1000},
    "Anti Tank Lv1":{money:800,food:1050,metal:550,oil:0,manpower:750},
    "Anti Tank Lv2":{money:900,food:1150,metal:600,oil:0,manpower:750},
    "Anti Tank Lv3":{money:1000,food:1250,metal:700,oil:0,manpower:800},
    "Anti Tank Lv4":{money:1100,food:1450,metal:800,oil:0,manpower:800},
    "Anti Tank Lv5":{money:1250,food:1600,metal:850,oil:0,manpower:850},
    "Anti Tank Lv6":{money:1400,food:1800,metal:950,oil:0,manpower:850},
    "Armored Car Lv1":{money:1750,food:0,metal:1100,oil:1000,manpower:1050},
    "Armored Car Lv2":{money:1850,food:0,metal:1200,oil:1050,manpower:1050},
    "Armored Car Lv3":{money:2100,food:0,metal:1350,oil:1200,manpower:1100},
    "Armored Car Lv4":{money:2500,food:0,metal:1600,oil:1450,manpower:1100},
    "Armored Car Lv5":{money:2950,food:0,metal:1900,oil:1700,manpower:1150},
    "Artillery Lv1":{money:1400,food:1800,metal:750,oil:0,manpower:1100},
    "Artillery Lv2":{money:1550,food:1950,metal:850,oil:0,manpower:1100},
    "Artillery Lv3":{money:1700,food:2200,metal:950,oil:0,manpower:1100},
    "Artillery Lv4":{money:1950,food:2500,metal:1050,oil:0,manpower:1150},
    "Artillery Lv5":{money:2200,food:2800,metal:1200,oil:0,manpower:1200},
    "Artillery Lv6":{money:2400,food:3100,metal:1300,oil:0,manpower:1200},
    "Attack Bomber Lv1":{money:1450,food:1050,metal:0,oil:1550,manpower:1050},
    "Attack Bomber Lv2":{money:1650,food:1200,metal:0,oil:1800,manpower:1100},
    "Attack Bomber Lv3":{money:1900,food:1350,metal:0,oil:2050,manpower:1100},
    "Attack Bomber Lv4":{money:2250,food:1600,metal:0,oil:2450,manpower:1150},
    "Attack Bomber Lv5":{money:2450,food:1800,metal:0,oil:2700,manpower:1200},
    "Battleship Lv1":{money:1800,food:900,metal:2700,oil:0,manpower:1650},
    "Battleship Lv2":{money:1950,food:950,metal:2900,oil:0,manpower:1650},
    "Battleship Lv3":{money:2250,food:1100,metal:3350,oil:0,manpower:1700},
    "Battleship Lv4":{money:2500,food:1250,metal:3800,oil:0,manpower:1750},
    "Battleship Lv5":{money:2950,food:1500,metal:4450,oil:0,manpower:1800},
    "Battleship Lv6":{money:3250,food:1600,metal:4850,oil:0,manpower:1850},
    "Commandos Lv1":{money:2150,food:2150,metal:0,oil:1000,manpower:1050},
    "Commandos Lv2":{money:2450,food:2450,metal:0,oil:1150,manpower:1100},
    "Commandos Lv3":{money:2750,food:2750,metal:0,oil:1300,manpower:1100},
    "Commandos Lv4":{money:3200,food:3200,metal:0,oil:1500,manpower:1150},
    "Cruiser Lv1":{money:1350,food:1900,metal:1100,oil:0,manpower:1000},
    "Cruiser Lv2":{money:1450,food:2050,metal:1150,oil:0,manpower:1000},
    "Cruiser Lv3":{money:1650,food:2300,metal:1300,oil:0,manpower:1050},
    "Cruiser Lv4":{money:1850,food:2600,metal:1500,oil:0,manpower:1050},
    "Cruiser Lv5":{money:2200,food:3050,metal:1750,oil:0,manpower:1100},
    "Cruiser Lv6":{money:2400,food:3400,metal:1950,oil:0,manpower:1150},
    "Destroyer Lv1":{money:1300,food:1000,metal:1200,oil:0,manpower:800},
    "Destroyer Lv2":{money:1450,food:1100,metal:1300,oil:0,manpower:850},
    "Destroyer Lv3":{money:1600,food:1200,metal:1450,oil:0,manpower:850},
    "Destroyer Lv4":{money:1800,food:1350,metal:1650,oil:0,manpower:850},
    "Destroyer Lv5":{money:2150,food:1600,metal:1950,oil:0,manpower:900},
    "Destroyer Lv6":{money:2350,food:1800,metal:2200,oil:0,manpower:950},
    "Flame Tank Lv1":{money:2250,food:0,metal:2050,oil:2050,manpower:1550},
    "Flame Tank Lv2":{money:2550,food:0,metal:2350,oil:2350,manpower:1600},
    "Flame Tank Lv3":{money:2950,food:0,metal:2700,oil:2700,manpower:1650},
    "Flying Bomb Lv1":{money:750,food:0,metal:750,oil:400,manpower:200},
    "Heavy Tank Lv1":{money:2600,food:0,metal:2100,oil:3050,manpower:1300},
    "Heavy Tank Lv2":{money:2950,food:0,metal:2400,oil:3450,manpower:1350},
    "Heavy Tank Lv3":{money:3450,food:0,metal:2850,oil:4100,manpower:1400},
    "Heavy Tank Lv4":{money:4000,food:0,metal:3300,oil:4750,manpower:1450},
    "Infantry Lv1":{money:800,food:1100,metal:250,oil:0,manpower:950},
    "Infantry Lv2":{money:800,food:1150,metal:250,oil:0,manpower:950},
    "Infantry Lv3":{money:850,food:1200,metal:250,oil:0,manpower:950},
    "Infantry Lv4":{money:900,food:1250,metal:250,oil:0,manpower:1000},
    "Infantry Lv5":{money:1000,food:1400,metal:300,oil:0,manpower:1000},
    "Infantry Lv6":{money:1150,food:1600,metal:350,oil:0,manpower:1050},
    "Infantry Lv7":{money:1250,food:1750,metal:400,oil:0,manpower:1050},
    "Interceptor Lv1":{money:1500,food:950,metal:0,oil:950,manpower:800},
    "Interceptor Lv2":{money:1600,food:1000,metal:0,oil:1000,manpower:800},
    "Interceptor Lv3":{money:1700,food:1100,metal:0,oil:1100,manpower:800},
    "Interceptor Lv4":{money:1950,food:1250,metal:0,oil:1250,manpower:850},
    "Interceptor Lv5":{money:2200,food:1400,metal:0,oil:1400,manpower:850},
    "Interceptor Lv6":{money:2450,food:1600,metal:0,oil:1600,manpower:900},
    "Interceptor Lv7":{money:2700,food:1750,metal:0,oil:1750,manpower:900},
    "Light Tank Lv1":{money:1100,food:0,metal:1500,oil:1350,manpower:900},
    "Light Tank Lv2":{money:1200,food:0,metal:1600,oil:1450,manpower:950},
    "Light Tank Lv3":{money:1350,food:0,metal:1800,oil:1650,manpower:950},
    "Light Tank Lv4":{money:1600,food:0,metal:2150,oil:2000,manpower:1000},
    "Light Tank Lv5":{money:1900,food:0,metal:2550,oil:2300,manpower:1050},
    "Mechanized Infantry Lv1":{money:1440,food:0,metal:1310,oil:1170,manpower:1130},
    "Mechanized Infantry Lv2":{money:1670,food:0,metal:1530,oil:1350,manpower:1170},
    "Mechanized Infantry Lv3":{money:1890,food:0,metal:1710,oil:1530,manpower:1170},
    "Mechanized Infantry Lv4":{money:2120,food:0,metal:1940,oil:1710,manpower:1220},
    "Mechanized Infantry Lv5":{money:2340,food:0,metal:2120,oil:1890,manpower:1260},
    "Medium Tank Lv1":{money:1750,food:0,metal:1750,oil:1900,manpower:1350},
    "Medium Tank Lv2":{money:1950,food:0,metal:1950,oil:2100,manpower:1400},
    "Medium Tank Lv3":{money:2200,food:0,metal:2200,oil:2400,manpower:1450},
    "Medium Tank Lv4":{money:2450,food:0,metal:2450,oil:2700,manpower:1450},
    "Medium Tank Lv5":{money:2750,food:0,metal:2750,oil:3000,manpower:1500},
    "Medium Tank Lv6":{money:3000,food:0,metal:3000,oil:3300,manpower:1550},
    "Militia Lv1":{money:600,food:500,metal:200,oil:0,manpower:800},
    "Militia Lv2":{money:650,food:550,metal:250,oil:0,manpower:850},
    "Militia Lv3":{money:750,food:650,metal:300,oil:0,manpower:850},
    "Militia Lv4":{money:900,food:750,metal:350,oil:0,manpower:900},
    "Motorized Infantry Lv1":{money:1250,food:1000,metal:0,oil:1500,manpower:1150},
    "Motorized Infantry Lv2":{money:1300,food:1050,metal:0,oil:1550,manpower:1150},
    "Motorized Infantry Lv3":{money:1450,food:1150,metal:0,oil:1750,manpower:1150},
    "Motorized Infantry Lv4":{money:1650,food:1300,metal:0,oil:2000,manpower:1200},
    "Motorized Infantry Lv5":{money:1850,food:1500,metal:0,oil:2200,manpower:1250},
    "Motorized Infantry Lv6":{money:2050,food:1650,metal:0,oil:2450,manpower:1250},
    "Naval Bomber Lv1":{money:1100,food:1200,metal:0,oil:1300,manpower:700},
    "Naval Bomber Lv2":{money:1150,food:1250,metal:0,oil:1350,manpower:700},
    "Naval Bomber Lv3":{money:1200,food:1350,metal:0,oil:1450,manpower:700},
    "Naval Bomber Lv4":{money:1400,food:1550,metal:0,oil:1650,manpower:750},
    "Naval Bomber Lv5":{money:1600,food:1750,metal:0,oil:1900,manpower:750},
    "Naval Bomber Lv6":{money:1750,food:1950,metal:0,oil:2100,manpower:800},
    "Naval Bomber Lv7":{money:1950,food:2150,metal:0,oil:2300,manpower:800},
    "Nuclear Bomber Lv1":{money:21050,food:3500,metal:3500,oil:9350,manpower:5700},
    "Nuclear Bomber Lv2":{money:22050,food:3700,metal:3700,oil:9800,manpower:5800},
    "Nuclear Bomber Lv3":{money:23100,food:3850,metal:3850,oil:10250,manpower:5850},
    "Nuclear Rocket Lv1":{money:24300,food:6750,metal:6750,oil:8100,manpower:4550},
    "Paratroopers Lv1":{money:2170,food:1150,metal:0,oil:1020,manpower:1150},
    "Paratroopers Lv2":{money:2470,food:1320,metal:0,oil:1150,manpower:1190},
    "Paratroopers Lv3":{money:2760,food:1490,metal:0,oil:1280,manpower:1230},
    "Paratroopers Lv4":{money:3230,food:1700,metal:0,oil:1490,manpower:1280},
    "Railroad Gun Lv1":{money:4050,food:0,metal:3400,oil:1850,manpower:2650},
    "Railroad Gun Lv2":{money:5550,food:0,metal:4700,oil:2550,manpower:2850},
    "Rocket Lv1":{money:2200,food:0,metal:800,oil:1050,manpower:450},
    "Rocket Lv2":{money:2500,food:0,metal:900,oil:1200,manpower:450},
    "Rocket Lv3":{money:2800,food:0,metal:1050,oil:1350,manpower:500},
    "Rocket Lv4":{money:3100,food:0,metal:1150,oil:1500,manpower:500},
    "Rocket Artillery Lv1":{money:1350,food:1250,metal:1750,oil:0,manpower:1000},
    "Rocket Artillery Lv2":{money:1600,food:1400,metal:2050,oil:0,manpower:1000},
    "Rocket Artillery Lv3":{money:2000,food:1800,metal:2600,oil:0,manpower:1050},
    "Rocket Fighter Lv1":{money:1350,food:1100,metal:0,oil:2000,manpower:750},
    "Rocket Fighter Lv2":{money:1700,food:1400,metal:0,oil:2600,manpower:800},
    "SP Anti Air Lv1":{money:1400,food:900,metal:0,oil:1650,manpower:1000},
    "SP Anti Air Lv2":{money:1600,food:1050,metal:0,oil:1900,manpower:1000},
    "SP Anti Air Lv3":{money:1850,food:1150,metal:0,oil:2150,manpower:1050},
    "SP Anti Air Lv4":{money:2050,food:1300,metal:0,oil:2400,manpower:1050},
    "SP Anti Air Lv5":{money:2250,food:1450,metal:0,oil:2650,manpower:1100},
    "SP Artillery Lv1":{money:2200,food:0,metal:1800,oil:1650,manpower:1400},
    "SP Artillery Lv2":{money:2500,food:0,metal:2100,oil:1900,manpower:1450},
    "SP Artillery Lv3":{money:2850,food:0,metal:2350,oil:2150,manpower:1450},
    "SP Artillery Lv4":{money:3150,food:0,metal:2650,oil:2350,manpower:1500},
    "SP Artillery Lv5":{money:3500,food:0,metal:2900,oil:2600,manpower:1550},
    "SP Rocket Artillery Lv1":{money:1900,food:0,metal:1900,oil:1900,manpower:1550},
    "SP Rocket Artillery Lv2":{money:2450,food:0,metal:2450,oil:2450,manpower:1600},
    "Strategic Bomber Lv1":{money:1800,food:1600,metal:0,oil:1600,manpower:1950},
    "Strategic Bomber Lv2":{money:1950,food:1750,metal:0,oil:1750,manpower:2000},
    "Strategic Bomber Lv3":{money:2100,food:1900,metal:0,oil:1900,manpower:2000},
    "Strategic Bomber Lv4":{money:2400,food:2150,metal:0,oil:2150,manpower:2100},
    "Strategic Bomber Lv5":{money:2650,food:2400,metal:0,oil:2400,manpower:2150},
    "Strategic Bomber Lv6":{money:2950,food:2650,metal:0,oil:2650,manpower:2200},
    "Strategic Bomber Lv7":{money:3250,food:2900,metal:0,oil:2900,manpower:2250},
    "Submarine Lv1":{money:1600,food:950,metal:0,oil:950,manpower:700},
    "Submarine Lv2":{money:1700,food:1050,metal:0,oil:1050,manpower:700},
    "Submarine Lv3":{money:1900,food:1150,metal:0,oil:1150,manpower:700},
    "Submarine Lv4":{money:2200,food:1300,metal:0,oil:1300,manpower:750},
    "Submarine Lv5":{money:2550,food:1550,metal:0,oil:1550,manpower:750},
    "Submarine Lv6":{money:2850,food:1700,metal:0,oil:1700,manpower:800},
    "Tactical Bomber Lv1":{money:1600,food:2100,metal:0,oil:1300,manpower:1300},
    "Tactical Bomber Lv2":{money:1750,food:2250,metal:0,oil:1400,manpower:1300},
    "Tactical Bomber Lv3":{money:1850,food:2400,metal:0,oil:1500,manpower:1350},
    "Tactical Bomber Lv4":{money:2100,food:2750,metal:0,oil:1700,manpower:1400},
    "Tactical Bomber Lv5":{money:2350,food:3100,metal:0,oil:1900,manpower:1400},
    "Tactical Bomber Lv6":{money:2600,food:3400,metal:0,oil:2100,manpower:1450},
    "Tactical Bomber Lv7":{money:2900,food:3750,metal:0,oil:2300,manpower:1500},
    "Tank Destroyer Lv1":{money:1740,food:0,metal:1620,oil:940,manpower:940},
    "Tank Destroyer Lv2":{money:1960,food:0,metal:1790,oil:1060,manpower:980},
    "Tank Destroyer Lv3":{money:2210,food:0,metal:2040,oil:1190,manpower:980},
    "Tank Destroyer Lv4":{money:2510,food:0,metal:2300,oil:1360,manpower:1020},
    "Tank Destroyer Lv5":{money:2760,food:0,metal:2550,oil:1490,manpower:1020},
    "Tank Destroyer Lv6":{money:3020,food:0,metal:2810,oil:1620,manpower:1060},
  },
  "Comintern": {
    "Aircraft Carrier Lv1":{money:1790,food:1020,metal:890,oil:0,manpower:1280},
    "Aircraft Carrier Lv2":{money:1910,food:1110,metal:980,oil:0,manpower:1280},
    "Aircraft Carrier Lv3":{money:2210,food:1280,metal:1110,oil:0,manpower:1320},
    "Aircraft Carrier Lv4":{money:2510,food:1450,metal:1230,oil:0,manpower:1360},
    "Aircraft Carrier Lv5":{money:2930,food:1660,metal:1450,oil:0,manpower:1400},
    "Aircraft Carrier Lv6":{money:3230,food:1830,metal:1620,oil:0,manpower:1450},
    "Anti Air Lv1":{money:720,food:850,metal:510,oil:0,manpower:720},
    "Anti Air Lv2":{money:770,food:940,metal:550,oil:0,manpower:770},
    "Anti Air Lv3":{money:850,food:1020,metal:600,oil:0,manpower:770},
    "Anti Air Lv4":{money:980,food:1190,metal:680,oil:0,manpower:810},
    "Anti Air Lv5":{money:1110,food:1320,metal:770,oil:0,manpower:810},
    "Anti Air Lv6":{money:1230,food:1450,metal:850,oil:0,manpower:850},
    "Anti Tank Lv1":{money:680,food:890,metal:470,oil:0,manpower:640},
    "Anti Tank Lv2":{money:770,food:980,metal:510,oil:0,manpower:640},
    "Anti Tank Lv3":{money:850,food:1060,metal:600,oil:0,manpower:680},
    "Anti Tank Lv4":{money:940,food:1230,metal:680,oil:0,manpower:680},
    "Anti Tank Lv5":{money:1060,food:1360,metal:720,oil:0,manpower:720},
    "Anti Tank Lv6":{money:1190,food:1530,metal:810,oil:0,manpower:720},
    "Armored Car Lv1":{money:1490,food:0,metal:940,oil:850,manpower:890},
    "Armored Car Lv2":{money:1570,food:0,metal:1020,oil:890,manpower:890},
    "Armored Car Lv3":{money:1790,food:0,metal:1150,oil:1020,manpower:940},
    "Armored Car Lv4":{money:2130,food:0,metal:1360,oil:1230,manpower:940},
    "Armored Car Lv5":{money:2510,food:0,metal:1620,oil:1450,manpower:980},
    "Artillery Lv1":{money:1050,food:1350,metal:560,oil:0,manpower:830},
    "Artillery Lv2":{money:1160,food:1460,metal:640,oil:0,manpower:830},
    "Artillery Lv3":{money:1280,food:1650,metal:710,oil:0,manpower:830},
    "Artillery Lv4":{money:1460,food:1880,metal:790,oil:0,manpower:860},
    "Artillery Lv5":{money:1650,food:2100,metal:900,oil:0,manpower:900},
    "Artillery Lv6":{money:1800,food:2330,metal:980,oil:0,manpower:900},
    "Attack Bomber Lv1":{money:1230,food:890,metal:0,oil:1320,manpower:890},
    "Attack Bomber Lv2":{money:1400,food:1020,metal:0,oil:1530,manpower:940},
    "Attack Bomber Lv3":{money:1620,food:1150,metal:0,oil:1740,manpower:940},
    "Attack Bomber Lv4":{money:1910,food:1360,metal:0,oil:2080,manpower:980},
    "Attack Bomber Lv5":{money:2080,food:1530,metal:0,oil:2300,manpower:1020},
    "Battleship Lv1":{money:1530,food:770,metal:2300,oil:0,manpower:1400},
    "Battleship Lv2":{money:1660,food:810,metal:2470,oil:0,manpower:1400},
    "Battleship Lv3":{money:1910,food:940,metal:2850,oil:0,manpower:1450},
    "Battleship Lv4":{money:2130,food:1060,metal:3230,oil:0,manpower:1490},
    "Battleship Lv5":{money:2510,food:1280,metal:3780,oil:0,manpower:1530},
    "Battleship Lv6":{money:2760,food:1360,metal:4120,oil:0,manpower:1570},
    "Commandos Lv1":{money:1830,food:1830,metal:0,oil:850,manpower:890},
    "Commandos Lv2":{money:2080,food:2080,metal:0,oil:980,manpower:940},
    "Commandos Lv3":{money:2340,food:2340,metal:0,oil:1110,manpower:940},
    "Commandos Lv4":{money:2720,food:2720,metal:0,oil:1280,manpower:980},
    "Cruiser Lv1":{money:1150,food:1620,metal:940,oil:0,manpower:850},
    "Cruiser Lv2":{money:1230,food:1740,metal:980,oil:0,manpower:850},
    "Cruiser Lv3":{money:1400,food:1960,metal:1110,oil:0,manpower:890},
    "Cruiser Lv4":{money:1570,food:2210,metal:1280,oil:0,manpower:890},
    "Cruiser Lv5":{money:1870,food:2590,metal:1490,oil:0,manpower:940},
    "Cruiser Lv6":{money:2040,food:2890,metal:1660,oil:0,manpower:980},
    "Destroyer Lv1":{money:1110,food:850,metal:1020,oil:0,manpower:680},
    "Destroyer Lv2":{money:1230,food:940,metal:1110,oil:0,manpower:720},
    "Destroyer Lv3":{money:1360,food:1020,metal:1230,oil:0,manpower:720},
    "Destroyer Lv4":{money:1530,food:1150,metal:1400,oil:0,manpower:720},
    "Destroyer Lv5":{money:1830,food:1360,metal:1660,oil:0,manpower:770},
    "Destroyer Lv6":{money:2000,food:1530,metal:1870,oil:0,manpower:810},
    "Flame Tank Lv1":{money:2250,food:0,metal:2050,oil:2050,manpower:1550},
    "Flame Tank Lv2":{money:2550,food:0,metal:2350,oil:2350,manpower:1600},
    "Flame Tank Lv3":{money:2950,food:0,metal:2700,oil:2700,manpower:1650},
    "Flying Bomb Lv1":{money:640,food:0,metal:640,oil:340,manpower:170},
    "Heavy Tank Lv1":{money:2210,food:0,metal:1790,oil:2590,manpower:1110},
    "Heavy Tank Lv2":{money:2510,food:0,metal:2040,oil:2930,manpower:1150},
    "Heavy Tank Lv3":{money:2930,food:0,metal:2420,oil:3490,manpower:1190},
    "Heavy Tank Lv4":{money:3400,food:0,metal:2810,oil:4040,manpower:1230},
    "Infantry Lv1":{money:680,food:940,metal:210,oil:0,manpower:810},
    "Infantry Lv2":{money:680,food:980,metal:210,oil:0,manpower:810},
    "Infantry Lv3":{money:720,food:1020,metal:210,oil:0,manpower:810},
    "Infantry Lv4":{money:770,food:1060,metal:210,oil:0,manpower:850},
    "Infantry Lv5":{money:850,food:1190,metal:260,oil:0,manpower:850},
    "Infantry Lv6":{money:980,food:1360,metal:300,oil:0,manpower:890},
    "Infantry Lv7":{money:1060,food:1490,metal:340,oil:0,manpower:890},
    "Interceptor Lv1":{money:1280,food:810,metal:0,oil:810,manpower:680},
    "Interceptor Lv2":{money:1360,food:850,metal:0,oil:850,manpower:680},
    "Interceptor Lv3":{money:1450,food:940,metal:0,oil:940,manpower:680},
    "Interceptor Lv4":{money:1660,food:1060,metal:0,oil:1060,manpower:720},
    "Interceptor Lv5":{money:1870,food:1190,metal:0,oil:1190,manpower:720},
    "Interceptor Lv6":{money:2080,food:1360,metal:0,oil:1360,manpower:770},
    "Interceptor Lv7":{money:2300,food:1490,metal:0,oil:1490,manpower:770},
    "Light Tank Lv1":{money:940,food:0,metal:1280,oil:1150,manpower:770},
    "Light Tank Lv2":{money:1020,food:0,metal:1360,oil:1230,manpower:810},
    "Light Tank Lv3":{money:1150,food:0,metal:1530,oil:1400,manpower:810},
    "Light Tank Lv4":{money:1360,food:0,metal:1830,oil:1700,manpower:850},
    "Light Tank Lv5":{money:1620,food:0,metal:2170,oil:1960,manpower:890},
    "Mechanized Infantry Lv1":{money:1360,food:0,metal:1230,oil:1110,manpower:1060},
    "Mechanized Infantry Lv2":{money:1570,food:0,metal:1450,oil:1280,manpower:1110},
    "Mechanized Infantry Lv3":{money:1790,food:0,metal:1620,oil:1450,manpower:1110},
    "Mechanized Infantry Lv4":{money:2000,food:0,metal:1830,oil:1620,manpower:1150},
    "Mechanized Infantry Lv5":{money:2210,food:0,metal:2000,oil:1790,manpower:1190},
    "Medium Tank Lv1":{money:1490,food:0,metal:1490,oil:1620,manpower:1150},
    "Medium Tank Lv2":{money:1660,food:0,metal:1660,oil:1790,manpower:1190},
    "Medium Tank Lv3":{money:1870,food:0,metal:1870,oil:2040,manpower:1230},
    "Medium Tank Lv4":{money:2080,food:0,metal:2080,oil:2300,manpower:1230},
    "Medium Tank Lv5":{money:2340,food:0,metal:2340,oil:2550,manpower:1280},
    "Medium Tank Lv6":{money:2550,food:0,metal:2550,oil:2810,manpower:1320},
    "Militia Lv1":{money:510,food:430,metal:170,oil:0,manpower:680},
    "Militia Lv2":{money:550,food:470,metal:210,oil:0,manpower:720},
    "Militia Lv3":{money:640,food:550,metal:260,oil:0,manpower:720},
    "Militia Lv4":{money:770,food:640,metal:300,oil:0,manpower:770},
    "Motorized Infantry Lv1":{money:1060,food:850,metal:0,oil:1280,manpower:980},
    "Motorized Infantry Lv2":{money:1110,food:890,metal:0,oil:1320,manpower:980},
    "Motorized Infantry Lv3":{money:1230,food:980,metal:0,oil:1490,manpower:980},
    "Motorized Infantry Lv4":{money:1400,food:1110,metal:0,oil:1700,manpower:1020},
    "Motorized Infantry Lv5":{money:1570,food:1280,metal:0,oil:1870,manpower:1060},
    "Motorized Infantry Lv6":{money:1740,food:1400,metal:0,oil:2080,manpower:1060},
    "Naval Bomber Lv1":{money:940,food:1020,metal:0,oil:1110,manpower:600},
    "Naval Bomber Lv2":{money:980,food:1060,metal:0,oil:1150,manpower:600},
    "Naval Bomber Lv3":{money:1020,food:1150,metal:0,oil:1230,manpower:600},
    "Naval Bomber Lv4":{money:1190,food:1320,metal:0,oil:1400,manpower:640},
    "Naval Bomber Lv5":{money:1360,food:1490,metal:0,oil:1620,manpower:640},
    "Naval Bomber Lv6":{money:1490,food:1660,metal:0,oil:1790,manpower:680},
    "Naval Bomber Lv7":{money:1660,food:1830,metal:0,oil:1960,manpower:680},
    "Nuclear Bomber Lv1":{money:17890,food:2980,metal:2980,oil:7950,manpower:4850},
    "Nuclear Bomber Lv2":{money:18740,food:3150,metal:3150,oil:8330,manpower:4930},
    "Nuclear Bomber Lv3":{money:19640,food:3270,metal:3270,oil:8710,manpower:4970},
    "Nuclear Rocket Lv1":{money:20660,food:5740,metal:5740,oil:6890,manpower:3870},
    "Paratroopers Lv1":{money:2170,food:1150,metal:0,oil:1020,manpower:1150},
    "Paratroopers Lv2":{money:2470,food:1320,metal:0,oil:1150,manpower:1190},
    "Paratroopers Lv3":{money:2760,food:1490,metal:0,oil:1280,manpower:1230},
    "Paratroopers Lv4":{money:3230,food:1700,metal:0,oil:1490,manpower:1280},
    "Railroad Gun Lv1":{money:3440,food:0,metal:2890,oil:1570,manpower:2250},
    "Railroad Gun Lv2":{money:4720,food:0,metal:4000,oil:2170,manpower:2420},
    "Rocket Lv1":{money:1870,food:0,metal:680,oil:890,manpower:380},
    "Rocket Lv2":{money:2130,food:0,metal:770,oil:1020,manpower:380},
    "Rocket Lv3":{money:2380,food:0,metal:890,oil:1150,manpower:430},
    "Rocket Lv4":{money:2640,food:0,metal:980,oil:1280,manpower:430},
    "Rocket Artillery Lv1":{money:1150,food:1060,metal:1490,oil:0,manpower:850},
    "Rocket Artillery Lv2":{money:1360,food:1190,metal:1740,oil:0,manpower:850},
    "Rocket Artillery Lv3":{money:1700,food:1530,metal:2210,oil:0,manpower:890},
    "Rocket Fighter Lv1":{money:1150,food:940,metal:0,oil:1700,manpower:640},
    "Rocket Fighter Lv2":{money:1450,food:1190,metal:0,oil:2210,manpower:680},
    "SP Anti Air Lv1":{money:1190,food:770,metal:0,oil:1400,manpower:850},
    "SP Anti Air Lv2":{money:1360,food:890,metal:0,oil:1620,manpower:850},
    "SP Anti Air Lv3":{money:1570,food:980,metal:0,oil:1830,manpower:890},
    "SP Anti Air Lv4":{money:1740,food:1110,metal:0,oil:2040,manpower:890},
    "SP Anti Air Lv5":{money:1910,food:1230,metal:0,oil:2250,manpower:940},
    "SP Artillery Lv1":{money:1870,food:0,metal:1530,oil:1400,manpower:1190},
    "SP Artillery Lv2":{money:2130,food:0,metal:1790,oil:1620,manpower:1230},
    "SP Artillery Lv3":{money:2420,food:0,metal:2000,oil:1830,manpower:1230},
    "SP Artillery Lv4":{money:2680,food:0,metal:2250,oil:2000,manpower:1280},
    "SP Artillery Lv5":{money:2980,food:0,metal:2470,oil:2210,manpower:1320},
    "SP Rocket Artillery Lv1":{money:1620,food:0,metal:1620,oil:1620,manpower:1320},
    "SP Rocket Artillery Lv2":{money:2080,food:0,metal:2080,oil:2080,manpower:1360},
    "Strategic Bomber Lv1":{money:1530,food:1360,metal:0,oil:1360,manpower:1660},
    "Strategic Bomber Lv2":{money:1660,food:1490,metal:0,oil:1490,manpower:1700},
    "Strategic Bomber Lv3":{money:1790,food:1620,metal:0,oil:1620,manpower:1700},
    "Strategic Bomber Lv4":{money:2040,food:1830,metal:0,oil:1830,manpower:1790},
    "Strategic Bomber Lv5":{money:2250,food:2040,metal:0,oil:2040,manpower:1830},
    "Strategic Bomber Lv6":{money:2510,food:2250,metal:0,oil:2250,manpower:1870},
    "Strategic Bomber Lv7":{money:2760,food:2470,metal:0,oil:2470,manpower:1910},
    "Submarine Lv1":{money:1360,food:810,metal:0,oil:810,manpower:600},
    "Submarine Lv2":{money:1450,food:890,metal:0,oil:890,manpower:600},
    "Submarine Lv3":{money:1620,food:980,metal:0,oil:980,manpower:600},
    "Submarine Lv4":{money:1870,food:1110,metal:0,oil:1110,manpower:640},
    "Submarine Lv5":{money:2170,food:1320,metal:0,oil:1320,manpower:640},
    "Submarine Lv6":{money:2420,food:1450,metal:0,oil:1450,manpower:680},
    "Tactical Bomber Lv1":{money:1360,food:1790,metal:0,oil:1110,manpower:1110},
    "Tactical Bomber Lv2":{money:1490,food:1910,metal:0,oil:1190,manpower:1110},
    "Tactical Bomber Lv3":{money:1570,food:2040,metal:0,oil:1280,manpower:1150},
    "Tactical Bomber Lv4":{money:1790,food:2340,metal:0,oil:1450,manpower:1190},
    "Tactical Bomber Lv5":{money:2000,food:2640,metal:0,oil:1620,manpower:1190},
    "Tactical Bomber Lv6":{money:2210,food:2890,metal:0,oil:1790,manpower:1230},
    "Tactical Bomber Lv7":{money:2470,food:3190,metal:0,oil:1960,manpower:1280},
    "Tank Destroyer Lv1":{money:1740,food:0,metal:1620,oil:940,manpower:940},
    "Tank Destroyer Lv2":{money:1960,food:0,metal:1790,oil:1060,manpower:980},
    "Tank Destroyer Lv3":{money:2210,food:0,metal:2040,oil:1190,manpower:980},
    "Tank Destroyer Lv4":{money:2510,food:0,metal:2300,oil:1360,manpower:1020},
    "Tank Destroyer Lv5":{money:2760,food:0,metal:2550,oil:1490,manpower:1020},
    "Tank Destroyer Lv6":{money:3020,food:0,metal:2810,oil:1620,manpower:1060},
  },
  "Pan-Asian": {
    "Aircraft Carrier Lv1":{money:2100,food:1200,metal:1050,oil:0,manpower:1500},
    "Aircraft Carrier Lv2":{money:2250,food:1300,metal:1150,oil:0,manpower:1500},
    "Aircraft Carrier Lv3":{money:2600,food:1500,metal:1300,oil:0,manpower:1550},
    "Aircraft Carrier Lv4":{money:2950,food:1700,metal:1450,oil:0,manpower:1600},
    "Aircraft Carrier Lv5":{money:3450,food:1950,metal:1700,oil:0,manpower:1650},
    "Aircraft Carrier Lv6":{money:3800,food:2150,metal:1900,oil:0,manpower:1700},
    "Anti Air Lv1":{money:850,food:1000,metal:600,oil:0,manpower:850},
    "Anti Air Lv2":{money:900,food:1100,metal:650,oil:0,manpower:900},
    "Anti Air Lv3":{money:1000,food:1200,metal:700,oil:0,manpower:900},
    "Anti Air Lv4":{money:1150,food:1400,metal:800,oil:0,manpower:950},
    "Anti Air Lv5":{money:1300,food:1550,metal:900,oil:0,manpower:950},
    "Anti Air Lv6":{money:1450,food:1700,metal:1000,oil:0,manpower:1000},
    "Anti Tank Lv1":{money:800,food:1050,metal:550,oil:0,manpower:750},
    "Anti Tank Lv2":{money:900,food:1150,metal:600,oil:0,manpower:750},
    "Anti Tank Lv3":{money:1000,food:1250,metal:700,oil:0,manpower:800},
    "Anti Tank Lv4":{money:1100,food:1450,metal:800,oil:0,manpower:800},
    "Anti Tank Lv5":{money:1250,food:1600,metal:850,oil:0,manpower:850},
    "Anti Tank Lv6":{money:1400,food:1800,metal:950,oil:0,manpower:850},
    "Armored Car Lv1":{money:1750,food:0,metal:1100,oil:1000,manpower:1050},
    "Armored Car Lv2":{money:1850,food:0,metal:1200,oil:1050,manpower:1050},
    "Armored Car Lv3":{money:2100,food:0,metal:1350,oil:1200,manpower:1100},
    "Armored Car Lv4":{money:2500,food:0,metal:1600,oil:1450,manpower:1100},
    "Armored Car Lv5":{money:2950,food:0,metal:1900,oil:1700,manpower:1150},
    "Artillery Lv1":{money:1260,food:1620,metal:680,oil:0,manpower:990},
    "Artillery Lv2":{money:1400,food:1760,metal:770,oil:0,manpower:990},
    "Artillery Lv3":{money:1530,food:1980,metal:860,oil:0,manpower:990},
    "Artillery Lv4":{money:1760,food:2250,metal:950,oil:0,manpower:1040},
    "Artillery Lv5":{money:1980,food:2520,metal:1080,oil:0,manpower:1080},
    "Artillery Lv6":{money:2160,food:2790,metal:1170,oil:0,manpower:1080},
    "Attack Bomber Lv1":{money:1450,food:1050,metal:0,oil:1550,manpower:1050},
    "Attack Bomber Lv2":{money:1650,food:1200,metal:0,oil:1800,manpower:1100},
    "Attack Bomber Lv3":{money:1900,food:1350,metal:0,oil:2050,manpower:1100},
    "Attack Bomber Lv4":{money:2250,food:1600,metal:0,oil:2450,manpower:1150},
    "Attack Bomber Lv5":{money:2450,food:1800,metal:0,oil:2700,manpower:1200},
    "Battleship Lv1":{money:1800,food:900,metal:2700,oil:0,manpower:1650},
    "Battleship Lv2":{money:1950,food:950,metal:2900,oil:0,manpower:1650},
    "Battleship Lv3":{money:2250,food:1100,metal:3350,oil:0,manpower:1700},
    "Battleship Lv4":{money:2500,food:1250,metal:3800,oil:0,manpower:1750},
    "Battleship Lv5":{money:2950,food:1500,metal:4450,oil:0,manpower:1800},
    "Battleship Lv6":{money:3250,food:1600,metal:4850,oil:0,manpower:1850},
    "Commandos Lv1":{money:2150,food:2150,metal:0,oil:1000,manpower:1050},
    "Commandos Lv2":{money:2450,food:2450,metal:0,oil:1150,manpower:1100},
    "Commandos Lv3":{money:2750,food:2750,metal:0,oil:1300,manpower:1100},
    "Commandos Lv4":{money:3200,food:3200,metal:0,oil:1500,manpower:1150},
    "Cruiser Lv1":{money:1350,food:1900,metal:1100,oil:0,manpower:1000},
    "Cruiser Lv2":{money:1450,food:2050,metal:1150,oil:0,manpower:1000},
    "Cruiser Lv3":{money:1650,food:2300,metal:1300,oil:0,manpower:1050},
    "Cruiser Lv4":{money:1850,food:2600,metal:1500,oil:0,manpower:1050},
    "Cruiser Lv5":{money:2200,food:3050,metal:1750,oil:0,manpower:1100},
    "Cruiser Lv6":{money:2400,food:3400,metal:1950,oil:0,manpower:1150},
    "Destroyer Lv1":{money:1300,food:1000,metal:1200,oil:0,manpower:800},
    "Destroyer Lv2":{money:1450,food:1100,metal:1300,oil:0,manpower:850},
    "Destroyer Lv3":{money:1600,food:1200,metal:1450,oil:0,manpower:850},
    "Destroyer Lv4":{money:1800,food:1350,metal:1650,oil:0,manpower:850},
    "Destroyer Lv5":{money:2150,food:1600,metal:1950,oil:0,manpower:900},
    "Destroyer Lv6":{money:2350,food:1800,metal:2200,oil:0,manpower:950},
    "Flame Tank Lv1":{money:2250,food:0,metal:2050,oil:2050,manpower:1550},
    "Flame Tank Lv2":{money:2550,food:0,metal:2350,oil:2350,manpower:1600},
    "Flame Tank Lv3":{money:2950,food:0,metal:2700,oil:2700,manpower:1650},
    "Flying Bomb Lv1":{money:750,food:0,metal:750,oil:400,manpower:200},
    "Heavy Tank Lv1":{money:2600,food:0,metal:2100,oil:3050,manpower:1300},
    "Heavy Tank Lv2":{money:2950,food:0,metal:2400,oil:3450,manpower:1350},
    "Heavy Tank Lv3":{money:3450,food:0,metal:2850,oil:4100,manpower:1400},
    "Heavy Tank Lv4":{money:4000,food:0,metal:3300,oil:4750,manpower:1450},
    "Infantry Lv1":{money:800,food:1100,metal:250,oil:0,manpower:950},
    "Infantry Lv2":{money:800,food:1150,metal:250,oil:0,manpower:950},
    "Infantry Lv3":{money:850,food:1200,metal:250,oil:0,manpower:950},
    "Infantry Lv4":{money:900,food:1250,metal:250,oil:0,manpower:1000},
    "Infantry Lv5":{money:1000,food:1400,metal:300,oil:0,manpower:1000},
    "Infantry Lv6":{money:1150,food:1600,metal:350,oil:0,manpower:1050},
    "Infantry Lv7":{money:1250,food:1750,metal:400,oil:0,manpower:1050},
    "Interceptor Lv1":{money:1500,food:950,metal:0,oil:950,manpower:800},
    "Interceptor Lv2":{money:1600,food:1000,metal:0,oil:1000,manpower:800},
    "Interceptor Lv3":{money:1700,food:1100,metal:0,oil:1100,manpower:800},
    "Interceptor Lv4":{money:1950,food:1250,metal:0,oil:1250,manpower:850},
    "Interceptor Lv5":{money:2200,food:1400,metal:0,oil:1400,manpower:850},
    "Interceptor Lv6":{money:2450,food:1600,metal:0,oil:1600,manpower:900},
    "Interceptor Lv7":{money:2700,food:1750,metal:0,oil:1750,manpower:900},
    "Light Tank Lv1":{money:1100,food:0,metal:1500,oil:1350,manpower:900},
    "Light Tank Lv2":{money:1200,food:0,metal:1600,oil:1450,manpower:950},
    "Light Tank Lv3":{money:1350,food:0,metal:1800,oil:1650,manpower:950},
    "Light Tank Lv4":{money:1600,food:0,metal:2150,oil:2000,manpower:1000},
    "Light Tank Lv5":{money:1900,food:0,metal:2550,oil:2300,manpower:1050},
    "Mechanized Infantry Lv1":{money:1600,food:0,metal:1450,oil:1300,manpower:1250},
    "Mechanized Infantry Lv2":{money:1850,food:0,metal:1700,oil:1500,manpower:1300},
    "Mechanized Infantry Lv3":{money:2100,food:0,metal:1900,oil:1700,manpower:1300},
    "Mechanized Infantry Lv4":{money:2350,food:0,metal:2150,oil:1900,manpower:1350},
    "Mechanized Infantry Lv5":{money:2600,food:0,metal:2350,oil:2100,manpower:1400},
    "Medium Tank Lv1":{money:1750,food:0,metal:1750,oil:1900,manpower:1350},
    "Medium Tank Lv2":{money:1950,food:0,metal:1950,oil:2100,manpower:1400},
    "Medium Tank Lv3":{money:2200,food:0,metal:2200,oil:2400,manpower:1450},
    "Medium Tank Lv4":{money:2450,food:0,metal:2450,oil:2700,manpower:1450},
    "Medium Tank Lv5":{money:2750,food:0,metal:2750,oil:3000,manpower:1500},
    "Medium Tank Lv6":{money:3000,food:0,metal:3000,oil:3300,manpower:1550},
    "Militia Lv1":{money:600,food:500,metal:200,oil:0,manpower:800},
    "Militia Lv2":{money:650,food:550,metal:250,oil:0,manpower:850},
    "Militia Lv3":{money:750,food:650,metal:300,oil:0,manpower:850},
    "Militia Lv4":{money:900,food:750,metal:350,oil:0,manpower:900},
    "Motorized Infantry Lv1":{money:1250,food:1000,metal:0,oil:1500,manpower:1150},
    "Motorized Infantry Lv2":{money:1300,food:1050,metal:0,oil:1550,manpower:1150},
    "Motorized Infantry Lv3":{money:1450,food:1150,metal:0,oil:1750,manpower:1150},
    "Motorized Infantry Lv4":{money:1650,food:1300,metal:0,oil:2000,manpower:1200},
    "Motorized Infantry Lv5":{money:1850,food:1500,metal:0,oil:2200,manpower:1250},
    "Motorized Infantry Lv6":{money:2050,food:1650,metal:0,oil:2450,manpower:1250},
    "Naval Bomber Lv1":{money:1100,food:1200,metal:0,oil:1300,manpower:700},
    "Naval Bomber Lv2":{money:1150,food:1250,metal:0,oil:1350,manpower:700},
    "Naval Bomber Lv3":{money:1200,food:1350,metal:0,oil:1450,manpower:700},
    "Naval Bomber Lv4":{money:1400,food:1550,metal:0,oil:1650,manpower:750},
    "Naval Bomber Lv5":{money:1600,food:1750,metal:0,oil:1900,manpower:750},
    "Naval Bomber Lv6":{money:1750,food:1950,metal:0,oil:2100,manpower:800},
    "Naval Bomber Lv7":{money:1950,food:2150,metal:0,oil:2300,manpower:800},
    "Nuclear Bomber Lv1":{money:21050,food:3500,metal:3500,oil:9350,manpower:5700},
    "Nuclear Bomber Lv2":{money:22050,food:3700,metal:3700,oil:9800,manpower:5800},
    "Nuclear Bomber Lv3":{money:23100,food:3850,metal:3850,oil:10250,manpower:5850},
    "Nuclear Rocket Lv1":{money:24300,food:6750,metal:6750,oil:8100,manpower:4550},
    "Paratroopers Lv1":{money:2550,food:1350,metal:0,oil:1200,manpower:1350},
    "Paratroopers Lv2":{money:2900,food:1550,metal:0,oil:1350,manpower:1400},
    "Paratroopers Lv3":{money:3250,food:1750,metal:0,oil:1500,manpower:1450},
    "Paratroopers Lv4":{money:3800,food:2000,metal:0,oil:1750,manpower:1500},
    "Railroad Gun Lv1":{money:4050,food:0,metal:3400,oil:1850,manpower:2650},
    "Railroad Gun Lv2":{money:5550,food:0,metal:4700,oil:2550,manpower:2850},
    "Rocket Lv1":{money:2200,food:0,metal:800,oil:1050,manpower:450},
    "Rocket Lv2":{money:2500,food:0,metal:900,oil:1200,manpower:450},
    "Rocket Lv3":{money:2800,food:0,metal:1050,oil:1350,manpower:500},
    "Rocket Lv4":{money:3100,food:0,metal:1150,oil:1500,manpower:500},
    "Rocket Artillery Lv1":{money:1350,food:1250,metal:1750,oil:0,manpower:1000},
    "Rocket Artillery Lv2":{money:1600,food:1400,metal:2050,oil:0,manpower:1000},
    "Rocket Artillery Lv3":{money:2000,food:1800,metal:2600,oil:0,manpower:1050},
    "Rocket Fighter Lv1":{money:1350,food:1100,metal:0,oil:2000,manpower:750},
    "Rocket Fighter Lv2":{money:1700,food:1400,metal:0,oil:2600,manpower:800},
    "SP Anti Air Lv1":{money:1400,food:900,metal:0,oil:1650,manpower:1000},
    "SP Anti Air Lv2":{money:1600,food:1050,metal:0,oil:1900,manpower:1000},
    "SP Anti Air Lv3":{money:1850,food:1150,metal:0,oil:2150,manpower:1050},
    "SP Anti Air Lv4":{money:2050,food:1300,metal:0,oil:2400,manpower:1050},
    "SP Anti Air Lv5":{money:2250,food:1450,metal:0,oil:2650,manpower:1100},
    "SP Artillery Lv1":{money:2200,food:0,metal:1800,oil:1650,manpower:1400},
    "SP Artillery Lv2":{money:2500,food:0,metal:2100,oil:1900,manpower:1450},
    "SP Artillery Lv3":{money:2850,food:0,metal:2350,oil:2150,manpower:1450},
    "SP Artillery Lv4":{money:3150,food:0,metal:2650,oil:2350,manpower:1500},
    "SP Artillery Lv5":{money:3500,food:0,metal:2900,oil:2600,manpower:1550},
    "SP Rocket Artillery Lv1":{money:1900,food:0,metal:1900,oil:1900,manpower:1550},
    "SP Rocket Artillery Lv2":{money:2450,food:0,metal:2450,oil:2450,manpower:1600},
    "Strategic Bomber Lv1":{money:1800,food:1600,metal:0,oil:1600,manpower:1950},
    "Strategic Bomber Lv2":{money:1950,food:1750,metal:0,oil:1750,manpower:2000},
    "Strategic Bomber Lv3":{money:2100,food:1900,metal:0,oil:1900,manpower:2000},
    "Strategic Bomber Lv4":{money:2400,food:2150,metal:0,oil:2150,manpower:2100},
    "Strategic Bomber Lv5":{money:2650,food:2400,metal:0,oil:2400,manpower:2150},
    "Strategic Bomber Lv6":{money:2950,food:2650,metal:0,oil:2650,manpower:2200},
    "Strategic Bomber Lv7":{money:3250,food:2900,metal:0,oil:2900,manpower:2250},
    "Submarine Lv1":{money:1600,food:950,metal:0,oil:950,manpower:700},
    "Submarine Lv2":{money:1700,food:1050,metal:0,oil:1050,manpower:700},
    "Submarine Lv3":{money:1900,food:1150,metal:0,oil:1150,manpower:700},
    "Submarine Lv4":{money:2200,food:1300,metal:0,oil:1300,manpower:750},
    "Submarine Lv5":{money:2550,food:1550,metal:0,oil:1550,manpower:750},
    "Submarine Lv6":{money:2850,food:1700,metal:0,oil:1700,manpower:800},
    "Tactical Bomber Lv1":{money:1600,food:2100,metal:0,oil:1300,manpower:1300},
    "Tactical Bomber Lv2":{money:1750,food:2250,metal:0,oil:1400,manpower:1300},
    "Tactical Bomber Lv3":{money:1850,food:2400,metal:0,oil:1500,manpower:1350},
    "Tactical Bomber Lv4":{money:2100,food:2750,metal:0,oil:1700,manpower:1400},
    "Tactical Bomber Lv5":{money:2350,food:3100,metal:0,oil:1900,manpower:1400},
    "Tactical Bomber Lv6":{money:2600,food:3400,metal:0,oil:2100,manpower:1450},
    "Tactical Bomber Lv7":{money:2900,food:3750,metal:0,oil:2300,manpower:1500},
    "Tank Destroyer Lv1":{money:2050,food:0,metal:1900,oil:1100,manpower:1100},
    "Tank Destroyer Lv2":{money:2300,food:0,metal:2100,oil:1250,manpower:1150},
    "Tank Destroyer Lv3":{money:2600,food:0,metal:2400,oil:1400,manpower:1150},
    "Tank Destroyer Lv4":{money:2950,food:0,metal:2700,oil:1600,manpower:1200},
    "Tank Destroyer Lv5":{money:3250,food:0,metal:3000,oil:1750,manpower:1200},
    "Tank Destroyer Lv6":{money:3550,food:0,metal:3300,oil:1900,manpower:1250},
  },
};

// Upgrade costs per doctrine (from Excel, exact values)
const UPGRADES = {
  "Pan-Asian": {
    "INF lv1→4":  {money:400, food:600, metal:125,oil:0,  manpower:475},
    "INT lv1→3":  {money:800, food:500, metal:0,  oil:500, manpower:400},
    "AC lv1→3":   {money:950, food:0,   metal:600,oil:550, manpower:550},
    "LT lv1→3":   {money:600, food:0,   metal:800,oil:750, manpower:475},
    "AB lv1→2":   {money:850, food:600, metal:0,  oil:900, manpower:550},
    "RA lv1→2":   {money:800, food:700, metal:1050,oil:0, manpower:500},
    "TB lv1→3":   {money:900, food:1150,metal:0,  oil:700, manpower:650},
  },
  "Axis": {
    "INF lv1→4":  {money:440, food:650, metal:140,oil:0,   manpower:550},
    "INT lv1→3":  {money:900, food:550, metal:0,  oil:550,  manpower:440},
    "AC lv1→3":   {money:950, food:0,   metal:600,oil:550,  manpower:600},
    "LT lv1→3":   {money:600, food:0,   metal:850,oil:750,  manpower:495},
    "AB lv1→2":   {money:800, food:600, metal:0,  oil:850,  manpower:600},
    "RA lv1→2":   {money:750, food:700, metal:950,oil:0,    manpower:550},
    "MT lv1→2":   {money:1075,food:0,   metal:1075,oil:1155,manpower:770},
    "TB lv1→3":   {money:900, food:1150,metal:0,  oil:700,  manpower:700},
  },
  "Allies": {
    "INF lv1→4":  {money:320, food:460, metal:100,oil:0,   manpower:380},
    "INT lv1→3":  {money:640, food:400, metal:0,  oil:400, manpower:320},
    "AC lv1→3":   {money:760, food:0,   metal:480,oil:440, manpower:440},
    "LT lv1→3":   {money:480, food:0,   metal:640,oil:600, manpower:380},
    "AB lv1→2":   {money:680, food:480, metal:0,  oil:720, manpower:440},
    "RA lv1→2":   {money:640, food:560, metal:840,oil:0,   manpower:400},
    "TB lv1→3":   {money:720, food:920, metal:0,  oil:560, manpower:520},
  },
  "Comintern": {
    "INF lv1→4":  {money:340, food:490, metal:105,oil:0,   manpower:405},
    "INT lv1→3":  {money:700, food:425, metal:0,  oil:425, manpower:340},
    "AC lv1→3":   {money:800, food:0,   metal:500,oil:445, manpower:445},
    "LT lv1→3":   {money:500, food:0,   metal:700,oil:600, manpower:405},
    "AB lv1→2":   {money:700, food:500, metal:0,  oil:750, manpower:470},
    "RA lv1→2":   {money:700, food:600, metal:850,oil:0,   manpower:425},
    "TB lv1→3":   {money:700, food:900, metal:0,  oil:550, manpower:550},
  },
};

// Research costs — all tiers, per faction
const UNITS_RESEARCH=[
  {id:"CV1",name:"Aircraft Carrier 1",costs:{"Allies":{money:5550,food:1650,metal:1450,oil:0},"Axis":{money:7400,food:2200,metal:1900,oil:0},"Comintern":{money:7400,food:2200,metal:1900,oil:0},"Pan-Asian":{money:7400,food:2200,metal:1900,oil:0}}},
  {id:"CV2",name:"Aircraft Carrier 2",costs:{"Allies":{money:6700,food:1900,metal:1700,oil:0},"Axis":{money:8900,food:2550,metal:2250,oil:0},"Comintern":{money:8900,food:2550,metal:2250,oil:0},"Pan-Asian":{money:8900,food:2550,metal:2250,oil:0}}},
  {id:"CV3",name:"Aircraft Carrier 3",costs:{"Allies":{money:8950,food:2500,metal:2200,oil:0},"Axis":{money:11950,food:3350,metal:2900,oil:0},"Comintern":{money:11950,food:3350,metal:2900,oil:0},"Pan-Asian":{money:11950,food:3350,metal:2900,oil:0}}},
  {id:"CV4",name:"Aircraft Carrier 4",costs:{"Allies":{money:11200,food:3100,metal:2700,oil:0},"Axis":{money:14950,food:4100,metal:3600,oil:0},"Comintern":{money:14950,food:4100,metal:3600,oil:0},"Pan-Asian":{money:14950,food:4100,metal:3600,oil:0}}},
  {id:"CV5",name:"Aircraft Carrier 5",costs:{"Allies":{money:14650,food:3950,metal:3450,oil:0},"Axis":{money:19500,food:5250,metal:4600,oil:0},"Comintern":{money:19500,food:5250,metal:4600,oil:0},"Pan-Asian":{money:19500,food:5250,metal:4600,oil:0}}},
  {id:"CV6",name:"Aircraft Carrier 6",costs:{"Allies":{money:16900,food:4500,metal:3950,oil:0},"Axis":{money:22500,food:6000,metal:5250,oil:0},"Comintern":{money:22500,food:6000,metal:5250,oil:0},"Pan-Asian":{money:22500,food:6000,metal:5250,oil:0}}},
  {id:"AA1",name:"Anti Air 1",costs:{"Allies":{money:2050,food:1300,metal:750,oil:0},"Axis":{money:2750,food:1750,metal:1000,oil:0},"Comintern":{money:2750,food:1750,metal:1000,oil:0},"Pan-Asian":{money:2750,food:1750,metal:1000,oil:0}}},
  {id:"AA2",name:"Anti Air 2",costs:{"Allies":{money:2550,food:1600,metal:900,oil:0},"Axis":{money:3400,food:2100,metal:1200,oil:0},"Comintern":{money:3400,food:2100,metal:1200,oil:0},"Pan-Asian":{money:3400,food:2100,metal:1200,oil:0}}},
  {id:"AA3",name:"Anti Air 3",costs:{"Allies":{money:3250,food:1950,metal:1150,oil:0},"Axis":{money:4350,food:2600,metal:1500,oil:0},"Comintern":{money:4350,food:2600,metal:1500,oil:0},"Pan-Asian":{money:4350,food:2600,metal:1500,oil:0}}},
  {id:"AA4",name:"Anti Air 4",costs:{"Allies":{money:4200,food:2450,metal:1450,oil:0},"Axis":{money:5600,food:3250,metal:1900,oil:0},"Comintern":{money:5600,food:3250,metal:1900,oil:0},"Pan-Asian":{money:5600,food:3250,metal:1900,oil:0}}},
  {id:"AA5",name:"Anti Air 5",costs:{"Allies":{money:5150,food:2950,metal:1750,oil:0},"Axis":{money:6850,food:3950,metal:2300,oil:0},"Comintern":{money:6850,food:3950,metal:2300,oil:0},"Pan-Asian":{money:6850,food:3950,metal:2300,oil:0}}},
  {id:"AA6",name:"Anti Air 6",costs:{"Allies":{money:6100,food:3450,metal:2050,oil:0},"Axis":{money:8100,food:4600,metal:2700,oil:0},"Comintern":{money:8100,food:4600,metal:2700,oil:0},"Pan-Asian":{money:8100,food:4600,metal:2700,oil:0}}},
  {id:"AT1",name:"Anti Tank 1",costs:{"Allies":{money:2000,food:1350,metal:750,oil:0},"Axis":{money:2650,food:1800,metal:1000,oil:0},"Comintern":{money:2650,food:1800,metal:1000,oil:0},"Pan-Asian":{money:2650,food:1800,metal:1000,oil:0}}},
  {id:"AT2",name:"Anti Tank 2",costs:{"Allies":{money:2450,food:1600,metal:850,oil:0},"Axis":{money:3250,food:2150,metal:1150,oil:0},"Comintern":{money:3250,food:2150,metal:1150,oil:0},"Pan-Asian":{money:3250,food:2150,metal:1150,oil:0}}},
  {id:"AT3",name:"Anti Tank 3",costs:{"Allies":{money:3150,food:2050,metal:1100,oil:0},"Axis":{money:4200,food:2700,metal:1450,oil:0},"Comintern":{money:4200,food:2700,metal:1450,oil:0},"Pan-Asian":{money:4200,food:2700,metal:1450,oil:0}}},
  {id:"AT4",name:"Anti Tank 4",costs:{"Allies":{money:4050,food:2550,metal:1400,oil:0},"Axis":{money:5400,food:3400,metal:1850,oil:0},"Comintern":{money:5400,food:3400,metal:1850,oil:0},"Pan-Asian":{money:5400,food:3400,metal:1850,oil:0}}},
  {id:"AT5",name:"Anti Tank 5",costs:{"Allies":{money:4950,food:3100,metal:1650,oil:0},"Axis":{money:6600,food:4100,metal:2200,oil:0},"Comintern":{money:6600,food:4100,metal:2200,oil:0},"Pan-Asian":{money:6600,food:4100,metal:2200,oil:0}}},
  {id:"AT6",name:"Anti Tank 6",costs:{"Allies":{money:5900,food:3600,metal:1950,oil:0},"Axis":{money:7850,food:4800,metal:2600,oil:0},"Comintern":{money:7850,food:4800,metal:2600,oil:0},"Pan-Asian":{money:7850,food:4800,metal:2600,oil:0}}},
  {id:"AC1",name:"Armored Car 1",costs:{"Allies":{money:4300,food:0,metal:1450,oil:1300},"Axis":{money:5700,food:0,metal:1900,oil:1700},"Comintern":{money:5700,food:0,metal:1900,oil:1700},"Pan-Asian":{money:5700,food:0,metal:1900,oil:1700}}},
  {id:"AC2",name:"Armored Car 2",costs:{"Allies":{money:5250,food:0,metal:1750,oil:1550},"Axis":{money:7000,food:0,metal:2300,oil:2050},"Comintern":{money:7000,food:0,metal:2300,oil:2050},"Pan-Asian":{money:7000,food:0,metal:2300,oil:2050}}},
  {id:"AC3",name:"Armored Car 3",costs:{"Allies":{money:6700,food:0,metal:2150,oil:1900},"Axis":{money:8950,food:0,metal:2850,oil:2550},"Comintern":{money:8950,food:0,metal:2850,oil:2550},"Pan-Asian":{money:8950,food:0,metal:2850,oil:2550}}},
  {id:"AC4",name:"Armored Car 4",costs:{"Allies":{money:9650,food:0,metal:2950,oil:2650},"Axis":{money:12850,food:0,metal:3950,oil:3500},"Comintern":{money:12850,food:0,metal:3950,oil:3500},"Pan-Asian":{money:12850,food:0,metal:3950,oil:3500}}},
  {id:"AC5",name:"Armored Car 5",costs:{"Allies":{money:12550,food:0,metal:3850,oil:3400},"Axis":{money:16750,food:0,metal:5100,oil:4500},"Comintern":{money:16750,food:0,metal:5100,oil:4500},"Pan-Asian":{money:16750,food:0,metal:5100,oil:4500}}},
  {id:"ARTY1",name:"Artillery 1",costs:{"Allies":{money:3500,food:2350,metal:1000,oil:0},"Axis":{money:4650,food:3100,metal:1350,oil:0},"Comintern":{money:4650,food:3100,metal:1350,oil:0},"Pan-Asian":{money:4650,food:3100,metal:1350,oil:0}}},
  {id:"ARTY2",name:"Artillery 2",costs:{"Allies":{money:4300,food:2800,metal:1200,oil:0},"Axis":{money:5750,food:3700,metal:1600,oil:0},"Comintern":{money:5750,food:3700,metal:1600,oil:0},"Pan-Asian":{money:5750,food:3700,metal:1600,oil:0}}},
  {id:"ARTY3",name:"Artillery 3",costs:{"Allies":{money:5500,food:3500,metal:1500,oil:0},"Axis":{money:7350,food:4650,metal:2000,oil:0},"Comintern":{money:7350,food:4650,metal:2000,oil:0},"Pan-Asian":{money:7350,food:4650,metal:2000,oil:0}}},
  {id:"ARTY4",name:"Artillery 4",costs:{"Allies":{money:7100,food:4400,metal:1900,oil:0},"Axis":{money:9450,food:5850,metal:2500,oil:0},"Comintern":{money:9450,food:5850,metal:2500,oil:0},"Pan-Asian":{money:9450,food:5850,metal:2500,oil:0}}},
  {id:"ARTY5",name:"Artillery 5",costs:{"Allies":{money:8700,food:5300,metal:2250,oil:0},"Axis":{money:11600,food:7050,metal:3000,oil:0},"Comintern":{money:11600,food:7050,metal:3000,oil:0},"Pan-Asian":{money:11600,food:7050,metal:3000,oil:0}}},
  {id:"ARTY6",name:"Artillery 6",costs:{"Allies":{money:10300,food:6200,metal:2650,oil:0},"Axis":{money:13700,food:8250,metal:3550,oil:0},"Comintern":{money:13700,food:8250,metal:3550,oil:0},"Pan-Asian":{money:13700,food:8250,metal:3550,oil:0}}},
  {id:"ATOM1",name:"Atomic Bomb 1",costs:{"Allies":{money:7500,food:1150,metal:3750,oil:1900},"Axis":{money:10000,food:1500,metal:5000,oil:2500},"Comintern":{money:10000,food:1500,metal:5000,oil:2500},"Pan-Asian":{money:10000,food:1500,metal:5000,oil:2500}}},
  {id:"ATOM2",name:"Atomic Bomb 2",costs:{"Allies":{money:9400,food:1500,metal:5250,oil:2650},"Axis":{money:12500,food:2000,metal:7000,oil:3500},"Comintern":{money:12500,food:2000,metal:7000,oil:3500},"Pan-Asian":{money:12500,food:2000,metal:7000,oil:3500}}},
  {id:"ATOM3",name:"Atomic Bomb 3",costs:{"Allies":{money:12000,food:2250,metal:7500,oil:3750},"Axis":{money:16000,food:3000,metal:10000,oil:5000},"Comintern":{money:16000,food:3000,metal:10000,oil:5000},"Pan-Asian":{money:16000,food:3000,metal:10000,oil:5000}}},
  {id:"AB1",name:"Attack Bomber 1",costs:{"Allies":{money:3800,food:1450,metal:0,oil:2150},"Axis":{money:5050,food:1900,metal:0,oil:2850},"Comintern":{money:5050,food:1900,metal:0,oil:2850},"Pan-Asian":{money:5050,food:1900,metal:0,oil:2850}}},
  {id:"AB2",name:"Attack Bomber 2",costs:{"Allies":{money:5350,food:1900,metal:0,oil:2900},"Axis":{money:7100,food:2550,metal:0,oil:3850},"Comintern":{money:7100,food:2550,metal:0,oil:3850},"Pan-Asian":{money:7100,food:2550,metal:0,oil:3850}}},
  {id:"AB3",name:"Attack Bomber 3",costs:{"Allies":{money:6850,food:2400,metal:0,oil:3650},"Axis":{money:9150,food:3200,metal:0,oil:4850},"Comintern":{money:9150,food:3200,metal:0,oil:4850},"Pan-Asian":{money:9150,food:3200,metal:0,oil:4850}}},
  {id:"AB4",name:"Attack Bomber 4",costs:{"Allies":{money:9200,food:3150,metal:0,oil:4750},"Axis":{money:12250,food:4200,metal:0,oil:6350},"Comintern":{money:12250,food:4200,metal:0,oil:6350},"Pan-Asian":{money:12250,food:4200,metal:0,oil:6350}}},
  {id:"AB5",name:"Attack Bomber 5",costs:{"Allies":{money:10750,food:3700,metal:0,oil:5500},"Axis":{money:14300,food:4900,metal:0,oil:7350},"Comintern":{money:14300,food:4900,metal:0,oil:7350},"Pan-Asian":{money:14300,food:4900,metal:0,oil:7350}}},
  {id:"BB1",name:"Battleship 1",costs:{"Allies":{money:4750,food:1250,metal:3700,oil:0},"Axis":{money:6350,food:1650,metal:4900,oil:0},"Comintern":{money:6350,food:1650,metal:4900,oil:0},"Pan-Asian":{money:6350,food:1650,metal:4900,oil:0}}},
  {id:"BB2",name:"Battleship 2",costs:{"Allies":{money:5750,food:1450,metal:4350,oil:0},"Axis":{money:7650,food:1950,metal:5800,oil:0},"Comintern":{money:7650,food:1950,metal:5800,oil:0},"Pan-Asian":{money:7650,food:1950,metal:5800,oil:0}}},
  {id:"BB3",name:"Battleship 3",costs:{"Allies":{money:7650,food:1900,metal:5650,oil:0},"Axis":{money:10200,food:2500,metal:7500,oil:0},"Comintern":{money:10200,food:2500,metal:7500,oil:0},"Pan-Asian":{money:10200,food:2500,metal:7500,oil:0}}},
  {id:"BB4",name:"Battleship 4",costs:{"Allies":{money:9600,food:2350,metal:6950,oil:0},"Axis":{money:12800,food:3100,metal:9250,oil:0},"Comintern":{money:12800,food:3100,metal:9250,oil:0},"Pan-Asian":{money:12800,food:3100,metal:9250,oil:0}}},
  {id:"BB5",name:"Battleship 5",costs:{"Allies":{money:12550,food:2950,metal:8900,oil:0},"Axis":{money:16700,food:3950,metal:11850,oil:0},"Comintern":{money:16700,food:3950,metal:11850,oil:0},"Pan-Asian":{money:16700,food:3950,metal:11850,oil:0}}},
  {id:"BB6",name:"Battleship 6",costs:{"Allies":{money:14500,food:3400,metal:10150,oil:0},"Axis":{money:19300,food:4500,metal:13550,oil:0},"Comintern":{money:19300,food:4500,metal:13550,oil:0},"Pan-Asian":{money:19300,food:4500,metal:13550,oil:0}}},
  {id:"CMD1",name:"Commandos 1",costs:{"Allies":{money:6950,food:3450,metal:0,oil:1600},"Axis":{money:9250,food:4600,metal:0,oil:2100},"Comintern":{money:9250,food:4600,metal:0,oil:2100},"Pan-Asian":{money:9250,food:4600,metal:0,oil:2100}}},
  {id:"CMD2",name:"Commandos 2",costs:{"Allies":{money:8950,food:4350,metal:0,oil:2000},"Axis":{money:11950,food:5800,metal:0,oil:2650},"Comintern":{money:11950,food:5800,metal:0,oil:2650},"Pan-Asian":{money:11950,food:5800,metal:0,oil:2650}}},
  {id:"CMD3",name:"Commandos 3",costs:{"Allies":{money:11000,food:5250,metal:0,oil:2450},"Axis":{money:14650,food:7000,metal:0,oil:3250},"Comintern":{money:14650,food:7000,metal:0,oil:3250},"Pan-Asian":{money:14650,food:7000,metal:0,oil:3250}}},
  {id:"CMD4",name:"Commandos 4",costs:{"Allies":{money:14050,food:6600,metal:0,oil:3050},"Axis":{money:18700,food:8800,metal:0,oil:4050},"Comintern":{money:18700,food:8800,metal:0,oil:4050},"Pan-Asian":{money:18700,food:8800,metal:0,oil:4050}}},
  {id:"CL1",name:"Cruiser 1",costs:{"Allies":{money:3350,food:2450,metal:1400,oil:0},"Axis":{money:4450,food:3250,metal:1850,oil:0},"Comintern":{money:4450,food:3250,metal:1850,oil:0},"Pan-Asian":{money:4450,food:3250,metal:1850,oil:0}}},
  {id:"CL2",name:"Cruiser 2",costs:{"Allies":{money:4100,food:2950,metal:1700,oil:0},"Axis":{money:5450,food:3900,metal:2250,oil:0},"Comintern":{money:5450,food:3900,metal:2250,oil:0},"Pan-Asian":{money:5450,food:3900,metal:2250,oil:0}}},
  {id:"CL3",name:"Cruiser 3",costs:{"Allies":{money:5250,food:3650,metal:2050,oil:0},"Axis":{money:7000,food:4850,metal:2750,oil:0},"Comintern":{money:7000,food:4850,metal:2750,oil:0},"Pan-Asian":{money:7000,food:4850,metal:2750,oil:0}}},
  {id:"CL4",name:"Cruiser 4",costs:{"Allies":{money:6750,food:4600,metal:2650,oil:0},"Axis":{money:9000,food:6100,metal:3500,oil:0},"Comintern":{money:9000,food:6100,metal:3500,oil:0},"Pan-Asian":{money:9000,food:6100,metal:3500,oil:0}}},
  {id:"CL5",name:"Cruiser 5",costs:{"Allies":{money:9050,food:6000,metal:3400,oil:0},"Axis":{money:12050,food:8000,metal:4550,oil:0},"Comintern":{money:12050,food:8000,metal:4550,oil:0},"Pan-Asian":{money:12050,food:8000,metal:4550,oil:0}}},
  {id:"CL6",name:"Cruiser 6",costs:{"Allies":{money:10550,food:6950,metal:4000,oil:0},"Axis":{money:14050,food:9250,metal:5300,oil:0},"Comintern":{money:14050,food:9250,metal:5300,oil:0},"Pan-Asian":{money:14050,food:9250,metal:5300,oil:0}}},
  {id:"DD1",name:"Destroyer 1",costs:{"Allies":{money:3250,food:1300,metal:1600,oil:0},"Axis":{money:4350,food:1700,metal:2100,oil:0},"Comintern":{money:4350,food:1700,metal:2100,oil:0},"Pan-Asian":{money:4350,food:1700,metal:2100,oil:0}}},
  {id:"DD2",name:"Destroyer 2",costs:{"Allies":{money:4000,food:1550,metal:1900,oil:0},"Axis":{money:5350,food:2050,metal:2500,oil:0},"Comintern":{money:5350,food:2050,metal:2500,oil:0},"Pan-Asian":{money:5350,food:2050,metal:2500,oil:0}}},
  {id:"DD3",name:"Destroyer 3",costs:{"Allies":{money:5150,food:1900,metal:2350,oil:0},"Axis":{money:6850,food:2550,metal:3100,oil:0},"Comintern":{money:6850,food:2550,metal:3100,oil:0},"Pan-Asian":{money:6850,food:2550,metal:3100,oil:0}}},
  {id:"DD4",name:"Destroyer 4",costs:{"Allies":{money:6650,food:2400,metal:2950,oil:0},"Axis":{money:8850,food:3200,metal:3900,oil:0},"Comintern":{money:8850,food:3200,metal:3900,oil:0},"Pan-Asian":{money:8850,food:3200,metal:3900,oil:0}}},
  {id:"DD5",name:"Destroyer 5",costs:{"Allies":{money:8850,food:3150,metal:3850,oil:0},"Axis":{money:11800,food:4200,metal:5150,oil:0},"Comintern":{money:11800,food:4200,metal:5150,oil:0},"Pan-Asian":{money:11800,food:4200,metal:5150,oil:0}}},
  {id:"DD6",name:"Destroyer 6",costs:{"Allies":{money:10350,food:3650,metal:4450,oil:0},"Axis":{money:13800,food:4850,metal:5950,oil:0},"Comintern":{money:13800,food:4850,metal:5950,oil:0},"Pan-Asian":{money:13800,food:4850,metal:5950,oil:0}}},
  {id:"FB1",name:"Flying Bomb 1",costs:{"Allies":{money:1900,food:0,metal:1000,oil:550},"Axis":{money:2550,food:0,metal:1300,oil:750},"Comintern":{money:2550,food:0,metal:1300,oil:750},"Pan-Asian":{money:2550,food:0,metal:1300,oil:750}}},
  {id:"HT1",name:"Heavy Tank 1",costs:{"Allies":{money:8300,food:0,metal:3400,oil:4900},"Axis":{money:11050,food:0,metal:4500,oil:6500},"Comintern":{money:11050,food:0,metal:4500,oil:6500},"Pan-Asian":{money:11050,food:0,metal:4500,oil:6500}}},
  {id:"HT2",name:"Heavy Tank 2",costs:{"Allies":{money:10700,food:0,metal:4250,oil:6100},"Axis":{money:14250,food:0,metal:5650,oil:8150},"Comintern":{money:14250,food:0,metal:5650,oil:8150},"Pan-Asian":{money:14250,food:0,metal:5650,oil:8150}}},
  {id:"HT3",name:"Heavy Tank 3",costs:{"Allies":{money:14300,food:0,metal:5550,oil:8050},"Axis":{money:19050,food:0,metal:7400,oil:10700},"Comintern":{money:19050,food:0,metal:7400,oil:10700},"Pan-Asian":{money:19050,food:0,metal:7400,oil:10700}}},
  {id:"HT4",name:"Heavy Tank 4",costs:{"Allies":{money:17950,food:0,metal:6850,oil:9900},"Axis":{money:23900,food:0,metal:9150,oil:13200},"Comintern":{money:23900,food:0,metal:9150,oil:13200},"Pan-Asian":{money:23900,food:0,metal:9150,oil:13200}}},
  {id:"INF1",name:"Infantry 1",costs:{"Allies":{money:1900,food:1450,metal:300,oil:0},"Axis":{money:2550,food:1900,metal:400,oil:0},"Comintern":{money:2550,food:1900,metal:400,oil:0},"Pan-Asian":{money:2550,food:1900,metal:400,oil:0}}},
  {id:"INF2",name:"Infantry 2",costs:{"Allies":{money:2150,food:1550,metal:350,oil:0},"Axis":{money:2850,food:2050,metal:450,oil:0},"Comintern":{money:2850,food:2050,metal:450,oil:0},"Pan-Asian":{money:2850,food:2050,metal:450,oil:0}}},
  {id:"INF3",name:"Infantry 3",costs:{"Allies":{money:2350,food:1700,metal:400,oil:0},"Axis":{money:3150,food:2250,metal:500,oil:0},"Comintern":{money:3150,food:2250,metal:500,oil:0},"Pan-Asian":{money:3150,food:2250,metal:500,oil:0}}},
  {id:"INF4",name:"Infantry 4",costs:{"Allies":{money:2600,food:1850,metal:400,oil:0},"Axis":{money:3450,food:2450,metal:500,oil:0},"Comintern":{money:3450,food:2450,metal:500,oil:0},"Pan-Asian":{money:3450,food:2450,metal:500,oil:0}}},
  {id:"INF5",name:"Infantry 5",costs:{"Allies":{money:3450,food:2350,metal:550,oil:0},"Axis":{money:4600,food:3150,metal:700,oil:0},"Comintern":{money:4600,food:3150,metal:700,oil:0},"Pan-Asian":{money:4600,food:3150,metal:700,oil:0}}},
  {id:"INF6",name:"Infantry 6",costs:{"Allies":{money:4350,food:2950,metal:650,oil:0},"Axis":{money:5800,food:3900,metal:850,oil:0},"Comintern":{money:5800,food:3900,metal:850,oil:0},"Pan-Asian":{money:5800,food:3900,metal:850,oil:0}}},
  {id:"INF7",name:"Infantry 7",costs:{"Allies":{money:5200,food:3450,metal:750,oil:0},"Axis":{money:6950,food:4600,metal:1000,oil:0},"Comintern":{money:6950,food:4600,metal:1000,oil:0},"Pan-Asian":{money:6950,food:4600,metal:1000,oil:0}}},
  {id:"INT1",name:"Interceptor 1",costs:{"Allies":{money:3750,food:1300,metal:0,oil:1300},"Axis":{money:5000,food:1700,metal:0,oil:1700},"Comintern":{money:5000,food:1700,metal:0,oil:1700},"Pan-Asian":{money:5000,food:1700,metal:0,oil:1700}}},
  {id:"INT2",name:"Interceptor 2",costs:{"Allies":{money:4150,food:1400,metal:0,oil:1400},"Axis":{money:5550,food:1850,metal:0,oil:1850},"Comintern":{money:5550,food:1850,metal:0,oil:1850},"Pan-Asian":{money:5550,food:1850,metal:0,oil:1850}}},
  {id:"INT3",name:"Interceptor 3",costs:{"Allies":{money:5050,food:1600,metal:0,oil:1600},"Axis":{money:6700,food:2150,metal:0,oil:2150},"Comintern":{money:6700,food:2150,metal:0,oil:2150},"Pan-Asian":{money:6700,food:2150,metal:0,oil:2150}}},
  {id:"INT4",name:"Interceptor 4",costs:{"Allies":{money:6700,food:2100,metal:0,oil:2100},"Axis":{money:8950,food:2800,metal:0,oil:2800},"Comintern":{money:8950,food:2800,metal:0,oil:2800},"Pan-Asian":{money:8950,food:2800,metal:0,oil:2800}}},
  {id:"INT5",name:"Interceptor 5",costs:{"Allies":{money:8400,food:2600,metal:0,oil:2600},"Axis":{money:11200,food:3450,metal:0,oil:3450},"Comintern":{money:11200,food:3450,metal:0,oil:3450},"Pan-Asian":{money:11200,food:3450,metal:0,oil:3450}}},
  {id:"INT6",name:"Interceptor 6",costs:{"Allies":{money:10150,food:3100,metal:0,oil:3100},"Axis":{money:13500,food:4100,metal:0,oil:4100},"Comintern":{money:13500,food:4100,metal:0,oil:4100},"Pan-Asian":{money:13500,food:4100,metal:0,oil:4100}}},
  {id:"INT7",name:"Interceptor 7",costs:{"Allies":{money:11800,food:3550,metal:0,oil:3550},"Axis":{money:15750,food:4750,metal:0,oil:4750},"Comintern":{money:15750,food:4750,metal:0,oil:4750},"Pan-Asian":{money:15750,food:4750,metal:0,oil:4750}}},
  {id:"LT1",name:"Light Tank 1",costs:{"Allies":{money:3050,food:0,metal:1900,oil:1450},"Axis":{money:4050,food:0,metal:2550,oil:1900},"Comintern":{money:4050,food:0,metal:2550,oil:1900},"Pan-Asian":{money:4050,food:0,metal:2550,oil:1900}}},
  {id:"LT2",name:"Light Tank 2",costs:{"Allies":{money:3750,food:0,metal:2300,oil:1750},"Axis":{money:5000,food:0,metal:3050,oil:2300},"Comintern":{money:5000,food:0,metal:3050,oil:2300},"Pan-Asian":{money:5000,food:0,metal:3050,oil:2300}}},
  {id:"LT3",name:"Light Tank 3",costs:{"Allies":{money:4800,food:0,metal:2850,oil:2150},"Axis":{money:6400,food:0,metal:3800,oil:2850},"Comintern":{money:6400,food:0,metal:3800,oil:2850},"Pan-Asian":{money:6400,food:0,metal:3800,oil:2850}}},
  {id:"LT4",name:"Light Tank 4",costs:{"Allies":{money:6850,food:0,metal:4000,oil:2950},"Axis":{money:9150,food:0,metal:5300,oil:3950},"Comintern":{money:9150,food:0,metal:5300,oil:3950},"Pan-Asian":{money:9150,food:0,metal:5300,oil:3950}}},
  {id:"LT5",name:"Light Tank 5",costs:{"Allies":{money:8950,food:0,metal:5050,oil:3850},"Axis":{money:11950,food:0,metal:6750,oil:5100},"Comintern":{money:11950,food:0,metal:6750,oil:5100},"Pan-Asian":{money:11950,food:0,metal:6750,oil:5100}}},
  {id:"MI1",name:"Mechanized Infantry 1",costs:{"Allies":{money:4750,food:0,metal:2200,oil:1950},"Axis":{money:6350,food:0,metal:2900,oil:2600},"Comintern":{money:6350,food:0,metal:2900,oil:2600},"Pan-Asian":{money:6350,food:0,metal:2900,oil:2600}}},
  {id:"MI2",name:"Mechanized Infantry 2",costs:{"Allies":{money:6400,food:0,metal:2850,oil:2550},"Axis":{money:8500,food:0,metal:3800,oil:3400},"Comintern":{money:8500,food:0,metal:3800,oil:3400},"Pan-Asian":{money:8500,food:0,metal:3800,oil:3400}}},
  {id:"MI3",name:"Mechanized Infantry 3",costs:{"Allies":{money:8000,food:0,metal:3500,oil:3150},"Axis":{money:10650,food:0,metal:4650,oil:4200},"Comintern":{money:10650,food:0,metal:4650,oil:4200},"Pan-Asian":{money:10650,food:0,metal:4650,oil:4200}}},
  {id:"MI4",name:"Mechanized Infantry 4",costs:{"Allies":{money:9650,food:0,metal:4150,oil:3750},"Axis":{money:12850,food:0,metal:5550,oil:5000},"Comintern":{money:12850,food:0,metal:5550,oil:5000},"Pan-Asian":{money:12850,food:0,metal:5550,oil:5000}}},
  {id:"MI5",name:"Mechanized Infantry 5",costs:{"Allies":{money:11250,food:0,metal:4800,oil:4300},"Axis":{money:15000,food:0,metal:6400,oil:5750},"Comintern":{money:15000,food:0,metal:6400,oil:5750},"Pan-Asian":{money:15000,food:0,metal:6400,oil:5750}}},
  {id:"MT1",name:"Medium Tank 1",costs:{"Allies":{money:4850,food:0,metal:2500,oil:2700},"Axis":{money:6450,food:0,metal:3300,oil:3600},"Comintern":{money:6450,food:0,metal:3300,oil:3600},"Pan-Asian":{money:6450,food:0,metal:3300,oil:3600}}},
  {id:"MT2",name:"Medium Tank 2",costs:{"Allies":{money:6200,food:0,metal:3100,oil:3400},"Axis":{money:8250,food:0,metal:4100,oil:4500},"Comintern":{money:8250,food:0,metal:4100,oil:4500},"Pan-Asian":{money:8250,food:0,metal:4100,oil:4500}}},
  {id:"MT3",name:"Medium Tank 3",costs:{"Allies":{money:8000,food:0,metal:3850,oil:4250},"Axis":{money:10650,food:0,metal:5150,oil:5650},"Comintern":{money:10650,food:0,metal:5150,oil:5650},"Pan-Asian":{money:10650,food:0,metal:5150,oil:5650}}},
  {id:"MT4",name:"Medium Tank 4",costs:{"Allies":{money:9800,food:0,metal:4650,oil:5150},"Axis":{money:13050,food:0,metal:6200,oil:6850},"Comintern":{money:13050,food:0,metal:6200,oil:6850},"Pan-Asian":{money:13050,food:0,metal:6200,oil:6850}}},
  {id:"MT5",name:"Medium Tank 5",costs:{"Allies":{money:11600,food:0,metal:5500,oil:6000},"Axis":{money:15450,food:0,metal:7300,oil:8000},"Comintern":{money:15450,food:0,metal:7300,oil:8000},"Pan-Asian":{money:15450,food:0,metal:7300,oil:8000}}},
  {id:"MT6",name:"Medium Tank 6",costs:{"Allies":{money:13350,food:0,metal:6250,oil:6900},"Axis":{money:17800,food:0,metal:8350,oil:9200},"Comintern":{money:17800,food:0,metal:8350,oil:9200},"Pan-Asian":{money:17800,food:0,metal:8350,oil:9200}}},
  {id:"MLT1",name:"Militia 1",costs:{"Allies":{money:1450,food:650,metal:250,oil:0},"Axis":{money:1950,food:850,metal:350,oil:0},"Comintern":{money:1950,food:850,metal:350,oil:0},"Pan-Asian":{money:1950,food:850,metal:350,oil:0}}},
  {id:"MLT2",name:"Militia 2",costs:{"Allies":{money:1800,food:750,metal:350,oil:0},"Axis":{money:2400,food:1000,metal:450,oil:0},"Comintern":{money:2400,food:1000,metal:450,oil:0},"Pan-Asian":{money:2400,food:1000,metal:450,oil:0}}},
  {id:"MLT3",name:"Militia 3",costs:{"Allies":{money:2650,food:1050,metal:500,oil:0},"Axis":{money:3500,food:1400,metal:650,oil:0},"Comintern":{money:3500,food:1400,metal:650,oil:0},"Pan-Asian":{money:3500,food:1400,metal:650,oil:0}}},
  {id:"MLT4",name:"Militia 4",costs:{"Allies":{money:3650,food:1450,metal:650,oil:0},"Axis":{money:4850,food:1900,metal:850,oil:0},"Comintern":{money:4850,food:1900,metal:850,oil:0},"Pan-Asian":{money:4850,food:1900,metal:850,oil:0}}},
  {id:"MOT1",name:"Motorized Infantry 1",costs:{"Allies":{money:3300,food:1350,metal:0,oil:2050},"Axis":{money:4400,food:1800,metal:0,oil:2750},"Comintern":{money:4400,food:1800,metal:0,oil:2750},"Pan-Asian":{money:4400,food:1800,metal:0,oil:2750}}},
  {id:"MOT2",name:"Motorized Infantry 2",costs:{"Allies":{money:3650,food:1500,metal:0,oil:2200},"Axis":{money:4850,food:2000,metal:0,oil:2950},"Comintern":{money:4850,food:2000,metal:0,oil:2950},"Pan-Asian":{money:4850,food:2000,metal:0,oil:2950}}},
  {id:"MOT3",name:"Motorized Infantry 3",costs:{"Allies":{money:4650,food:1850,metal:0,oil:2800},"Axis":{money:6200,food:2450,metal:0,oil:3700},"Comintern":{money:6200,food:2450,metal:0,oil:3700},"Pan-Asian":{money:6200,food:2450,metal:0,oil:3700}}},
  {id:"MOT4",name:"Motorized Infantry 4",costs:{"Allies":{money:6000,food:2350,metal:0,oil:3500},"Axis":{money:8000,food:3100,metal:0,oil:4650},"Comintern":{money:8000,food:3100,metal:0,oil:4650},"Pan-Asian":{money:8000,food:3100,metal:0,oil:4650}}},
  {id:"MOT5",name:"Motorized Infantry 5",costs:{"Allies":{money:7350,food:2800,metal:0,oil:4200},"Axis":{money:9800,food:3750,metal:0,oil:5600},"Comintern":{money:9800,food:3750,metal:0,oil:5600},"Pan-Asian":{money:9800,food:3750,metal:0,oil:5600}}},
  {id:"MOT6",name:"Motorized Infantry 6",costs:{"Allies":{money:8700,food:3300,metal:0,oil:4900},"Axis":{money:11600,food:4400,metal:0,oil:6550},"Comintern":{money:11600,food:4400,metal:0,oil:6550},"Pan-Asian":{money:11600,food:4400,metal:0,oil:6550}}},
  {id:"NB1",name:"Naval Bomber 1",costs:{"Allies":{money:2650,food:1550,metal:0,oil:1700},"Axis":{money:3550,food:2050,metal:0,oil:2250},"Comintern":{money:3550,food:2050,metal:0,oil:2250},"Pan-Asian":{money:3550,food:2050,metal:0,oil:2250}}},
  {id:"NB2",name:"Naval Bomber 2",costs:{"Allies":{money:2950,food:1700,metal:0,oil:1850},"Axis":{money:3950,food:2250,metal:0,oil:2450},"Comintern":{money:3950,food:2250,metal:0,oil:2450},"Pan-Asian":{money:3950,food:2250,metal:0,oil:2450}}},
  {id:"NB3",name:"Naval Bomber 3",costs:{"Allies":{money:3550,food:2000,metal:0,oil:2200},"Axis":{money:4750,food:2650,metal:0,oil:2900},"Comintern":{money:4750,food:2650,metal:0,oil:2900},"Pan-Asian":{money:4750,food:2650,metal:0,oil:2900}}},
  {id:"NB4",name:"Naval Bomber 4",costs:{"Allies":{money:4800,food:2600,metal:0,oil:2800},"Axis":{money:6400,food:3450,metal:0,oil:3750},"Comintern":{money:6400,food:3450,metal:0,oil:3750},"Pan-Asian":{money:6400,food:3450,metal:0,oil:3750}}},
  {id:"NB5",name:"Naval Bomber 5",costs:{"Allies":{money:6000,food:3200,metal:0,oil:3450},"Axis":{money:8000,food:4250,metal:0,oil:4600},"Comintern":{money:8000,food:4250,metal:0,oil:4600},"Pan-Asian":{money:8000,food:4250,metal:0,oil:4600}}},
  {id:"NB6",name:"Naval Bomber 6",costs:{"Allies":{money:7250,food:3750,metal:0,oil:4150},"Axis":{money:9650,food:5000,metal:0,oil:5500},"Comintern":{money:9650,food:5000,metal:0,oil:5500},"Pan-Asian":{money:9650,food:5000,metal:0,oil:5500}}},
  {id:"NB7",name:"Naval Bomber 7",costs:{"Allies":{money:8450,food:4350,metal:0,oil:4750},"Axis":{money:11250,food:5800,metal:0,oil:6350},"Comintern":{money:11250,food:5800,metal:0,oil:6350},"Pan-Asian":{money:11250,food:5800,metal:0,oil:6350}}},
  {id:"NBMB1",name:"Nuclear Bomber 1",costs:{"Allies":{money:18750,food:4500,metal:6750,oil:4500},"Axis":{money:25000,food:6000,metal:9000,oil:6000},"Comintern":{money:25000,food:6000,metal:9000,oil:6000},"Pan-Asian":{money:25000,food:6000,metal:9000,oil:6000}}},
  {id:"NBMB2",name:"Nuclear Bomber 2",costs:{"Allies":{money:21000,food:5650,metal:8250,oil:5650},"Axis":{money:28000,food:7500,metal:11000,oil:7500},"Comintern":{money:28000,food:7500,metal:11000,oil:7500},"Pan-Asian":{money:28000,food:7500,metal:11000,oil:7500}}},
  {id:"NBMB3",name:"Nuclear Bomber 3",costs:{"Allies":{money:25500,food:7150,metal:10500,oil:7150},"Axis":{money:34000,food:9500,metal:14000,oil:9500},"Comintern":{money:34000,food:9500,metal:14000,oil:9500},"Pan-Asian":{money:34000,food:9500,metal:14000,oil:9500}}},
  {id:"NRKT1",name:"Nuclear Rocket 1",costs:{"Allies":{money:30000,food:8250,metal:12750,oil:8250},"Axis":{money:40000,food:11000,metal:17000,oil:11000},"Comintern":{money:40000,food:11000,metal:17000,oil:11000},"Pan-Asian":{money:40000,food:11000,metal:17000,oil:11000}}},
  {id:"PARA1",name:"Paratroopers 1",costs:{"Allies":{money:8200,food:2200,metal:0,oil:1900},"Axis":{money:10950,food:2900,metal:0,oil:2550},"Comintern":{money:10950,food:2900,metal:0,oil:2550},"Pan-Asian":{money:10950,food:2900,metal:0,oil:2550}}},
  {id:"PARA2",name:"Paratroopers 2",costs:{"Allies":{money:10600,food:2750,metal:0,oil:2400},"Axis":{money:14100,food:3650,metal:0,oil:3200},"Comintern":{money:14100,food:3650,metal:0,oil:3200},"Pan-Asian":{money:14100,food:3650,metal:0,oil:3200}}},
  {id:"PARA3",name:"Paratroopers 3",costs:{"Allies":{money:12950,food:3300,metal:0,oil:2900},"Axis":{money:17250,food:4400,metal:0,oil:3850},"Comintern":{money:17250,food:4400,metal:0,oil:3850},"Pan-Asian":{money:17250,food:4400,metal:0,oil:3850}}},
  {id:"PARA4",name:"Paratroopers 4",costs:{"Allies":{money:16550,food:4150,metal:0,oil:3650},"Axis":{money:22050,food:5500,metal:0,oil:4850},"Comintern":{money:22050,food:5500,metal:0,oil:4850},"Pan-Asian":{money:22050,food:5500,metal:0,oil:4850}}},
  {id:"RRG1",name:"Railroad Gun 1",costs:{"Allies":{money:11900,food:0,metal:5050,oil:2800},"Axis":{money:15850,food:0,metal:6750,oil:3700},"Comintern":{money:15850,food:0,metal:6750,oil:3700},"Pan-Asian":{money:15850,food:0,metal:6750,oil:3700}}},
  {id:"RRG2",name:"Railroad Gun 2",costs:{"Allies":{money:22000,food:0,metal:8900,oil:4850},"Axis":{money:29300,food:0,metal:11850,oil:6450},"Comintern":{money:29300,food:0,metal:11850,oil:6450},"Pan-Asian":{money:29300,food:0,metal:11850,oil:6450}}},
  {id:"RKT1",name:"Rocket 1",costs:{"Allies":{money:7050,food:0,metal:1300,oil:1650},"Axis":{money:9400,food:0,metal:1700,oil:2200},"Comintern":{money:9400,food:0,metal:1700,oil:2200},"Pan-Asian":{money:9400,food:0,metal:1700,oil:2200}}},
  {id:"RKT2",name:"Rocket 2",costs:{"Allies":{money:9100,food:0,metal:1600,oil:2100},"Axis":{money:12150,food:0,metal:2150,oil:2800},"Comintern":{money:12150,food:0,metal:2150,oil:2800},"Pan-Asian":{money:12150,food:0,metal:2150,oil:2800}}},
  {id:"RKT3",name:"Rocket 3",costs:{"Allies":{money:11200,food:0,metal:1950,oil:2500},"Axis":{money:14900,food:0,metal:2600,oil:3350},"Comintern":{money:14900,food:0,metal:2600,oil:3350},"Pan-Asian":{money:14900,food:0,metal:2600,oil:3350}}},
  {id:"RKT4",name:"Rocket 4",costs:{"Allies":{money:13250,food:0,metal:2300,oil:2950},"Axis":{money:17650,food:0,metal:3050,oil:3950},"Comintern":{money:17650,food:0,metal:3050,oil:3950},"Pan-Asian":{money:17650,food:0,metal:3050,oil:3950}}},
  {id:"RA1",name:"Rocket Artillery 1",costs:{"Allies":{money:3600,food:1700,metal:2400,oil:0},"Axis":{money:4800,food:2250,metal:3200,oil:0},"Comintern":{money:4800,food:2250,metal:3200,oil:0},"Pan-Asian":{money:4800,food:2250,metal:3200,oil:0}}},
  {id:"RA2",name:"Rocket Artillery 2",costs:{"Allies":{money:5050,food:2250,metal:3250,oil:0},"Axis":{money:6750,food:3000,metal:4350,oil:0},"Comintern":{money:6750,food:3000,metal:4350,oil:0},"Pan-Asian":{money:6750,food:3000,metal:4350,oil:0}}},
  {id:"RA3",name:"Rocket Artillery 3",costs:{"Allies":{money:8050,food:3450,metal:4950,oil:0},"Axis":{money:10700,food:4600,metal:6600,oil:0},"Comintern":{money:10700,food:4600,metal:6600,oil:0},"Pan-Asian":{money:10700,food:4600,metal:6600,oil:0}}},
  {id:"RF1",name:"Rocket Fighter 1",costs:{"Allies":{money:4300,food:1750,metal:0,oil:3250},"Axis":{money:5750,food:2300,metal:0,oil:4300},"Comintern":{money:5750,food:2300,metal:0,oil:4300},"Pan-Asian":{money:5750,food:2300,metal:0,oil:4300}}},
  {id:"RF2",name:"Rocket Fighter 2",costs:{"Allies":{money:6850,food:2650,metal:0,oil:4900},"Axis":{money:9100,food:3500,metal:0,oil:6500},"Comintern":{money:9100,food:3500,metal:0,oil:6500},"Pan-Asian":{money:9100,food:3500,metal:0,oil:6500}}},
  {id:"SPAA1",name:"SP Anti Air 1",costs:{"Allies":{money:4150,food:1350,metal:0,oil:2500},"Axis":{money:5550,food:1800,metal:0,oil:3300},"Comintern":{money:5550,food:1800,metal:0,oil:3300},"Pan-Asian":{money:5550,food:1800,metal:0,oil:3300}}},
  {id:"SPAA2",name:"SP Anti Air 2",costs:{"Allies":{money:5550,food:1750,metal:0,oil:3250},"Axis":{money:7400,food:2300,metal:0,oil:4300},"Comintern":{money:7400,food:2300,metal:0,oil:4300},"Pan-Asian":{money:7400,food:2300,metal:0,oil:4300}}},
  {id:"SPAA3",name:"SP Anti Air 3",costs:{"Allies":{money:7000,food:2150,metal:0,oil:4000},"Axis":{money:9300,food:2850,metal:0,oil:5300},"Comintern":{money:9300,food:2850,metal:0,oil:5300},"Pan-Asian":{money:9300,food:2850,metal:0,oil:5300}}},
  {id:"SPAA4",name:"SP Anti Air 4",costs:{"Allies":{money:8400,food:2500,metal:0,oil:4700},"Axis":{money:11200,food:3350,metal:0,oil:6250},"Comintern":{money:11200,food:3350,metal:0,oil:6250},"Pan-Asian":{money:11200,food:3350,metal:0,oil:6250}}},
  {id:"SPAA5",name:"SP Anti Air 5",costs:{"Allies":{money:9800,food:2950,metal:0,oil:5450},"Axis":{money:13050,food:3900,metal:0,oil:7250},"Comintern":{money:13050,food:3900,metal:0,oil:7250},"Pan-Asian":{money:13050,food:3900,metal:0,oil:7250}}},
  {id:"SPA1",name:"SP Artillery 1",costs:{"Allies":{money:6450,food:0,metal:2700,oil:2450},"Axis":{money:8600,food:0,metal:3600,oil:3250},"Comintern":{money:8600,food:0,metal:3600,oil:3250},"Pan-Asian":{money:8600,food:0,metal:3600,oil:3250}}},
  {id:"SPA2",name:"SP Artillery 2",costs:{"Allies":{money:8650,food:0,metal:3550,oil:3150},"Axis":{money:11500,food:0,metal:4700,oil:4200},"Comintern":{money:11500,food:0,metal:4700,oil:4200},"Pan-Asian":{money:11500,food:0,metal:4700,oil:4200}}},
  {id:"SPA3",name:"SP Artillery 3",costs:{"Allies":{money:10800,food:0,metal:4300,oil:3900},"Axis":{money:14400,food:0,metal:5750,oil:5200},"Comintern":{money:14400,food:0,metal:5750,oil:5200},"Pan-Asian":{money:14400,food:0,metal:5750,oil:5200}}},
  {id:"SPA4",name:"SP Artillery 4",costs:{"Allies":{money:13000,food:0,metal:5150,oil:4600},"Axis":{money:17350,food:0,metal:6850,oil:6150},"Comintern":{money:17350,food:0,metal:6850,oil:6150},"Pan-Asian":{money:17350,food:0,metal:6850,oil:6150}}},
  {id:"SPA5",name:"SP Artillery 5",costs:{"Allies":{money:15200,food:0,metal:5950,oil:5350},"Axis":{money:20250,food:0,metal:7950,oil:7150},"Comintern":{money:20250,food:0,metal:7950,oil:7150},"Pan-Asian":{money:20250,food:0,metal:7950,oil:7150}}},
  {id:"SPRA1",name:"SP Rocket Artillery 1",costs:{"Allies":{money:6150,food:0,metal:3050,oil:3050},"Axis":{money:8200,food:0,metal:4050,oil:4050},"Comintern":{money:8200,food:0,metal:4050,oil:4050},"Pan-Asian":{money:8200,food:0,metal:4050,oil:4050}}},
  {id:"SPRA2",name:"SP Rocket Artillery 2",costs:{"Allies":{money:9700,food:0,metal:4600,oil:4600},"Axis":{money:12950,food:0,metal:6150,oil:6150},"Comintern":{money:12950,food:0,metal:6150,oil:6150},"Pan-Asian":{money:12950,food:0,metal:6150,oil:6150}}},
  {id:"SB1",name:"Strategic Bomber 1",costs:{"Allies":{money:4750,food:2200,metal:0,oil:2200},"Axis":{money:6350,food:2950,metal:0,oil:2950},"Comintern":{money:6350,food:2950,metal:0,oil:2950},"Pan-Asian":{money:6350,food:2950,metal:0,oil:2950}}},
  {id:"SB2",name:"Strategic Bomber 2",costs:{"Allies":{money:5750,food:2600,metal:0,oil:2600},"Axis":{money:7650,food:3450,metal:0,oil:3450},"Comintern":{money:7650,food:3450,metal:0,oil:3450},"Pan-Asian":{money:7650,food:3450,metal:0,oil:3450}}},
  {id:"SB3",name:"Strategic Bomber 3",costs:{"Allies":{money:6700,food:3000,metal:0,oil:3000},"Axis":{money:8950,food:4000,metal:0,oil:4000},"Comintern":{money:8950,food:4000,metal:0,oil:4000},"Pan-Asian":{money:8950,food:4000,metal:0,oil:4000}}},
  {id:"SB4",name:"Strategic Bomber 4",costs:{"Allies":{money:8650,food:3750,metal:0,oil:3750},"Axis":{money:11500,food:5000,metal:0,oil:5000},"Comintern":{money:11500,food:5000,metal:0,oil:5000},"Pan-Asian":{money:11500,food:5000,metal:0,oil:5000}}},
  {id:"SB5",name:"Strategic Bomber 5",costs:{"Allies":{money:10600,food:4550,metal:0,oil:4550},"Axis":{money:14100,food:6050,metal:0,oil:6050},"Comintern":{money:14100,food:6050,metal:0,oil:6050},"Pan-Asian":{money:14100,food:6050,metal:0,oil:6050}}},
  {id:"SB6",name:"Strategic Bomber 6",costs:{"Allies":{money:12550,food:5350,metal:0,oil:5350},"Axis":{money:16700,food:7100,metal:0,oil:7100},"Comintern":{money:16700,food:7100,metal:0,oil:7100},"Pan-Asian":{money:16700,food:7100,metal:0,oil:7100}}},
  {id:"SB7",name:"Strategic Bomber 7",costs:{"Allies":{money:14500,food:6100,metal:0,oil:6100},"Axis":{money:19300,food:8150,metal:0,oil:8150},"Comintern":{money:19300,food:8150,metal:0,oil:8150},"Pan-Asian":{money:19300,food:8150,metal:0,oil:8150}}},
  {id:"SS1",name:"Submarine 1",costs:{"Allies":{money:3900,food:1250,metal:0,oil:1250},"Axis":{money:5200,food:1650,metal:0,oil:1650},"Comintern":{money:5200,food:1650,metal:0,oil:1650},"Pan-Asian":{money:5200,food:1650,metal:0,oil:1650}}},
  {id:"SS2",name:"Submarine 2",costs:{"Allies":{money:4800,food:1450,metal:0,oil:1450},"Axis":{money:6400,food:1950,metal:0,oil:1950},"Comintern":{money:6400,food:1950,metal:0,oil:1950},"Pan-Asian":{money:6400,food:1950,metal:0,oil:1950}}},
  {id:"SS3",name:"Submarine 3",costs:{"Allies":{money:6150,food:1850,metal:0,oil:1850},"Axis":{money:8200,food:2450,metal:0,oil:2450},"Comintern":{money:8200,food:2450,metal:0,oil:2450},"Pan-Asian":{money:8200,food:2450,metal:0,oil:2450}}},
  {id:"SS4",name:"Submarine 4",costs:{"Allies":{money:7900,food:2300,metal:0,oil:2300},"Axis":{money:10550,food:3050,metal:0,oil:3050},"Comintern":{money:10550,food:3050,metal:0,oil:3050},"Pan-Asian":{money:10550,food:3050,metal:0,oil:3050}}},
  {id:"SS5",name:"Submarine 5",costs:{"Allies":{money:10600,food:3000,metal:0,oil:3000},"Axis":{money:14100,food:4000,metal:0,oil:4000},"Comintern":{money:14100,food:4000,metal:0,oil:4000},"Pan-Asian":{money:14100,food:4000,metal:0,oil:4000}}},
  {id:"SS6",name:"Submarine 6",costs:{"Allies":{money:12400,food:3500,metal:0,oil:3500},"Axis":{money:16500,food:4650,metal:0,oil:4650},"Comintern":{money:16500,food:4650,metal:0,oil:4650},"Pan-Asian":{money:16500,food:4650,metal:0,oil:4650}}},
  {id:"TB1",name:"Tactical Bomber 1",costs:{"Allies":{money:4250,food:2850,metal:0,oil:1750},"Axis":{money:5650,food:3800,metal:0,oil:2350},"Comintern":{money:5650,food:3800,metal:0,oil:2350},"Pan-Asian":{money:5650,food:3800,metal:0,oil:2350}}},
  {id:"TB2",name:"Tactical Bomber 2",costs:{"Allies":{money:5100,food:3350,metal:0,oil:2050},"Axis":{money:6800,food:4450,metal:0,oil:2750},"Comintern":{money:6800,food:4450,metal:0,oil:2750},"Pan-Asian":{money:6800,food:4450,metal:0,oil:2750}}},
  {id:"TB3",name:"Tactical Bomber 3",costs:{"Allies":{money:5950,food:3850,metal:0,oil:2350},"Axis":{money:7950,food:5100,metal:0,oil:3150},"Comintern":{money:7950,food:5100,metal:0,oil:3150},"Pan-Asian":{money:7950,food:5100,metal:0,oil:3150}}},
  {id:"TB4",name:"Tactical Bomber 4",costs:{"Allies":{money:7700,food:4850,metal:0,oil:2950},"Axis":{money:10250,food:6450,metal:0,oil:3950},"Comintern":{money:10250,food:6450,metal:0,oil:3950},"Pan-Asian":{money:10250,food:6450,metal:0,oil:3950}}},
  {id:"TB5",name:"Tactical Bomber 5",costs:{"Allies":{money:9400,food:5850,metal:0,oil:3600},"Axis":{money:12550,food:7800,metal:0,oil:4800},"Comintern":{money:12550,food:7800,metal:0,oil:4800},"Pan-Asian":{money:12550,food:7800,metal:0,oil:4800}}},
  {id:"TB6",name:"Tactical Bomber 6",costs:{"Allies":{money:11150,food:6850,metal:0,oil:4200},"Axis":{money:14850,food:9100,metal:0,oil:5600},"Comintern":{money:14850,food:9100,metal:0,oil:5600},"Pan-Asian":{money:14850,food:9100,metal:0,oil:5600}}},
  {id:"TB7",name:"Tactical Bomber 7",costs:{"Allies":{money:12850,food:7850,metal:0,oil:4850},"Axis":{money:17150,food:10450,metal:0,oil:6450},"Comintern":{money:17150,food:10450,metal:0,oil:6450},"Pan-Asian":{money:17150,food:10450,metal:0,oil:6450}}},
  {id:"TD1",name:"Tank Destroyer 1",costs:{"Allies":{money:5800,food:0,metal:2700,oil:1600},"Axis":{money:7700,food:0,metal:3600,oil:2100},"Comintern":{money:7700,food:0,metal:3600,oil:2100},"Pan-Asian":{money:7700,food:0,metal:3600,oil:2100}}},
  {id:"TD2",name:"Tank Destroyer 2",costs:{"Allies":{money:7400,food:0,metal:3400,oil:2000},"Axis":{money:9850,food:0,metal:4500,oil:2650},"Comintern":{money:9850,food:0,metal:4500,oil:2650},"Pan-Asian":{money:9850,food:0,metal:4500,oil:2650}}},
  {id:"TD3",name:"Tank Destroyer 3",costs:{"Allies":{money:9550,food:0,metal:4250,oil:2500},"Axis":{money:12700,food:0,metal:5650,oil:3300},"Comintern":{money:12700,food:0,metal:5650,oil:3300},"Pan-Asian":{money:12700,food:0,metal:5650,oil:3300}}},
  {id:"TD4",name:"Tank Destroyer 4",costs:{"Allies":{money:11650,food:0,metal:5150,oil:3000},"Axis":{money:15550,food:0,metal:6850,oil:4000},"Comintern":{money:15550,food:0,metal:6850,oil:4000},"Pan-Asian":{money:15550,food:0,metal:6850,oil:4000}}},
  {id:"TD5",name:"Tank Destroyer 5",costs:{"Allies":{money:13800,food:0,metal:6000,oil:3550},"Axis":{money:18400,food:0,metal:8000,oil:4700},"Comintern":{money:18400,food:0,metal:8000,oil:4700},"Pan-Asian":{money:18400,food:0,metal:8000,oil:4700}}},
  {id:"TD6",name:"Tank Destroyer 6",costs:{"Allies":{money:15950,food:0,metal:6900,oil:4000},"Axis":{money:21250,food:0,metal:9200,oil:5350},"Comintern":{money:21250,food:0,metal:9200,oil:5350},"Pan-Asian":{money:21250,food:0,metal:9200,oil:5350}}},
];

const RESEARCH_CHAINS={
  "AA2":["AA1"],
  "AA3":["AA1","AA2"],
  "AA4":["AA1","AA2","AA3"],
  "AA5":["AA1","AA2","AA3","AA4"],
  "AA6":["AA1","AA2","AA3","AA4","AA5"],
  "AB2":["AB1"],
  "AB3":["AB1","AB2"],
  "AB4":["AB1","AB2","AB3"],
  "AB5":["AB1","AB2","AB3","AB4"],
  "AC2":["AC1"],
  "AC3":["AC1","AC2"],
  "AC4":["AC1","AC2","AC3"],
  "AC5":["AC1","AC2","AC3","AC4"],
  "ARTY2":["ARTY1"],
  "ARTY3":["ARTY1","ARTY2"],
  "ARTY4":["ARTY1","ARTY2","ARTY3"],
  "ARTY5":["ARTY1","ARTY2","ARTY3","ARTY4"],
  "ARTY6":["ARTY1","ARTY2","ARTY3","ARTY4","ARTY5"],
  "AT2":["AT1"],
  "AT3":["AT1","AT2"],
  "AT4":["AT1","AT2","AT3"],
  "AT5":["AT1","AT2","AT3","AT4"],
  "AT6":["AT1","AT2","AT3","AT4","AT5"],
  "ATOM2":["ATOM1"],
  "ATOM3":["ATOM1","ATOM2"],
  "BB2":["BB1"],
  "BB3":["BB1","BB2"],
  "BB4":["BB1","BB2","BB3"],
  "BB5":["BB1","BB2","BB3","BB4"],
  "BB6":["BB1","BB2","BB3","BB4","BB5"],
  "CL2":["CL1"],
  "CL3":["CL1","CL2"],
  "CL4":["CL1","CL2","CL3"],
  "CL5":["CL1","CL2","CL3","CL4"],
  "CL6":["CL1","CL2","CL3","CL4","CL5"],
  "CMD2":["CMD1"],
  "CMD3":["CMD1","CMD2"],
  "CMD4":["CMD1","CMD2","CMD3"],
  "CV2":["CV1"],
  "CV3":["CV1","CV2"],
  "CV4":["CV1","CV2","CV3"],
  "CV5":["CV1","CV2","CV3","CV4"],
  "CV6":["CV1","CV2","CV3","CV4","CV5"],
  "DD2":["DD1"],
  "DD3":["DD1","DD2"],
  "DD4":["DD1","DD2","DD3"],
  "DD5":["DD1","DD2","DD3","DD4"],
  "DD6":["DD1","DD2","DD3","DD4","DD5"],
  "HT2":["HT1"],
  "HT3":["HT1","HT2"],
  "HT4":["HT1","HT2","HT3"],
  "INF2":["INF1"],
  "INF3":["INF1","INF2"],
  "INF4":["INF1","INF2","INF3"],
  "INF5":["INF1","INF2","INF3","INF4"],
  "INF6":["INF1","INF2","INF3","INF4","INF5"],
  "INF7":["INF1","INF2","INF3","INF4","INF5","INF6"],
  "INT2":["INT1"],
  "INT3":["INT1","INT2"],
  "INT4":["INT1","INT2","INT3"],
  "INT5":["INT1","INT2","INT3","INT4"],
  "INT6":["INT1","INT2","INT3","INT4","INT5"],
  "INT7":["INT1","INT2","INT3","INT4","INT5","INT6"],
  "LT2":["LT1"],
  "LT3":["LT1","LT2"],
  "LT4":["LT1","LT2","LT3"],
  "LT5":["LT1","LT2","LT3","LT4"],
  "MI2":["MI1"],
  "MI3":["MI1","MI2"],
  "MI4":["MI1","MI2","MI3"],
  "MI5":["MI1","MI2","MI3","MI4"],
  "MLT2":["MLT1"],
  "MLT3":["MLT1","MLT2"],
  "MLT4":["MLT1","MLT2","MLT3"],
  "MOT2":["MOT1"],
  "MOT3":["MOT1","MOT2"],
  "MOT4":["MOT1","MOT2","MOT3"],
  "MOT5":["MOT1","MOT2","MOT3","MOT4"],
  "MOT6":["MOT1","MOT2","MOT3","MOT4","MOT5"],
  "MT2":["MT1"],
  "MT3":["MT1","MT2"],
  "MT4":["MT1","MT2","MT3"],
  "MT5":["MT1","MT2","MT3","MT4"],
  "MT6":["MT1","MT2","MT3","MT4","MT5"],
  "NB2":["NB1"],
  "NB3":["NB1","NB2"],
  "NB4":["NB1","NB2","NB3"],
  "NB5":["NB1","NB2","NB3","NB4"],
  "NB6":["NB1","NB2","NB3","NB4","NB5"],
  "NB7":["NB1","NB2","NB3","NB4","NB5","NB6"],
  "NBMB2":["NBMB1"],
  "NBMB3":["NBMB1","NBMB2"],
  "PARA2":["PARA1"],
  "PARA3":["PARA1","PARA2"],
  "PARA4":["PARA1","PARA2","PARA3"],
  "RA2":["RA1"],
  "RA3":["RA1","RA2"],
  "RF2":["RF1"],
  "RKT2":["RKT1"],
  "RKT3":["RKT1","RKT2"],
  "RKT4":["RKT1","RKT2","RKT3"],
  "RRG2":["RRG1"],
  "SB2":["SB1"],
  "SB3":["SB1","SB2"],
  "SB4":["SB1","SB2","SB3"],
  "SB5":["SB1","SB2","SB3","SB4"],
  "SB6":["SB1","SB2","SB3","SB4","SB5"],
  "SB7":["SB1","SB2","SB3","SB4","SB5","SB6"],
  "SPA2":["SPA1"],
  "SPA3":["SPA1","SPA2"],
  "SPA4":["SPA1","SPA2","SPA3"],
  "SPA5":["SPA1","SPA2","SPA3","SPA4"],
  "SPAA2":["SPAA1"],
  "SPAA3":["SPAA1","SPAA2"],
  "SPAA4":["SPAA1","SPAA2","SPAA3"],
  "SPAA5":["SPAA1","SPAA2","SPAA3","SPAA4"],
  "SPRA2":["SPRA1"],
  "SS2":["SS1"],
  "SS3":["SS1","SS2"],
  "SS4":["SS1","SS2","SS3"],
  "SS5":["SS1","SS2","SS3","SS4"],
  "SS6":["SS1","SS2","SS3","SS4","SS5"],
  "TB2":["TB1"],
  "TB3":["TB1","TB2"],
  "TB4":["TB1","TB2","TB3"],
  "TB5":["TB1","TB2","TB3","TB4"],
  "TB6":["TB1","TB2","TB3","TB4","TB5"],
  "TB7":["TB1","TB2","TB3","TB4","TB5","TB6"],
  "TD2":["TD1"],
  "TD3":["TD1","TD2"],
  "TD4":["TD1","TD2","TD3"],
  "TD5":["TD1","TD2","TD3","TD4"],
  "TD6":["TD1","TD2","TD3","TD4","TD5"]
};

// Upkeep costs per unit per doctrine (money/food/metal/oil/manpower per day)
const UPKEEP_COSTS = {
  "Aircraft Carrier 1":{"Axis":{money:105,food:60,metal:53,manpower:75},"Allies":{money:105,food:60,metal:53,manpower:75},"Comintern":{money:74,food:42,metal:37,manpower:53},"Pan-Asian":{money:105,food:60,metal:53,manpower:75}},
  "Aircraft Carrier 2":{"Axis":{money:113,food:65,metal:58,manpower:75},"Allies":{money:113,food:65,metal:58,manpower:75},"Comintern":{money:79,food:46,metal:41,manpower:53},"Pan-Asian":{money:113,food:65,metal:58,manpower:75}},
  "Aircraft Carrier 3":{"Axis":{money:130,food:75,metal:65,manpower:78},"Allies":{money:130,food:75,metal:65,manpower:78},"Comintern":{money:91,food:53,metal:46,manpower:55},"Pan-Asian":{money:130,food:75,metal:65,manpower:78}},
  "Aircraft Carrier 4":{"Axis":{money:148,food:85,metal:73,manpower:80},"Allies":{money:148,food:85,metal:73,manpower:80},"Comintern":{money:104,food:60,metal:51,manpower:56},"Pan-Asian":{money:148,food:85,metal:73,manpower:80}},
  "Aircraft Carrier 5":{"Axis":{money:173,food:98,metal:85,manpower:83},"Allies":{money:173,food:98,metal:85,manpower:83},"Comintern":{money:121,food:69,metal:60,manpower:58},"Pan-Asian":{money:173,food:98,metal:85,manpower:83}},
  "Aircraft Carrier 6":{"Axis":{money:190,food:108,metal:95,manpower:85},"Allies":{money:190,food:108,metal:95,manpower:85},"Comintern":{money:133,food:76,metal:67,manpower:60},"Pan-Asian":{money:190,food:108,metal:95,manpower:85}},
  "Anti Air 1":{"Axis":{money:43,food:50,metal:30,manpower:43},"Allies":{money:43,food:50,metal:30,manpower:43},"Comintern":{money:30,food:35,metal:21,manpower:30},"Pan-Asian":{money:43,food:50,metal:30,manpower:43}},
  "Anti Air 2":{"Axis":{money:45,food:55,metal:33,manpower:45},"Allies":{money:45,food:55,metal:33,manpower:45},"Comintern":{money:32,food:39,metal:23,manpower:32},"Pan-Asian":{money:45,food:55,metal:33,manpower:45}},
  "Anti Air 3":{"Axis":{money:50,food:60,metal:35,manpower:45},"Allies":{money:50,food:60,metal:35,manpower:45},"Comintern":{money:35,food:42,metal:25,manpower:32},"Pan-Asian":{money:50,food:60,metal:35,manpower:45}},
  "Anti Air 4":{"Axis":{money:58,food:70,metal:40,manpower:48},"Allies":{money:58,food:70,metal:40,manpower:48},"Comintern":{money:41,food:49,metal:28,manpower:34},"Pan-Asian":{money:58,food:70,metal:40,manpower:48}},
  "Anti Air 5":{"Axis":{money:65,food:78,metal:45,manpower:48},"Allies":{money:65,food:78,metal:45,manpower:48},"Comintern":{money:46,food:55,metal:32,manpower:34},"Pan-Asian":{money:65,food:78,metal:45,manpower:48}},
  "Anti Air 6":{"Axis":{money:73,food:85,metal:50,manpower:50},"Allies":{money:73,food:85,metal:50,manpower:50},"Comintern":{money:51,food:60,metal:35,manpower:35},"Pan-Asian":{money:73,food:85,metal:50,manpower:50}},
  "Anti Tank 1":{"Axis":{money:40,food:53,metal:28,manpower:38},"Allies":{money:40,food:53,metal:28,manpower:38},"Comintern":{money:28,food:37,metal:20,manpower:27},"Pan-Asian":{money:40,food:53,metal:28,manpower:38}},
  "Anti Tank 2":{"Axis":{money:45,food:58,metal:30,manpower:38},"Allies":{money:45,food:58,metal:30,manpower:38},"Comintern":{money:32,food:41,metal:21,manpower:27},"Pan-Asian":{money:45,food:58,metal:30,manpower:38}},
  "Anti Tank 3":{"Axis":{money:50,food:63,metal:35,manpower:40},"Allies":{money:50,food:63,metal:35,manpower:40},"Comintern":{money:35,food:44,metal:25,manpower:28},"Pan-Asian":{money:50,food:63,metal:35,manpower:40}},
  "Anti Tank 4":{"Axis":{money:55,food:73,metal:40,manpower:40},"Allies":{money:55,food:73,metal:40,manpower:40},"Comintern":{money:39,food:51,metal:28,manpower:28},"Pan-Asian":{money:55,food:73,metal:40,manpower:40}},
  "Anti Tank 5":{"Axis":{money:63,food:80,metal:43,manpower:43},"Allies":{money:63,food:80,metal:43,manpower:43},"Comintern":{money:44,food:56,metal:30,manpower:30},"Pan-Asian":{money:63,food:80,metal:43,manpower:43}},
  "Anti Tank 6":{"Axis":{money:70,food:90,metal:48,manpower:43},"Allies":{money:70,food:90,metal:48,manpower:43},"Comintern":{money:49,food:63,metal:34,manpower:30},"Pan-Asian":{money:70,food:90,metal:48,manpower:43}},
  "Armored Car 1":{"Axis":{money:88,metal:55,oil:50,manpower:53},"Allies":{money:88,metal:55,oil:50,manpower:53},"Comintern":{money:62,metal:39,oil:35,manpower:37},"Pan-Asian":{money:88,metal:55,oil:50,manpower:53}},
  "Armored Car 2":{"Axis":{money:93,metal:60,oil:53,manpower:53},"Allies":{money:93,metal:60,oil:53,manpower:53},"Comintern":{money:65,metal:42,oil:37,manpower:37},"Pan-Asian":{money:93,metal:60,oil:53,manpower:53}},
  "Armored Car 3":{"Axis":{money:105,metal:68,oil:60,manpower:55},"Allies":{money:105,metal:68,oil:60,manpower:55},"Comintern":{money:74,metal:48,oil:42,manpower:39},"Pan-Asian":{money:105,metal:68,oil:60,manpower:55}},
  "Armored Car 4":{"Axis":{money:125,metal:80,oil:73,manpower:55},"Allies":{money:125,metal:80,oil:73,manpower:55},"Comintern":{money:88,metal:56,oil:51,manpower:39},"Pan-Asian":{money:125,metal:80,oil:73,manpower:55}},
  "Armored Car 5":{"Axis":{money:148,metal:95,oil:85,manpower:58},"Allies":{money:148,metal:95,oil:85,manpower:58},"Comintern":{money:104,metal:67,oil:60,manpower:41},"Pan-Asian":{money:148,metal:95,oil:85,manpower:58}},
  "Artillery 1":{"Axis":{money:70,food:90,metal:38,manpower:55},"Allies":{money:70,food:90,metal:38,manpower:55},"Comintern":{money:49,food:63,metal:27,manpower:39},"Pan-Asian":{money:70,food:90,metal:38,manpower:55}},
  "Artillery 2":{"Axis":{money:78,food:98,metal:43,manpower:55},"Allies":{money:78,food:98,metal:43,manpower:55},"Comintern":{money:55,food:69,metal:30,manpower:39},"Pan-Asian":{money:78,food:98,metal:43,manpower:55}},
  "Artillery 3":{"Axis":{money:85,food:110,metal:48,manpower:55},"Allies":{money:85,food:110,metal:48,manpower:55},"Comintern":{money:60,food:77,metal:34,manpower:39},"Pan-Asian":{money:85,food:110,metal:48,manpower:55}},
  "Artillery 4":{"Axis":{money:98,food:125,metal:53,manpower:58},"Allies":{money:98,food:125,metal:53,manpower:58},"Comintern":{money:69,food:88,metal:37,manpower:41},"Pan-Asian":{money:98,food:125,metal:53,manpower:58}},
  "Artillery 5":{"Axis":{money:110,food:140,metal:60,manpower:60},"Allies":{money:110,food:140,metal:60,manpower:60},"Comintern":{money:77,food:98,metal:42,manpower:42},"Pan-Asian":{money:110,food:140,metal:60,manpower:60}},
  "Artillery 6":{"Axis":{money:120,food:155,metal:65,manpower:60},"Allies":{money:120,food:155,metal:65,manpower:60},"Comintern":{money:84,food:109,metal:46,manpower:42},"Pan-Asian":{money:120,food:155,metal:65,manpower:60}},
  "Attack Bomber 1":{"Axis":{money:73,food:53,oil:78,manpower:53},"Allies":{money:73,food:53,oil:78,manpower:53},"Comintern":{money:51,food:37,oil:55,manpower:37},"Pan-Asian":{money:73,food:53,oil:78,manpower:53}},
  "Attack Bomber 2":{"Axis":{money:83,food:60,oil:90,manpower:55},"Allies":{money:83,food:60,oil:90,manpower:55},"Comintern":{money:58,food:42,oil:63,manpower:39},"Pan-Asian":{money:83,food:60,oil:90,manpower:55}},
  "Attack Bomber 3":{"Axis":{money:95,food:68,oil:103,manpower:55},"Allies":{money:95,food:68,oil:103,manpower:55},"Comintern":{money:67,food:48,oil:72,manpower:39},"Pan-Asian":{money:95,food:68,oil:103,manpower:55}},
  "Attack Bomber 4":{"Axis":{money:113,food:80,oil:123,manpower:58},"Allies":{money:113,food:80,oil:123,manpower:58},"Comintern":{money:79,food:56,oil:86,manpower:41},"Pan-Asian":{money:113,food:80,oil:123,manpower:58}},
  "Attack Bomber 5":{"Axis":{money:123,food:90,oil:135,manpower:60},"Allies":{money:123,food:90,oil:135,manpower:60},"Comintern":{money:86,food:63,oil:95,manpower:42},"Pan-Asian":{money:123,food:90,oil:135,manpower:60}},
  "Battleship 1":{"Axis":{money:90,food:45,metal:135,manpower:83},"Allies":{money:90,food:45,metal:135,manpower:83},"Comintern":{money:63,food:32,metal:95,manpower:58},"Pan-Asian":{money:90,food:45,metal:135,manpower:83}},
  "Battleship 2":{"Axis":{money:98,food:48,metal:145,manpower:83},"Allies":{money:98,food:48,metal:145,manpower:83},"Comintern":{money:69,food:34,metal:102,manpower:58},"Pan-Asian":{money:98,food:48,metal:145,manpower:83}},
  "Battleship 3":{"Axis":{money:113,food:55,metal:168,manpower:85},"Allies":{money:113,food:55,metal:168,manpower:85},"Comintern":{money:79,food:39,metal:118,manpower:60},"Pan-Asian":{money:113,food:55,metal:168,manpower:85}},
  "Battleship 4":{"Axis":{money:125,food:63,metal:190,manpower:88},"Allies":{money:125,food:63,metal:190,manpower:88},"Comintern":{money:88,food:44,metal:133,manpower:62},"Pan-Asian":{money:125,food:63,metal:190,manpower:88}},
  "Battleship 5":{"Axis":{money:148,food:75,metal:223,manpower:90},"Allies":{money:148,food:75,metal:223,manpower:90},"Comintern":{money:104,food:53,metal:156,manpower:63},"Pan-Asian":{money:148,food:75,metal:223,manpower:90}},
  "Battleship 6":{"Axis":{money:163,food:80,metal:243,manpower:93},"Allies":{money:163,food:80,metal:243,manpower:93},"Comintern":{money:114,food:56,metal:170,manpower:65},"Pan-Asian":{money:163,food:80,metal:243,manpower:93}},
  "Commandos 1":{"Axis":{money:108,food:108,oil:50,manpower:53},"Allies":{money:108,food:108,oil:50,manpower:53},"Comintern":{money:76,food:76,oil:35,manpower:37},"Pan-Asian":{money:108,food:108,oil:50,manpower:53}},
  "Commandos 2":{"Axis":{money:123,food:123,oil:58,manpower:55},"Allies":{money:123,food:123,oil:58,manpower:55},"Comintern":{money:86,food:86,oil:41,manpower:39},"Pan-Asian":{money:123,food:123,oil:58,manpower:55}},
  "Commandos 3":{"Axis":{money:138,food:138,oil:65,manpower:55},"Allies":{money:138,food:138,oil:65,manpower:55},"Comintern":{money:97,food:97,oil:46,manpower:39},"Pan-Asian":{money:138,food:138,oil:65,manpower:55}},
  "Commandos 4":{"Axis":{money:160,food:160,oil:75,manpower:58},"Allies":{money:160,food:160,oil:75,manpower:58},"Comintern":{money:112,food:112,oil:53,manpower:41},"Pan-Asian":{money:160,food:160,oil:75,manpower:58}},
  "Cruiser 1":{"Axis":{money:68,food:95,metal:55,manpower:50},"Allies":{money:68,food:95,metal:55,manpower:50},"Comintern":{money:48,food:67,metal:39,manpower:35},"Pan-Asian":{money:68,food:95,metal:55,manpower:50}},
  "Cruiser 2":{"Axis":{money:73,food:103,metal:58,manpower:50},"Allies":{money:73,food:103,metal:58,manpower:50},"Comintern":{money:51,food:72,metal:41,manpower:35},"Pan-Asian":{money:73,food:103,metal:58,manpower:50}},
  "Cruiser 3":{"Axis":{money:83,food:115,metal:65,manpower:53},"Allies":{money:83,food:115,metal:65,manpower:53},"Comintern":{money:58,food:81,metal:46,manpower:37},"Pan-Asian":{money:83,food:115,metal:65,manpower:53}},
  "Cruiser 4":{"Axis":{money:93,food:130,metal:75,manpower:53},"Allies":{money:93,food:130,metal:75,manpower:53},"Comintern":{money:65,food:91,metal:53,manpower:37},"Pan-Asian":{money:93,food:130,metal:75,manpower:53}},
  "Cruiser 5":{"Axis":{money:110,food:153,metal:88,manpower:55},"Allies":{money:110,food:153,metal:88,manpower:55},"Comintern":{money:77,food:107,metal:62,manpower:39},"Pan-Asian":{money:110,food:153,metal:88,manpower:55}},
  "Cruiser 6":{"Axis":{money:120,food:170,metal:98,manpower:58},"Allies":{money:120,food:170,metal:98,manpower:58},"Comintern":{money:84,food:119,metal:69,manpower:41},"Pan-Asian":{money:120,food:170,metal:98,manpower:58}},
  "Destroyer 1":{"Axis":{money:65,food:50,metal:60,manpower:40},"Allies":{money:65,food:50,metal:60,manpower:40},"Comintern":{money:46,food:35,metal:42,manpower:28},"Pan-Asian":{money:65,food:50,metal:60,manpower:40}},
  "Destroyer 2":{"Axis":{money:73,food:55,metal:65,manpower:43},"Allies":{money:73,food:55,metal:65,manpower:43},"Comintern":{money:51,food:39,metal:46,manpower:30},"Pan-Asian":{money:73,food:55,metal:65,manpower:43}},
  "Destroyer 3":{"Axis":{money:80,food:60,metal:73,manpower:43},"Allies":{money:80,food:60,metal:73,manpower:43},"Comintern":{money:56,food:42,metal:51,manpower:30},"Pan-Asian":{money:80,food:60,metal:73,manpower:43}},
  "Destroyer 4":{"Axis":{money:90,food:68,metal:83,manpower:43},"Allies":{money:90,food:68,metal:83,manpower:43},"Comintern":{money:63,food:48,metal:58,manpower:30},"Pan-Asian":{money:90,food:68,metal:83,manpower:43}},
  "Destroyer 5":{"Axis":{money:108,food:80,metal:98,manpower:45},"Allies":{money:108,food:80,metal:98,manpower:45},"Comintern":{money:76,food:56,metal:69,manpower:32},"Pan-Asian":{money:108,food:80,metal:98,manpower:45}},
  "Destroyer 6":{"Axis":{money:118,food:90,metal:110,manpower:48},"Allies":{money:118,food:90,metal:110,manpower:48},"Comintern":{money:83,food:63,metal:77,manpower:34},"Pan-Asian":{money:118,food:90,metal:110,manpower:48}},
  "Flame Tank 1":{"Axis":{money:113,metal:103,oil:103,manpower:78},"Allies":{money:113,metal:103,oil:103,manpower:78},"Comintern":{money:113,metal:103,oil:103,manpower:78},"Pan-Asian":{money:113,metal:103,oil:103,manpower:78}},
  "Flame Tank 2":{"Axis":{money:128,metal:118,oil:118,manpower:80},"Allies":{money:128,metal:118,oil:118,manpower:80},"Comintern":{money:128,metal:118,oil:118,manpower:80},"Pan-Asian":{money:128,metal:118,oil:118,manpower:80}},
  "Flame Tank 3":{"Axis":{money:148,metal:135,oil:135,manpower:83},"Allies":{money:148,metal:135,oil:135,manpower:83},"Comintern":{money:148,metal:135,oil:135,manpower:83},"Pan-Asian":{money:148,metal:135,oil:135,manpower:83}},
  "Flying Bomb 1":{"Axis":{money:38,metal:38,oil:20,manpower:10},"Allies":{money:38,metal:38,oil:20,manpower:10},"Comintern":{money:38,metal:38,oil:20,manpower:10},"Pan-Asian":{money:38,metal:38,oil:20,manpower:10}},
  "Heavy Tank 1":{"Axis":{money:130,metal:105,oil:153,manpower:65},"Allies":{money:130,metal:105,oil:153,manpower:65},"Comintern":{money:91,metal:74,oil:107,manpower:46},"Pan-Asian":{money:130,metal:105,oil:153,manpower:65}},
  "Heavy Tank 2":{"Axis":{money:148,metal:120,oil:173,manpower:68},"Allies":{money:148,metal:120,oil:173,manpower:68},"Comintern":{money:104,metal:84,oil:121,manpower:48},"Pan-Asian":{money:148,metal:120,oil:173,manpower:68}},
  "Heavy Tank 3":{"Axis":{money:173,metal:143,oil:205,manpower:70},"Allies":{money:173,metal:143,oil:205,manpower:70},"Comintern":{money:121,metal:100,oil:144,manpower:49},"Pan-Asian":{money:173,metal:143,oil:205,manpower:70}},
  "Heavy Tank 4":{"Axis":{money:200,metal:165,oil:238,manpower:73},"Allies":{money:200,metal:165,oil:238,manpower:73},"Comintern":{money:140,metal:116,oil:167,manpower:51},"Pan-Asian":{money:200,metal:165,oil:238,manpower:73}},
  "Infantry 1":{"Axis":{money:40,food:55,metal:13,manpower:48},"Allies":{money:40,food:55,metal:13,manpower:48},"Comintern":{money:20,food:28,metal:7,manpower:24},"Pan-Asian":{money:40,food:55,metal:13,manpower:48}},
  "Infantry 2":{"Axis":{money:40,food:58,metal:13,manpower:48},"Allies":{money:40,food:58,metal:13,manpower:48},"Comintern":{money:20,food:29,metal:7,manpower:24},"Pan-Asian":{money:40,food:58,metal:13,manpower:48}},
  "Infantry 3":{"Axis":{money:43,food:60,metal:13,manpower:48},"Allies":{money:43,food:60,metal:13,manpower:48},"Comintern":{money:22,food:30,metal:7,manpower:24},"Pan-Asian":{money:43,food:60,metal:13,manpower:48}},
  "Infantry 4":{"Axis":{money:45,food:63,metal:13,manpower:50},"Allies":{money:45,food:63,metal:13,manpower:50},"Comintern":{money:23,food:32,metal:7,manpower:25},"Pan-Asian":{money:45,food:63,metal:13,manpower:50}},
  "Infantry 5":{"Axis":{money:50,food:70,metal:15,manpower:50},"Allies":{money:50,food:70,metal:15,manpower:50},"Comintern":{money:25,food:35,metal:8,manpower:25},"Pan-Asian":{money:50,food:70,metal:15,manpower:50}},
  "Infantry 6":{"Axis":{money:58,food:80,metal:18,manpower:53},"Allies":{money:58,food:80,metal:18,manpower:53},"Comintern":{money:29,food:40,metal:9,manpower:27},"Pan-Asian":{money:58,food:80,metal:18,manpower:53}},
  "Infantry 7":{"Axis":{money:63,food:88,metal:20,manpower:53},"Allies":{money:63,food:88,metal:20,manpower:53},"Comintern":{money:32,food:44,metal:10,manpower:27},"Pan-Asian":{money:63,food:88,metal:20,manpower:53}},
  "Interceptor 1":{"Axis":{money:75,food:48,oil:48,manpower:40},"Allies":{money:75,food:48,oil:48,manpower:40},"Comintern":{money:53,food:34,oil:34,manpower:28},"Pan-Asian":{money:75,food:48,oil:48,manpower:40}},
  "Interceptor 2":{"Axis":{money:80,food:50,oil:50,manpower:40},"Allies":{money:80,food:50,oil:50,manpower:40},"Comintern":{money:56,food:35,oil:35,manpower:28},"Pan-Asian":{money:80,food:50,oil:50,manpower:40}},
  "Interceptor 3":{"Axis":{money:85,food:55,oil:55,manpower:40},"Allies":{money:85,food:55,oil:55,manpower:40},"Comintern":{money:60,food:39,oil:39,manpower:28},"Pan-Asian":{money:85,food:55,oil:55,manpower:40}},
  "Interceptor 4":{"Axis":{money:98,food:63,oil:63,manpower:43},"Allies":{money:98,food:63,oil:63,manpower:43},"Comintern":{money:69,food:44,oil:44,manpower:30},"Pan-Asian":{money:98,food:63,oil:63,manpower:43}},
  "Interceptor 5":{"Axis":{money:110,food:70,oil:70,manpower:43},"Allies":{money:110,food:70,oil:70,manpower:43},"Comintern":{money:77,food:49,oil:49,manpower:30},"Pan-Asian":{money:110,food:70,oil:70,manpower:43}},
  "Interceptor 6":{"Axis":{money:123,food:80,oil:80,manpower:45},"Allies":{money:123,food:80,oil:80,manpower:45},"Comintern":{money:86,food:56,oil:56,manpower:32},"Pan-Asian":{money:123,food:80,oil:80,manpower:45}},
  "Interceptor 7":{"Axis":{money:135,food:88,oil:88,manpower:45},"Allies":{money:135,food:88,oil:88,manpower:45},"Comintern":{money:95,food:62,oil:62,manpower:32},"Pan-Asian":{money:135,food:88,oil:88,manpower:45}},
  "Light Tank 1":{"Axis":{money:55,metal:75,oil:68,manpower:45},"Allies":{money:55,metal:75,oil:68,manpower:45},"Comintern":{money:39,metal:53,oil:48,manpower:32},"Pan-Asian":{money:55,metal:75,oil:68,manpower:45}},
  "Light Tank 2":{"Axis":{money:60,metal:80,oil:73,manpower:48},"Allies":{money:60,metal:80,oil:73,manpower:48},"Comintern":{money:42,metal:56,oil:51,manpower:34},"Pan-Asian":{money:60,metal:80,oil:73,manpower:48}},
  "Light Tank 3":{"Axis":{money:68,metal:90,oil:83,manpower:48},"Allies":{money:68,metal:90,oil:83,manpower:48},"Comintern":{money:48,metal:63,oil:58,manpower:34},"Pan-Asian":{money:68,metal:90,oil:83,manpower:48}},
  "Light Tank 4":{"Axis":{money:80,metal:108,oil:100,manpower:50},"Allies":{money:80,metal:108,oil:100,manpower:50},"Comintern":{money:56,metal:76,oil:70,manpower:35},"Pan-Asian":{money:80,metal:108,oil:100,manpower:50}},
  "Light Tank 5":{"Axis":{money:95,metal:128,oil:115,manpower:53},"Allies":{money:95,metal:128,oil:115,manpower:53},"Comintern":{money:67,metal:90,oil:81,manpower:37},"Pan-Asian":{money:95,metal:128,oil:115,manpower:53}},
  "Marines 1":{"Axis":{money:110,food:60,oil:55,manpower:48},"Allies":{money:110,food:60,oil:55,manpower:48},"Comintern":{money:77,food:42,oil:39,manpower:34},"Pan-Asian":{money:110,food:60,oil:55,manpower:48}},
  "Marines 2":{"Axis":{money:120,food:65,oil:60,manpower:48},"Allies":{money:120,food:65,oil:60,manpower:48},"Comintern":{money:84,food:46,oil:42,manpower:34},"Pan-Asian":{money:120,food:65,oil:60,manpower:48}},
  "Marines 3":{"Axis":{money:133,food:73,oil:68,manpower:48},"Allies":{money:133,food:73,oil:68,manpower:48},"Comintern":{money:93,food:51,oil:48,manpower:34},"Pan-Asian":{money:133,food:73,oil:68,manpower:48}},
  "Mechanized Infantry 1":{"Axis":{money:80,metal:73,oil:65,manpower:63},"Allies":{money:80,metal:73,oil:65,manpower:63},"Comintern":{money:56,metal:51,oil:46,manpower:44},"Pan-Asian":{money:80,metal:73,oil:65,manpower:63}},
  "Mechanized Infantry 2":{"Axis":{money:93,metal:85,oil:75,manpower:65},"Allies":{money:93,metal:85,oil:75,manpower:65},"Comintern":{money:65,metal:60,oil:53,manpower:46},"Pan-Asian":{money:93,metal:85,oil:75,manpower:65}},
  "Mechanized Infantry 3":{"Axis":{money:105,metal:95,oil:85,manpower:65},"Allies":{money:105,metal:95,oil:85,manpower:65},"Comintern":{money:74,metal:67,oil:60,manpower:46},"Pan-Asian":{money:105,metal:95,oil:85,manpower:65}},
  "Mechanized Infantry 4":{"Axis":{money:118,metal:108,oil:95,manpower:68},"Allies":{money:118,metal:108,oil:95,manpower:68},"Comintern":{money:83,metal:76,oil:67,manpower:48},"Pan-Asian":{money:118,metal:108,oil:95,manpower:68}},
  "Mechanized Infantry 5":{"Axis":{money:130,metal:118,oil:105,manpower:70},"Allies":{money:130,metal:118,oil:105,manpower:70},"Comintern":{money:91,metal:83,oil:74,manpower:49},"Pan-Asian":{money:130,metal:118,oil:105,manpower:70}},
  "Medium Tank 1":{"Axis":{money:88,metal:88,oil:95,manpower:68},"Allies":{money:88,metal:88,oil:95,manpower:68},"Comintern":{money:62,metal:62,oil:67,manpower:48},"Pan-Asian":{money:88,metal:88,oil:95,manpower:68}},
  "Medium Tank 2":{"Axis":{money:98,metal:98,oil:105,manpower:70},"Allies":{money:98,metal:98,oil:105,manpower:70},"Comintern":{money:69,metal:69,oil:74,manpower:49},"Pan-Asian":{money:98,metal:98,oil:105,manpower:70}},
  "Medium Tank 3":{"Axis":{money:110,metal:110,oil:120,manpower:73},"Allies":{money:110,metal:110,oil:120,manpower:73},"Comintern":{money:77,metal:77,oil:84,manpower:51},"Pan-Asian":{money:110,metal:110,oil:120,manpower:73}},
  "Medium Tank 4":{"Axis":{money:123,metal:123,oil:135,manpower:73},"Allies":{money:123,metal:123,oil:135,manpower:73},"Comintern":{money:86,metal:86,oil:95,manpower:51},"Pan-Asian":{money:123,metal:123,oil:135,manpower:73}},
  "Medium Tank 5":{"Axis":{money:138,metal:138,oil:150,manpower:75},"Allies":{money:138,metal:138,oil:150,manpower:75},"Comintern":{money:97,metal:97,oil:105,manpower:53},"Pan-Asian":{money:138,metal:138,oil:150,manpower:75}},
  "Medium Tank 6":{"Axis":{money:150,metal:150,oil:165,manpower:78},"Allies":{money:150,metal:150,oil:165,manpower:78},"Comintern":{money:105,metal:105,oil:116,manpower:55},"Pan-Asian":{money:150,metal:150,oil:165,manpower:78}},
  "Militia 1":{"Axis":{money:30,food:25,metal:10,manpower:40},"Allies":{money:30,food:25,metal:10,manpower:40},"Comintern":{money:21,food:18,metal:7,manpower:28},"Pan-Asian":{money:30,food:25,metal:10,manpower:40}},
  "Militia 2":{"Axis":{money:33,food:28,metal:13,manpower:43},"Allies":{money:33,food:28,metal:13,manpower:43},"Comintern":{money:23,food:20,metal:9,manpower:30},"Pan-Asian":{money:33,food:28,metal:13,manpower:43}},
  "Militia 3":{"Axis":{money:38,food:33,metal:15,manpower:43},"Allies":{money:38,food:33,metal:15,manpower:43},"Comintern":{money:27,food:23,metal:11,manpower:30},"Pan-Asian":{money:38,food:33,metal:15,manpower:43}},
  "Militia 4":{"Axis":{money:45,food:38,metal:18,manpower:45},"Allies":{money:45,food:38,metal:18,manpower:45},"Comintern":{money:32,food:27,metal:13,manpower:32},"Pan-Asian":{money:45,food:38,metal:18,manpower:45}},
  "Motorized Infantry 1":{"Axis":{money:63,food:50,oil:75,manpower:58},"Allies":{money:63,food:50,oil:75,manpower:58},"Comintern":{money:44,food:35,oil:53,manpower:41},"Pan-Asian":{money:63,food:50,oil:75,manpower:58}},
  "Motorized Infantry 2":{"Axis":{money:65,food:53,oil:78,manpower:58},"Allies":{money:65,food:53,oil:78,manpower:58},"Comintern":{money:46,food:37,oil:55,manpower:41},"Pan-Asian":{money:65,food:53,oil:78,manpower:58}},
  "Motorized Infantry 3":{"Axis":{money:73,food:58,oil:88,manpower:58},"Allies":{money:73,food:58,oil:88,manpower:58},"Comintern":{money:51,food:41,oil:62,manpower:41},"Pan-Asian":{money:73,food:58,oil:88,manpower:58}},
  "Motorized Infantry 4":{"Axis":{money:83,food:65,oil:100,manpower:60},"Allies":{money:83,food:65,oil:100,manpower:60},"Comintern":{money:58,food:46,oil:70,manpower:42},"Pan-Asian":{money:83,food:65,oil:100,manpower:60}},
  "Motorized Infantry 5":{"Axis":{money:93,food:75,oil:110,manpower:63},"Allies":{money:93,food:75,oil:110,manpower:63},"Comintern":{money:65,food:53,oil:77,manpower:44},"Pan-Asian":{money:93,food:75,oil:110,manpower:63}},
  "Motorized Infantry 6":{"Axis":{money:103,food:83,oil:123,manpower:63},"Allies":{money:103,food:83,oil:123,manpower:63},"Comintern":{money:72,food:58,oil:86,manpower:44},"Pan-Asian":{money:103,food:83,oil:123,manpower:63}},
  "Naval Bomber 1":{"Axis":{money:55,food:60,oil:65,manpower:35},"Allies":{money:55,food:60,oil:65,manpower:35},"Comintern":{money:39,food:42,oil:46,manpower:25},"Pan-Asian":{money:55,food:60,oil:65,manpower:35}},
  "Naval Bomber 2":{"Axis":{money:58,food:63,oil:68,manpower:35},"Allies":{money:58,food:63,oil:68,manpower:35},"Comintern":{money:41,food:44,oil:48,manpower:25},"Pan-Asian":{money:58,food:63,oil:68,manpower:35}},
  "Naval Bomber 3":{"Axis":{money:60,food:68,oil:73,manpower:35},"Allies":{money:60,food:68,oil:73,manpower:35},"Comintern":{money:42,food:48,oil:51,manpower:25},"Pan-Asian":{money:60,food:68,oil:73,manpower:35}},
  "Naval Bomber 4":{"Axis":{money:70,food:78,oil:83,manpower:38},"Allies":{money:70,food:78,oil:83,manpower:38},"Comintern":{money:49,food:55,oil:58,manpower:27},"Pan-Asian":{money:70,food:78,oil:83,manpower:38}},
  "Naval Bomber 5":{"Axis":{money:80,food:88,oil:95,manpower:38},"Allies":{money:80,food:88,oil:95,manpower:38},"Comintern":{money:56,food:62,oil:67,manpower:27},"Pan-Asian":{money:80,food:88,oil:95,manpower:38}},
  "Naval Bomber 6":{"Axis":{money:88,food:98,oil:105,manpower:40},"Allies":{money:88,food:98,oil:105,manpower:40},"Comintern":{money:62,food:69,oil:74,manpower:28},"Pan-Asian":{money:88,food:98,oil:105,manpower:40}},
  "Naval Bomber 7":{"Axis":{money:98,food:108,oil:115,manpower:40},"Allies":{money:98,food:108,oil:115,manpower:40},"Comintern":{money:69,food:76,oil:81,manpower:28},"Pan-Asian":{money:98,food:108,oil:115,manpower:40}},
  "Nuclear Bomber 1":{"Axis":{money:1053,food:175,metal:175,oil:468,manpower:285},"Allies":{money:1053,food:175,metal:175,oil:468,manpower:285},"Comintern":{money:737,food:123,metal:123,oil:328,manpower:200},"Pan-Asian":{money:1053,food:175,metal:175,oil:468,manpower:285}},
  "Nuclear Bomber 2":{"Axis":{money:1103,food:185,metal:185,oil:490,manpower:290},"Allies":{money:1103,food:185,metal:185,oil:490,manpower:290},"Comintern":{money:772,food:130,metal:130,oil:343,manpower:203},"Pan-Asian":{money:1103,food:185,metal:185,oil:490,manpower:290}},
  "Nuclear Bomber 3":{"Axis":{money:1155,food:193,metal:193,oil:513,manpower:293},"Allies":{money:1155,food:193,metal:193,oil:513,manpower:293},"Comintern":{money:809,food:135,metal:135,oil:359,manpower:205},"Pan-Asian":{money:1155,food:193,metal:193,oil:513,manpower:293}},
  "Nuclear Rocket 1":{"Axis":{money:1215,food:338,metal:338,oil:405,manpower:228},"Allies":{money:1215,food:338,metal:338,oil:405,manpower:228},"Comintern":{money:851,food:237,metal:237,oil:284,manpower:160},"Pan-Asian":{money:1215,food:338,metal:338,oil:405,manpower:228}},
  "Paratroopers 1":{"Axis":{money:128,food:68,oil:60,manpower:68},"Allies":{money:128,food:68,oil:60,manpower:68},"Comintern":{money:90,food:48,oil:42,manpower:48},"Pan-Asian":{money:128,food:68,oil:60,manpower:68}},
  "Paratroopers 2":{"Axis":{money:145,food:78,oil:68,manpower:70},"Allies":{money:145,food:78,oil:68,manpower:70},"Comintern":{money:102,food:55,oil:48,manpower:49},"Pan-Asian":{money:145,food:78,oil:68,manpower:70}},
  "Paratroopers 3":{"Axis":{money:163,food:88,oil:75,manpower:73},"Allies":{money:163,food:88,oil:75,manpower:73},"Comintern":{money:114,food:62,oil:53,manpower:51},"Pan-Asian":{money:163,food:88,oil:75,manpower:73}},
  "Paratroopers 4":{"Axis":{money:190,food:100,oil:88,manpower:75},"Allies":{money:190,food:100,oil:88,manpower:75},"Comintern":{money:133,food:70,oil:62,manpower:53},"Pan-Asian":{money:190,food:100,oil:88,manpower:75}},
  "Railroad Gun 1":{"Axis":{money:203,metal:170,oil:93,manpower:133},"Allies":{money:203,metal:170,oil:93,manpower:133},"Comintern":{money:142,metal:119,oil:65,manpower:93},"Pan-Asian":{money:203,metal:170,oil:93,manpower:133}},
  "Railroad Gun 2":{"Axis":{money:278,metal:235,oil:128,manpower:143},"Allies":{money:278,metal:235,oil:128,manpower:143},"Comintern":{money:195,metal:165,oil:90,manpower:100},"Pan-Asian":{money:278,metal:235,oil:128,manpower:143}},
  "Rocket 1":{"Axis":{money:110,metal:40,oil:53,manpower:23},"Allies":{money:110,metal:40,oil:53,manpower:23},"Comintern":{money:77,metal:28,oil:37,manpower:16},"Pan-Asian":{money:110,metal:40,oil:53,manpower:23}},
  "Rocket 2":{"Axis":{money:125,metal:45,oil:60,manpower:23},"Allies":{money:125,metal:45,oil:60,manpower:23},"Comintern":{money:88,metal:32,oil:42,manpower:16},"Pan-Asian":{money:125,metal:45,oil:60,manpower:23}},
  "Rocket 3":{"Axis":{money:140,metal:53,oil:68,manpower:25},"Allies":{money:140,metal:53,oil:68,manpower:25},"Comintern":{money:98,metal:37,oil:48,manpower:18},"Pan-Asian":{money:140,metal:53,oil:68,manpower:25}},
  "Rocket 4":{"Axis":{money:155,metal:58,oil:75,manpower:25},"Allies":{money:155,metal:58,oil:75,manpower:25},"Comintern":{money:109,metal:41,oil:53,manpower:18},"Pan-Asian":{money:155,metal:58,oil:75,manpower:25}},
  "Rocket Artillery 1":{"Axis":{money:68,food:63,metal:88,manpower:50},"Allies":{money:68,food:63,metal:88,manpower:50},"Comintern":{money:48,food:44,metal:62,manpower:35},"Pan-Asian":{money:68,food:63,metal:88,manpower:50}},
  "Rocket Artillery 2":{"Axis":{money:80,food:70,metal:103,manpower:50},"Allies":{money:80,food:70,metal:103,manpower:50},"Comintern":{money:56,food:49,metal:72,manpower:35},"Pan-Asian":{money:80,food:70,metal:103,manpower:50}},
  "Rocket Artillery 3":{"Axis":{money:100,food:90,metal:130,manpower:53},"Allies":{money:100,food:90,metal:130,manpower:53},"Comintern":{money:70,food:63,metal:91,manpower:37},"Pan-Asian":{money:100,food:90,metal:130,manpower:53}},
  "Rocket Fighter 1":{"Axis":{money:68,food:55,oil:100,manpower:38},"Allies":{money:68,food:55,oil:100,manpower:38},"Comintern":{money:48,food:39,oil:70,manpower:27},"Pan-Asian":{money:68,food:55,oil:100,manpower:38}},
  "Rocket Fighter 2":{"Axis":{money:85,food:70,oil:130,manpower:40},"Allies":{money:85,food:70,oil:130,manpower:40},"Comintern":{money:60,food:49,oil:91,manpower:28},"Pan-Asian":{money:85,food:70,oil:130,manpower:40}},
  "SP Anti Air 1":{"Axis":{money:70,food:45,oil:83,manpower:50},"Allies":{money:70,food:45,oil:83,manpower:50},"Comintern":{money:49,food:32,oil:58,manpower:35},"Pan-Asian":{money:70,food:45,oil:83,manpower:50}},
  "SP Anti Air 2":{"Axis":{money:80,food:53,oil:95,manpower:50},"Allies":{money:80,food:53,oil:95,manpower:50},"Comintern":{money:56,food:37,oil:67,manpower:35},"Pan-Asian":{money:80,food:53,oil:95,manpower:50}},
  "SP Anti Air 3":{"Axis":{money:93,food:58,oil:108,manpower:53},"Allies":{money:93,food:58,oil:108,manpower:53},"Comintern":{money:65,food:41,oil:76,manpower:37},"Pan-Asian":{money:93,food:58,oil:108,manpower:53}},
  "SP Anti Air 4":{"Axis":{money:103,food:65,oil:120,manpower:53},"Allies":{money:103,food:65,oil:120,manpower:53},"Comintern":{money:72,food:46,oil:84,manpower:37},"Pan-Asian":{money:103,food:65,oil:120,manpower:53}},
  "SP Anti Air 5":{"Axis":{money:113,food:73,oil:133,manpower:55},"Allies":{money:113,food:73,oil:133,manpower:55},"Comintern":{money:79,food:51,oil:93,manpower:39},"Pan-Asian":{money:113,food:73,oil:133,manpower:55}},
  "SP Artillery 1":{"Axis":{money:110,metal:90,oil:83,manpower:70},"Allies":{money:110,metal:90,oil:83,manpower:70},"Comintern":{money:77,metal:63,oil:58,manpower:49},"Pan-Asian":{money:110,metal:90,oil:83,manpower:70}},
  "SP Artillery 2":{"Axis":{money:125,metal:105,oil:95,manpower:73},"Allies":{money:125,metal:105,oil:95,manpower:73},"Comintern":{money:88,metal:74,oil:67,manpower:51},"Pan-Asian":{money:125,metal:105,oil:95,manpower:73}},
  "SP Artillery 3":{"Axis":{money:143,metal:118,oil:108,manpower:73},"Allies":{money:143,metal:118,oil:108,manpower:73},"Comintern":{money:100,metal:83,oil:76,manpower:51},"Pan-Asian":{money:143,metal:118,oil:108,manpower:73}},
  "SP Artillery 4":{"Axis":{money:158,metal:133,oil:118,manpower:75},"Allies":{money:158,metal:133,oil:118,manpower:75},"Comintern":{money:111,metal:93,oil:83,manpower:53},"Pan-Asian":{money:158,metal:133,oil:118,manpower:75}},
  "SP Artillery 5":{"Axis":{money:175,metal:145,oil:130,manpower:78},"Allies":{money:175,metal:145,oil:130,manpower:78},"Comintern":{money:123,metal:102,oil:91,manpower:55},"Pan-Asian":{money:175,metal:145,oil:130,manpower:78}},
  "SP Rocket Artillery 1":{"Axis":{money:95,metal:95,oil:95,manpower:78},"Allies":{money:95,metal:95,oil:95,manpower:78},"Comintern":{money:67,metal:67,oil:67,manpower:55},"Pan-Asian":{money:95,metal:95,oil:95,manpower:78}},
  "SP Rocket Artillery 2":{"Axis":{money:123,metal:123,oil:123,manpower:80},"Allies":{money:123,metal:123,oil:123,manpower:80},"Comintern":{money:86,metal:86,oil:86,manpower:56},"Pan-Asian":{money:123,metal:123,oil:123,manpower:80}},
  "Sniper 1":{"Axis":{money:70,food:55,metal:15,manpower:40},"Allies":{money:70,food:55,metal:15,manpower:40},"Comintern":{money:70,food:55,metal:15,manpower:40},"Pan-Asian":{money:70,food:55,metal:15,manpower:40}},
  "Sniper 2":{"Axis":{money:70,food:55,metal:15,manpower:40},"Allies":{money:70,food:55,metal:15,manpower:40},"Comintern":{money:70,food:55,metal:15,manpower:40},"Pan-Asian":{money:70,food:55,metal:15,manpower:40}},
  "Sniper 3":{"Axis":{money:70,food:55,metal:15,manpower:40},"Allies":{money:70,food:55,metal:15,manpower:40},"Comintern":{money:70,food:55,metal:15,manpower:40},"Pan-Asian":{money:70,food:55,metal:15,manpower:40}},
  "Strategic Bomber 1":{"Axis":{money:90,food:80,oil:80,manpower:98},"Allies":{money:90,food:80,oil:80,manpower:98},"Comintern":{money:63,food:56,oil:56,manpower:69},"Pan-Asian":{money:90,food:80,oil:80,manpower:98}},
  "Strategic Bomber 2":{"Axis":{money:98,food:88,oil:88,manpower:100},"Allies":{money:98,food:88,oil:88,manpower:100},"Comintern":{money:69,food:62,oil:62,manpower:70},"Pan-Asian":{money:98,food:88,oil:88,manpower:100}},
  "Strategic Bomber 3":{"Axis":{money:105,food:95,oil:95,manpower:100},"Allies":{money:105,food:95,oil:95,manpower:100},"Comintern":{money:74,food:67,oil:67,manpower:70},"Pan-Asian":{money:105,food:95,oil:95,manpower:100}},
  "Strategic Bomber 4":{"Axis":{money:120,food:108,oil:108,manpower:105},"Allies":{money:120,food:108,oil:108,manpower:105},"Comintern":{money:84,food:76,oil:76,manpower:74},"Pan-Asian":{money:120,food:108,oil:108,manpower:105}},
  "Strategic Bomber 5":{"Axis":{money:133,food:120,oil:120,manpower:108},"Allies":{money:133,food:120,oil:120,manpower:108},"Comintern":{money:93,food:84,oil:84,manpower:76},"Pan-Asian":{money:133,food:120,oil:120,manpower:108}},
  "Strategic Bomber 6":{"Axis":{money:148,food:133,oil:133,manpower:110},"Allies":{money:148,food:133,oil:133,manpower:110},"Comintern":{money:104,food:93,oil:93,manpower:77},"Pan-Asian":{money:148,food:133,oil:133,manpower:110}},
  "Strategic Bomber 7":{"Axis":{money:163,food:145,oil:145,manpower:113},"Allies":{money:163,food:145,oil:145,manpower:113},"Comintern":{money:114,food:102,oil:102,manpower:79},"Pan-Asian":{money:163,food:145,oil:145,manpower:113}},
  "Submarine 1":{"Axis":{money:80,food:48,oil:48,manpower:35},"Allies":{money:80,food:48,oil:48,manpower:35},"Comintern":{money:56,food:34,oil:34,manpower:25},"Pan-Asian":{money:80,food:48,oil:48,manpower:35}},
  "Submarine 2":{"Axis":{money:85,food:53,oil:53,manpower:35},"Allies":{money:85,food:53,oil:53,manpower:35},"Comintern":{money:60,food:37,oil:37,manpower:25},"Pan-Asian":{money:85,food:53,oil:53,manpower:35}},
  "Submarine 3":{"Axis":{money:95,food:58,oil:58,manpower:35},"Allies":{money:95,food:58,oil:58,manpower:35},"Comintern":{money:67,food:41,oil:41,manpower:25},"Pan-Asian":{money:95,food:58,oil:58,manpower:35}},
  "Submarine 4":{"Axis":{money:110,food:65,oil:65,manpower:38},"Allies":{money:110,food:65,oil:65,manpower:38},"Comintern":{money:77,food:46,oil:46,manpower:27},"Pan-Asian":{money:110,food:65,oil:65,manpower:38}},
  "Submarine 5":{"Axis":{money:128,food:78,oil:78,manpower:38},"Allies":{money:128,food:78,oil:78,manpower:38},"Comintern":{money:90,food:55,oil:55,manpower:27},"Pan-Asian":{money:128,food:78,oil:78,manpower:38}},
  "Submarine 6":{"Axis":{money:143,food:85,oil:85,manpower:40},"Allies":{money:143,food:85,oil:85,manpower:40},"Comintern":{money:100,food:60,oil:60,manpower:28},"Pan-Asian":{money:143,food:85,oil:85,manpower:40}},
  "Tactical Bomber 1":{"Axis":{money:80,food:105,oil:65,manpower:65},"Allies":{money:80,food:105,oil:65,manpower:65},"Comintern":{money:56,food:74,oil:46,manpower:46},"Pan-Asian":{money:80,food:105,oil:65,manpower:65}},
  "Tactical Bomber 2":{"Axis":{money:88,food:113,oil:70,manpower:65},"Allies":{money:88,food:113,oil:70,manpower:65},"Comintern":{money:62,food:79,oil:49,manpower:46},"Pan-Asian":{money:88,food:113,oil:70,manpower:65}},
  "Tactical Bomber 3":{"Axis":{money:93,food:120,oil:75,manpower:68},"Allies":{money:93,food:120,oil:75,manpower:68},"Comintern":{money:65,food:84,oil:53,manpower:48},"Pan-Asian":{money:93,food:120,oil:75,manpower:68}},
  "Tactical Bomber 4":{"Axis":{money:105,food:138,oil:85,manpower:70},"Allies":{money:105,food:138,oil:85,manpower:70},"Comintern":{money:74,food:97,oil:60,manpower:49},"Pan-Asian":{money:105,food:138,oil:85,manpower:70}},
  "Tactical Bomber 5":{"Axis":{money:118,food:155,oil:95,manpower:70},"Allies":{money:118,food:155,oil:95,manpower:70},"Comintern":{money:83,food:109,oil:67,manpower:49},"Pan-Asian":{money:118,food:155,oil:95,manpower:70}},
  "Tactical Bomber 6":{"Axis":{money:130,food:170,oil:105,manpower:73},"Allies":{money:130,food:170,oil:105,manpower:73},"Comintern":{money:91,food:119,oil:74,manpower:51},"Pan-Asian":{money:130,food:170,oil:105,manpower:73}},
  "Tactical Bomber 7":{"Axis":{money:145,food:188,oil:115,manpower:75},"Allies":{money:145,food:188,oil:115,manpower:75},"Comintern":{money:102,food:132,oil:81,manpower:53},"Pan-Asian":{money:145,food:188,oil:115,manpower:75}},
  "Tank Destroyer 1":{"Axis":{money:103,metal:95,oil:55,manpower:55},"Allies":{money:103,metal:95,oil:55,manpower:55},"Comintern":{money:72,metal:67,oil:39,manpower:39},"Pan-Asian":{money:103,metal:95,oil:55,manpower:55}},
  "Tank Destroyer 2":{"Axis":{money:115,metal:105,oil:63,manpower:58},"Allies":{money:115,metal:105,oil:63,manpower:58},"Comintern":{money:81,metal:74,oil:44,manpower:41},"Pan-Asian":{money:115,metal:105,oil:63,manpower:58}},
  "Tank Destroyer 3":{"Axis":{money:130,metal:120,oil:70,manpower:58},"Allies":{money:130,metal:120,oil:70,manpower:58},"Comintern":{money:91,metal:84,oil:49,manpower:41},"Pan-Asian":{money:130,metal:120,oil:70,manpower:58}},
  "Tank Destroyer 4":{"Axis":{money:148,metal:135,oil:80,manpower:60},"Allies":{money:148,metal:135,oil:80,manpower:60},"Comintern":{money:104,metal:95,oil:56,manpower:42},"Pan-Asian":{money:148,metal:135,oil:80,manpower:60}},
  "Tank Destroyer 5":{"Axis":{money:163,metal:150,oil:88,manpower:60},"Allies":{money:163,metal:150,oil:88,manpower:60},"Comintern":{money:114,metal:105,oil:62,manpower:42},"Pan-Asian":{money:163,metal:150,oil:88,manpower:60}},
  "Tank Destroyer 6":{"Axis":{money:178,metal:165,oil:95,manpower:63},"Allies":{money:178,metal:165,oil:95,manpower:63},"Comintern":{money:125,metal:116,oil:67,manpower:44},"Pan-Asian":{money:178,metal:165,oil:95,manpower:63}},
};

// Fixed starting resources — same for every country
const UNIVERSAL_START={money:80000,manpower:12000,food:15000,metal:15000,oil:15000};

// Daily income at 100% morale
const COUNTRY_DAILY_100={
  "Germany":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "France":{money:42000,manpower:8850,food:13500,metal:12000,oil:13500},
  "United Kingdom":{money:42600,manpower:9300,food:13500,metal:12000,oil:13500},
  "Italy":{money:42000,manpower:8850,food:13500,metal:13500,oil:12000},
  "Spain":{money:42600,manpower:9300,food:12000,metal:13500,oil:13500},
  "Communist Russia":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Sweden":{money:42000,manpower:8850,food:13500,metal:13500,oil:12000},
  "Yugoslavia":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Greater Romania":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Turkey":{money:42000,manpower:8850,food:13500,metal:13500,oil:12000},
  "Northern States of America":{money:42000,manpower:8850,food:13500,metal:12000,oil:13500},
  "Canada":{money:42000,manpower:8850,food:13500,metal:12000,oil:13500},
  "Greater Finland":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Poland":{money:42000,manpower:9150,food:13500,metal:13500,oil:12000},
  "Southern United States":{money:42000,manpower:8850,food:13500,metal:13500,oil:12000},
  "Morocco":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Algeria":{money:42000,manpower:8850,food:13500,metal:13500,oil:12000},
  "Libya":{money:42000,manpower:8850,food:13500,metal:12000,oil:13500},
  "Egypt":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Ukraine":{money:42000,manpower:8850,food:12000,metal:13500,oil:13500},
  "Caucasus":{money:42000,manpower:8850,food:13500,metal:12000,oil:13500},
  "Russian Empire":{money:42600,manpower:9300,food:13500,metal:13500,oil:12000},
};

// Dynamic budget calculation
// Day morale: Dag1=70%, Dag2=76%, Dag3=76%
// Each capital adds +10% morale starting from (day-1)*24 + hour into the 3-day window
// A day is 24 hours; total = 72 hours. Capital at day D hour H means bonus applies for
// the remaining fraction of that day + all subsequent days.
function calcDynamicBudget(name, capitals, warbonds){
  const start = UNIVERSAL_START;
  const daily = COUNTRY_DAILY_100[name];
  if(!daily) return null;
  const baseMorale = [0.70, 0.76, 0.79];
  const effectiveMorale = [0, 0, 0];
  for(let d=0;d<3;d++){
    let bonus = 0;
    for(const cap of (capitals||[])){
      const cd=(cap.day||1)-1;
      const ch=Math.min(23,Math.max(0,cap.hour||0));
      if(cd<d) bonus+=0.10;
      else if(cd===d) bonus+=0.10*((24-ch)/24);
    }
    effectiveMorale[d]=Math.min(1.0, baseMorale[d]+bonus);
  }
  const result = {...start};
  for(let d=0;d<3;d++){
    for(const k of ["money","manpower","food","metal","oil"]){
      result[k] = (result[k]||0) + Math.round((daily[k]||0)*effectiveMorale[d]);
    }
  }
  return result;
}

// Per-day budget: returns income for a single day (1, 2, or 3)
function calcDailyBudget(name, capitals, warbonds, day){
  const daily = COUNTRY_DAILY_100[name];
  if(!daily) return null;
  const d = day - 1;
  const baseMorale = [0.70, 0.76, 0.79];
  let bonus = 0;
  for(const cap of (capitals||[])){
    const cd=(cap.day||1)-1;
    const ch=Math.min(23,Math.max(0,cap.hour||0));
    if(cd<d) bonus+=0.10;
    else if(cd===d) bonus+=0.10*((24-ch)/24);
  }
  const morale = Math.min(1.0, baseMorale[d]+bonus);
  const result = {};
  for(const k of ["money","manpower","food","metal","oil"]){
    result[k] = Math.round((daily[k]||0)*morale);
  }
  return result;
}

// Cumulative budget up to and including a given day (with start resources)
function calcCumulativeBudget(name, capitals, warbonds, upToDay){
  const daily = COUNTRY_DAILY_100[name];
  if(!daily) return null;
  const baseMorale = [0.70, 0.76, 0.79];
  const result = {...UNIVERSAL_START};
  for(let d=0; d<upToDay; d++){
    let bonus = 0;
    for(const cap of (capitals||[])){
      const cd=(cap.day||1)-1;
      const ch=Math.min(23,Math.max(0,cap.hour||0));
      if(cd<d) bonus+=0.10;
      else if(cd===d) bonus+=0.10*((24-ch)/24);
    }
    const morale = Math.min(1.0, baseMorale[d]+bonus);
    for(const k of ["money","manpower","food","metal","oil"]){
      result[k] = (result[k]||0) + Math.round((daily[k]||0)*morale);
    }
  }
  return result;
}

// Legacy static budget (fallback, kept for reference)
const COUNTRY_BUDGET={
  "Germany":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "France":{money:196386,manpower:36517,food:52413,metal:48256,oil:52413},
  "United Kingdom":{money:198048,manpower:37764,food:52413,metal:48256,oil:52413},
  "Italy":{money:196386,manpower:36517,food:52413,metal:52413,oil:48256},
  "Spain":{money:198048,manpower:37764,food:48256,metal:52413,oil:52413},
  "Communist Russia":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Sweden":{money:196386,manpower:36517,food:52413,metal:52413,oil:48256},
  "Yugoslavia":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Greater Romania":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Turkey":{money:196386,manpower:36517,food:52413,metal:52413,oil:48256},
  "Northern States of America":{money:196386,manpower:36517,food:52413,metal:48256,oil:52413},
  "Canada":{money:196386,manpower:36517,food:52413,metal:48256,oil:52413},
  "Greater Finland":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Poland":{money:196386,manpower:37349,food:52413,metal:52413,oil:48256},
  "Southern United States":{money:196386,manpower:36517,food:52413,metal:52413,oil:48256},
  "Morocco":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Algeria":{money:196386,manpower:36517,food:52413,metal:52413,oil:48256},
  "Libya":{money:196386,manpower:36517,food:52413,metal:48256,oil:52413},
  "Egypt":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Ukraine":{money:196386,manpower:36517,food:48256,metal:52413,oil:52413},
  "Caucasus":{money:196386,manpower:36517,food:52413,metal:48256,oil:52413},
  "Russian Empire":{money:198048,manpower:37764,food:52413,metal:52413,oil:48256},
};

// City data per country: each city has a name and resource type (food/metal/oil)
const COUNTRY_CITIES={
  "Germany":[{name:"Berlin",res:"oil"},{name:"Hamburg",res:"oil"},{name:"Duisburg",res:"metal"},{name:"Köln",res:"food"},{name:"Munich",res:"metal"}],
  "Algeria":[{name:"Constantine",res:"food"},{name:"Bougie",res:"metal"},{name:"Algiers",res:"oil"},{name:"Oran",res:"food"},{name:"Touggourt",res:"metal"}],
  "Canada":[{name:"Toronto",res:"oil"},{name:"Ottawa",res:"metal"},{name:"Montreal",res:"food"},{name:"Quebec",res:"oil"},{name:"Halifax",res:"food"}],
  "Caucasus":[{name:"Tiflis",res:"metal"},{name:"Grozny",res:"oil"},{name:"Voroshilovsk",res:"food"},{name:"Krasnodar",res:"oil"},{name:"Rostov",res:"food"}],
  "Communist Russia":[{name:"Moscow",res:"metal"},{name:"Yaroslavl",res:"food"},{name:"Kalinin",res:"oil"},{name:"Veliky Novgorod",res:"metal"},{name:"Leningrad",res:"oil"}],
  "Egypt":[{name:"Alexandria",res:"oil"},{name:"Cairo",res:"metal"},{name:"Gaza",res:"oil"},{name:"Amman",res:"metal"},{name:"Luxor",res:"food"}],
  "France":[{name:"Paris",res:"food"},{name:"Lyon",res:"food"},{name:"Marseille",res:"oil"},{name:"Bordeaux",res:"oil"},{name:"Nancy",res:"metal"}],
  "Greater Finland":[{name:"Helsinki",res:"oil"},{name:"Tampere",res:"food"},{name:"Turku",res:"metal"},{name:"Oulu",res:"metal"},{name:"Murmansk",res:"oil"}],
  "Greater Romania":[{name:"Budapest",res:"oil"},{name:"Debrecen",res:"food"},{name:"Bucharest",res:"oil"},{name:"Constanta",res:"metal"},{name:"Iasi",res:"metal"}],
  "Italy":[{name:"Turin",res:"metal"},{name:"Milan",res:"oil"},{name:"Genoa",res:"food"},{name:"Rome",res:"food"},{name:"Naples",res:"metal"}],
  "Libya":[{name:"Tripoli",res:"oil"},{name:"Sirte",res:"food"},{name:"Benghazi",res:"metal"},{name:"Derna",res:"food"},{name:"Tobruk",res:"oil"}],
  "Morocco":[{name:"Fes",res:"metal"},{name:"Rabat",res:"metal"},{name:"Casablanca",res:"oil"},{name:"Marrakesh",res:"oil"},{name:"Oujda",res:"food"}],
  "Northern States of America":[{name:"Washington DC",res:"oil"},{name:"Pittsburgh",res:"food"},{name:"Philadelphia",res:"metal"},{name:"New York",res:"oil"},{name:"Boston",res:"food"}],
  "Poland":[{name:"Danzig",res:"metal"},{name:"Warsaw",res:"oil"},{name:"Vilnius",res:"food"},{name:"Lvov",res:"food"},{name:"Krakow",res:"metal"}],
  "Russian Empire":[{name:"Arkhangelsk",res:"metal"},{name:"Vologda",res:"food"},{name:"Nizhny Novgorod",res:"oil"},{name:"Kazan",res:"metal"},{name:"Samara",res:"food"}],
  "Southern United States":[{name:"Jacksonville",res:"oil"},{name:"Miami",res:"food"},{name:"Savannah",res:"metal"},{name:"Charlotte",res:"food"},{name:"Atlanta",res:"metal"}],
  "Spain":[{name:"Malaga",res:"oil"},{name:"Sevilla",res:"food"},{name:"Madrid",res:"metal"},{name:"Valencia",res:"metal"},{name:"Barcelona",res:"oil"}],
  "Sweden":[{name:"Malmö",res:"food"},{name:"Gothenburg",res:"metal"},{name:"Karlskrona",res:"oil"},{name:"Stockholm",res:"metal"},{name:"Uppsala",res:"food"}],
  "Turkey":[{name:"Istanbul",res:"metal"},{name:"Ankara",res:"metal"},{name:"Izmir",res:"oil"},{name:"Adana",res:"food"},{name:"Trabzon",res:"food"}],
  "United Kingdom":[{name:"Plymouth",res:"food"},{name:"London",res:"oil"},{name:"Birmingham",res:"food"},{name:"Manchester",res:"oil"},{name:"Glasgow",res:"metal"}],
  "Ukraine":[{name:"Kiev",res:"oil"},{name:"Kremenchuk",res:"oil"},{name:"Kharkov",res:"metal"},{name:"Mariupol",res:"metal"},{name:"Odessa",res:"food"}],
  "Yugoslavia":[{name:"Dubrovnik",res:"food"},{name:"Sarajevo",res:"metal"},{name:"Split",res:"oil"},{name:"Zagreb",res:"oil"},{name:"Belgrade",res:"metal"}],
};

// Building production data: bouwtijd in uren, productie bonus per level
// Industry: % bonus op stadsresource (6000/dag basis), bouwtijden in uren
const INDUSTRY_DATA=[
  {lvl:1,buildHours:8,bonusPct:0.13},
  {lvl:2,buildHours:14,bonusPct:0.28},
  {lvl:3,buildHours:20,bonusPct:0.50},
  {lvl:4,buildHours:26,bonusPct:0.80},
  {lvl:5,buildHours:32,bonusPct:1.20},
];
// RC: % bonus op manpower (600/dag basis)
const RC_DATA=[
  {lvl:1,buildHours:6,bonusPct:0.35},
  {lvl:2,buildHours:12,bonusPct:1.00},
  {lvl:3,buildHours:18,bonusPct:2.00},
];

const GAME_DAYS=3;
const BASE_CITY_PRODUCTION=6000; // per day per stad bij 100% morale
const BASE_MANPOWER_PRODUCTION=600; // per day bij 100% morale
// Uit de game: per 10% morale stijging komen er onderstaande resources bij (voor stad & money/manpower)
// 70%→+4628, 80%→+5085, 90%→+5542, 100%→+6000 — stap = 457 resource, 46 manpower, 457 geld
const WB_PER_10PCT_RESOURCE=457; // extra resource (food/metal/oil) per 10% warbond morale
const WB_PER_10PCT_MONEY=457;    // extra geld per 10% warbond morale
const WB_PER_10PCT_MANPOWER=46;  // extra manpower per 10% warbond morale

// Geeft morale (fractie) op tijdstip timeDays (0-3) rekening houdend met capitals en warbonds
function getMoraleAtTime(timeDays, capitals, warbonds){
  const dayIdx=Math.min(2, Math.floor(timeDays));
  const base=[0.70,0.76,0.79][dayIdx];
  // Warbonds gelden alleen op dag 1 (dayIdx===0)
  const warbondBonus = dayIdx===0 ? Math.min(3,(warbonds||0))*0.10 : 0;
  let bonus=warbondBonus;
  for(const cap of (capitals||[])){
    const cd=(cap.day||1)-1;
    const ch=Math.min(23,Math.max(0,cap.hour||0));
    const capTimeDays=cd+ch/24;
    if(capTimeDays<=timeDays) bonus+=0.10;
  }
  return Math.min(1.0, base+bonus);
}

// Berekent productie per level met morale verwerkt per moment
// data = RC_DATA of INDUSTRY_DATA, capitals = [{day,hour},...]
function calcLeveledProduction(data, targetLvl, baseProduction, capitals, warbonds){
  const STEP=0.01;
  let total=0;
  let buildEnd=[];
  let t=0;
  for(let i=0;i<targetLvl;i++){t+=data[i].buildHours/24;buildEnd.push(t);}
  for(let t=0;t<GAME_DAYS;t+=STEP){
    const morale=getMoraleAtTime(t, capitals, warbonds);
    let activeBonus=0;
    for(let i=0;i<targetLvl;i++){
      const levelStart=i===0?0:buildEnd[i-1];
      const levelEnd=buildEnd[i];
      const dailyBonus=baseProduction*data[i].bonusPct;
      if(t<levelStart) break;
      if(t<levelEnd){activeBonus+=0.5*dailyBonus;break;}
      else if(i===targetLvl-1){activeBonus+=dailyBonus;}
    }
    total+=activeBonus*morale*STEP;
  }
  return Math.round(total);
}

const RESEARCH_MULT={"Pan-Asian":1,"Axis":1,"Allies":0.75,"Comintern":1};
const RES_COLORS={money:"#f59e0b",food:"#84cc16",metal:"#94a3b8",oil:"#6366f1",manpower:"#f97316"};
const RES_IMGS={
  food:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAEOklEQVR4nM2W229UVRSHv733OXN6OteWtjOU1t4YBQkIogQCMRHvb6gPvnpJfPCf8I8wvokvfYCYaEyMAUGjIrHBhgooQTSWYrG36cy0c2MuZ+/tw4imtdMWNMRfsl/OOTnf/q291tpLRDuSlvsoeT9h/x+gECBoro0lNvldC6AxFq0t2lqMbcJbyQKCAG03u7lVQGstvh+i3XfwPUXIEWgNYhVVCNDGEg8LnntikHjEoRHYdTd3R87fPxEEgWFHOsmRg2my87P40uXjzyZYKCm8kIM1hmZKC7CGvi449Pgw1WqRc+M5tBXIP51vCASLVIpaNYfnZnnlpQPIQNMRq/PBpxe5Me/huh5CGACM0ezds4ORwS789v1Mz41xfbKMdMW6xBUhDQJDT3eY25Wb+H6WaCTLU08/xOuvHeHgo2GgTqAFQgissWQyM3RvCZPqifJwOoEUBrvBaa4AKiWZmlqkp3M7bW4EYUq0yUWO7N3K2289yasvdLI1WkRrg5CSTK5GPlsi2eOz75EUvZ2N5rt1DvMvoLXgKJic1rzz7ikmxn8llRom5ChEZZG4WuaNlw/z4tF+uqMVtFVk8rCUKzI3M0MqGWPPrkGM1pt3aK3FcR2ytS2MnvyWsQtTRGJDFEt1ZmZuYfQSzx7dx7FnRkglSszNZ8lll5B4uNJj585tJCKgTesycf7xxBqk8hi/muH46DneVD4PPjDM8kIDTJ5oqMKx53cTaZec+eIKxeUyihSONITDlnhcslw2qBbJs3ZrMwGhWBdfXSpzfPQM5ZqDF+7kdqWArS8Q0rMc3j/I0UND/HTtR5RwqBSLJBI+yS7dzGS7tsc1gRYwWuP6Mb7+vsz7o5/j+km6tw7hKIHUZahm2J3u5bG9w8z9/huOgEQkTH9/D64TYFqEdN3mLYyGUJQTp6d5b/Qst20HdRNFN8CTmoFtMYb6o3iqSqGQJZ9dIhFJ4HsG26IW1wVaQKLRboyTZ2Y4Pz5PpHMn7ZFeQo5L2NNIk8PzqpQKWXRN4LsddMS7MFqv2eo2vJ6sBVdaCvUox09cYOLSNOFwL7VKnfziLVxVor8vTlCvsDCXo1zQGEPLNN3UfaiNpc0TXJ2q8uGpy1z5+SZ9w9tpD8cQWqBwSad3oJRE6wDbKp6sVRatnGpDKBLnm0uzDA5eo2H6SPd2Y3OGUtGjXC6jXIdSJYu1jZZeNg8EhG6An+STs7/Ql+pkZGAXX459R13Ncu3GLMltI2jrowMQonlbrtZdjxjGWIo6QpVuPjr9A2NXMgROD6FIkonLk9yaWaIetG7h4l6mNgv0xC1tSpIv1DmwZwAj4fzFSaxoQ5u13cFdhHTFLoG5fDNs2jhMXM+Q7IpR021Iuf6Uc09AAEc1fyqBUtVgsxWUbO3sju55TLS2uRCCQGvyhcqGsH8FXC2lNje3/WfAdWp9hf4Auza8oc+BVz0AAAAASUVORK5CYII=",
  oil:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAE60lEQVR4nL2W244kxRGGv8jMOvVpuntODLPYq91lwQIjJB6Ap+AdeQFL+MKyuPGFQbKELRvZaFkWdoadnp3pU3VVV2Vm+KLHeJfpXowvSJVUqapSfBV//KkI6Y+OlV9wmV8SBuBe9VIARDZ3dgkhKIr+jzq9EugVYtsSNRKN48WoIoKqYgSsMVhjEPSH5z8bGI1h3ygPD/qMugVrBBGASAwRHwI2SVkjPFsu+G5asm4NIDhndmZ8CyiAV2Wkno/e/Q1v9XPcekFMKoo8o5elDLtDFOHp5ZR/Xc3Qd96j8/AhF6s1H3/8CdPZAme3Q7dmqMA4Npw6y9Gqovz+KX+7fEIA3FoYZCnHR/ucTSvmacHh6w84ObjDSb/P+fuP+N2nfyaqxaC3Kr8dqOAk4uo5tpzzq8xhTu/zfLGgni9oq5rVtGTY2WPv4HXOnl7y+R/+hCly9mYLPrx3wqePzomSYORlu20FighRPRpKDkYp3dmMTjqmSjLCuE8UTzBCf3yMHR3y1bTku+WEduGw0fLg3ptknS6f/P0xeuPxVwIBTCLkRQK6pnDQa6YMBRqtkAxqbTHlmmb1jA9O73K/a7laemYIPk14cLSP+/JbfAzIC9DdLo2QkpEbh0mVmHvsOlC0KaglSoL3EWlXTL9+xOnbv6XbVcrHjzm/mPDN1YoQWkQcL4q6Q1IgQvRK0S1oqinBKLlzpCaljR6TpBg8ncxQt8Lk2fdcqzKdTaiSAt+2qN7EelG5bUBVsNZinSXNUqazOWeTSyTvIHmBZhmuKFABayxp4jCihLbBiMMYBz+q3SuBIkJd16zKFSAM9vZYNZ5pVaFZDnnBvG54dnGFbwIOQ5GmBO9p25ambYhx+8nf6dKm8TRNg/ee0WjMscDZxSW97pDZquL84pyjQY9eXtAEJTYtohEjBuL27HYCAayVGzi064bBoE9Vrnn05AlBAuPDQ46HQwqFJChr54jBE0IEa9AIRm4f/Z3tKUaIMSIiGIHCWgadDhoDw/GYo8NjnBjER4wqzlnEmE13McIORXcDjRHSLMVaBzEyn0xolguGgx51VVGXJQYh+EhoPG3b0HiPRqirNd77rb7ZCbRWsMYSQmA+mxOqFa+NR9w9vYNFWMwXaBtwCMYYIoqKYozBh0izbn5OhkqIbP7QQOKE49GAzEZCs+LkaExdlSyrkugsmqRYk5CIwxhD6hzex5u++HKaO4BCDIYqRuahptvL6dpAohVWV3RTONwfUMeaurAsBZrKkLcZiTHkaYfohRjiLVm3d4sYcUVGVXSoBkNWVrHXnkQMWkMalLtZn9Z5yusladGjCWEjbdah1ZSShIBg+Ylu8R8Rpi7jr5MJy9kl7+z1eb9/yNCmSOORdYN4Tx4F3wRiFtHUUcXIc5vwzfMZs7SAtuHHXXhrhkaEebB8fjbhy1XJZwbujQbcPzrg/nifX3e6jGJD7oVk0KVslZAkLJOML86+5R9XK65jD2du21R2zaXKpsCJthAiWVhSSGSo8Pa44N3X9nnr+JBB6uj2xkyrlt9/9hf+eH3Nc9fjKnawcjv0TuB/wcLNhSIk2pD6in6oOLDKwzt7vHHyBpOLKV98/ZR/JkMak2M0bh0sfxL40sc30CgGox6jkSIu6KaCb5W5dmjcBrYzxv8z6m9GX9nsRH7whaDIzoF5s/4NBpxpjzdkJskAAAAASUVORK5CYII=",
  money:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAE30lEQVR4nL2W229UVRSHv73PPudMZ6bTmbZT7LSUS4FiFAS5BU2KCTGEeElMTIwvGDFofDTRaKKvPpnov+CDbyY+mBCigOWioiRKgSJYoPfpTNtpZ5jpzDlzOudsHxoI2IGWPrAed3b2t9dav/3bSzQm1mieYMgnCQNQ9RaFEAixZBUArTVar74oS4Baa2o1n8AP7h2s7wPZtoVSxqqh/wNqpGHQnoqyqWc9zS1xLNPCshTSkOhAcOqnP5gYz2FZ5qqg94BCCKrVBbZv6+KzLz7ECIEd0SCqKNOk5gdYMkJzc5xvvvpuVdnBA6LRKKWIRk0cb56KV2KulEY2VMg7E1T8GYYmr7N91wae39WN61SRckmjHwe4GKYlOX3mBBguuTtTzM3PMZYdwg3mCccNfKPCwUN7UaZkNW18ABgEAU1NEQqFGf69dQ1lmfhasq57IyhNNB6i7BXYubuHvfu6cZwqUj7ey7pvtwANY+NZmuIJLl/qJxSKUHF97FAM0wpjKJNQ2Kbo5Hj1jV6i0RC1mo9Y+oaWB2qtUabi6uU0xVkfW4aZTE9TcaqM3pokO5bHd0zamtuZLeTZsHkdb7/1Gq5bfSyguN/ahAB/AeJJg4OHe7DCkp17dmAISbI5yVPJFG0tKRQhoo0JZjN3OPb+x1y4OEAkHCIIlm+q+L+XCiGoei679nXQmYrQu38/R999j2rVIxSKoowIymigUnEIR2zOnD/HkSOfMDs3j2kay0KXdFxrjalsbgzM0iCbKE2VmU3niUdbMA0bIQXzlSKZ6QmO//I904VxXj68BykhCHQdS3ww6nqpYUhKJYfJdIlnukP0nT3PXn8PN0duMlPIkc5OoixJuNGgXPI49Hovk9kcfT/3Y9sWi2a4wpIulhV8XxMOKT7/9CjXbw0QSzbQ2tGEHZMUKnkCfPbv2svsdJEFT6Fo5Osvv+XapXEaIjaBH6yspItlBaUkhWKZ3y5ewVlYQFsGPTt6iLVFeXpnNx2b2ig6d2h6qpG8m8ETBT746E1SXXE8t/ZQ5T701S7+DCFOnrpItaoZvDFIZmIKzwvIZGdYu3Y9uWKe0cwQm5/tYqY8QiQO7xx7BdNaNJHHBIKUAsfxuHFtlJZYC30/nyVixaBq4RR9WtvayJcLTOfTJNrCjGZv8mLvbl57/QCet1A3y0f6ktYa01SMj+WolWE+5/D3hX7ak+0MDQ5jaYut67bQGl9DZ3sXz23bges69GzdiG3X/77qqvSBG0lJueIxPDTLszu6uNY/wNruFPFEDO0GdKa6mCvlyWSmGb6eJp+uMHQjj+9rlBJLDH5559Uaw1AM3krjOjUS8SR9J8/QGEmgawa/nv2TH384zq99F8hN3SHZkmIqU2Bhob7HLpuhZlGxpWKVkZEcG7a0MJWd4dyp32mJJXA9h9ZYB/HOZpKJLm5eGWN0OINtm3VdZ1ngvRAwPjbHpi2dtDZ1sCaxlngkRrgxjG3b5PNFrv71D6dP/I3jBphm/blnRcC74slmC9weTPPCS3tIta3HLRYZvz3D1SsDXOkfJjdTxPMESqmHzjt1nabuRiHw/YBw2KL3wE7K5Qq3bw8xPVXCcXwMaaBMhRA8crhaMfD+bKtVFykk0jBRSt4Tx0qmuJX38O4NhSAcjizasw7QemWgu/EfoSMnLbYjj1IAAAAASUVORK5CYII=",
  metal:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAFFklEQVR4nL2WSW8cVRSFv1evqrvjntxtt91DtbGdmNhu23EIUoIYIsQqKxRBhPgdIPZI8CMQiDVCEIUQQsQkxJIpEUgIOwmeevRs99z1qh4LO8HGDkkA5WyqFlX16dy6990jwrF+zSOU8ShhAOb9HhBC7Nxozf9Rin90KITAUYp2p4Or9V/w/6BDHQohcF0Pz1P0J3roOtLF2vo61XoDwzAQwkAI0PrhPR8AakA5ilDwCCNHh+hPJLBMH5tbm5TKFfLlMo7j4HkgpQQ0D8O9CxSA8jwsUzJ8NEs6maYn1kskGscwDLpCUYLBCLFYnO3qJqXlFarVOkKIXdc8EFiEY/1aAK7nEYsGGR7MEgpFiYR7iEbiGMICQyAEeLgIIVCqTam0xFJ+iVJlhVarhevqPeB7k3ccCoHruiQSvZw+fYa11W2cjqbVVCQSCYQpabWb+E2JP2ChlEOgK0iiP0m5UmRhYZG11TWazSauy13Xh4F3HAqBUi698QhTuVGSyQFGjk2wurxNrd5EBnx0d0cxDEHHaSMlgEuzVcOQgnq9SnFxjo31NQrFCmubW3Q6DlIe7Emx96TRWmNZgkgoyrlzL5IbP0GjpdiqVmk2mwitica6sSyJZQq09pCGgasUwS4/2xsbFApL5PPzzN66zVKxiGanzIcC7ygSCTJ89DjxRJJ0Okuy3yYWi1Gv1fFcl66AHyklnucSi0apVqtoT2NJAbhsbayysbFMebnMpc8+x/X+Qhzw7LoukUiUSCRCq9nm+k/X6Y4ukkwmGR4eZsDOIA1Bq93B8xSGFASO+Oi0O1imic8K0JeIMTT8Ahcvfoj42/l016EQAsdxSKUSnD9/nlzuJDdu/MbiUplGs06tXsWSFnYqTW5iDNu2EUIgDYNms46nPKLhMLnJUTKpft5+600+vnSRlY3tw5vGUYp0spdXX3mJ0bFp2h2Xjc0GnifRWlEqFbl18xbVahXTNLDtDMdGRsik0vT1JZianKK3J4JlwjvvvMtrb7yO6fMjDWOfxz2D72Gn4jz++HHC4SBLv92msrzO2uom8XiUkZFjpFNJ5ufnKRYLFEtF6vUaS4sL5MZz+AN+vvp6gdzYKD/88D3+wBG0EAdGYxeoEUKSL1Z4//33OH58gtHRSbJ2Bu1qZmdnuHnzd7LZAbJZm4nxMUrlEjMzM5TKJRqtBjd+uU6n3WZwyCYUCWJako7jYvwNau6MAxiGQXm5yura7/zy6wzx+HecffZ5crkp+nq7yRcKrKyuUC6X6O3tYfrkNEePDTEzM0uhWKDWqBEOhXA9F2EYCK1RSuGzrHvP4Z3iAjiqQ8D08djAENPTp7CzaULBIJtb28zenqVeqzE4OMhzZ58jGAoxt7BIuVLkmafO8PNPP3LtymUazRZ/LBT2rbVD5/BO12o0juMgtGTAznDq5JNMTk2iBSwszlMsFjF9Fhk7zYmTp0gmkwT8Jm67xepKhW+/+ZoPPvr0wYB7waBxOg5aQ7K/jzOnTzMxOUE8HqeyvEKhkMcTmgsvX2B8fIwvr13l86tXmJub59ZcYd8/vC9wPxiUUrhKYWcynJjK8eSpJ0il0th2GqUcPvnkMpcuX6HRbKFckHJ/qHhg4D6wgE7HwVWKSDjI2WefJpVKcvXaF+TzJfyBwG4qOLicHxq4F7yzZdRuAtD4fBamZe0ErnvsxPumtntJ735USomUcqfJtEZ73j++96+Be8F7r/fTIw/Cjxz4J3LxSr/XNv5XAAAAAElFTkSuQmCC",
  manpower:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAE+UlEQVR4nL2W3W8cVxXAf+feOzP74d317tqOa8eJ05q6SkggNEQgxAPif4YHpMIDovBA20AhNdSpY7L+2E/Prj07szP3Xh7WdtLWbhOBcqQrXWlG93e+z5Fa84bnLYp6mzAA8zo/iQDI1R+9501c9J1AEcE5j7UO78F7j/ce8IgIIgqlBKUEEfCvQb4WKCLM8oJSaKg2yqyvNQnDEGMMxgRk6ZQ4ntA5jMmyAusEo+V7od8CzjUVsixj82aLB/ffo73SoNlqsLS0RKNex2jFdDolHsYcHnb5cvc5nz7ZJT51aK3OvfAaQBFwzqOU4tGPN7m7fYvllRZB2dBqLVJbKKHUjCgI0aJZKC3SblW4vdHixlKF3/zuE04TUEqujevXgPM4CT/7cIu7H6xjXcY0PcFEFdIEtKQsVEqYkkNcjnUFWmVUSpb797Y4PU347Uc7eAxcg7wsCxEhLyzbW6s8fnSPbJZgfYL3KXl2RjFLMMpSqQREAUSRJ4ocC2WhWhWqZc1PP7zP3a0WRZEjcnVWXwKdcyyUQx4/+iGFK3A+R2shDObH+xnWpnifUi7BUrPCarvOcqtOLVREZsaNpTKPH75LGCic81zFVJfW5ZaN9Tbv3lkHcrRRGBOgVIB4h1IFtkhIpyPwU1qLZTbeWWKlVqVZjqiajFqU8f6dVd6/3SYv7JVWGrgoaUe9VqXRaBBP+hitEZnHwXmPcxacQ5zDINSiiHq5REU0NpmivGOS5Ky2W/zi4R16/THHcUGgv55AZv4gGKO4s7mOCUKCIEBrDdjzAndoNIJHrGd2lmCnGQuNJjoI8a1FRt0BR3sdjoZTyqHh/g9WcP/uM5zM8N6fl8s3stSYAGstzs07iwBKKaBABMRBkc7Iz1JclmPTnL29Pf7y8Z85PDhhfJqReUNz7T1+/atf8ujnns8+3+UPf3pCnluUugDKvCaGoyGBCeYnMDjv5iAU4gWxgps5jAS82D/ki789ZTw6od8/QZziwb2HhPUmUwkYJZbnhx3G4xglc6VBXlrogcFwRFHkIBBFEYWdZ5p3Hqzg8nkUdr74ioPnzxHvWVtbZXF5jeXWBqM4o7N/zN7hEZ/tPOPZQcxgovBotJKXLhXAOkV/MCFNE4w25EqjUfP4eYPLPVlh6XV6DHtdQhNxc+Mm7dVlSpUKv//4E7IU4iTl77sHHMSe0zRCFAgvJ4q5sE9rxelkwng8oVqrkKbxXBUvKDEEOqB7eMTweECz0ebW5m2UMfyr0yceT6g2lumMOjx5usfBOCTLPUZ9u9+YC38qpZhOE7rdLluLm6hzC31hUWLoHvXo9YYst1dp1Ooc98ccDXr04yGjccyPHvyEz3f3eXGisc5h9NXjylzET4kwOZsxHo+pVaucDAWRgKhSxk1SescxhTX8c/c/TJKc0XjM6GzG2bQgLEX848s/4qVM4UB/x2y8TBrnPAsLZba3P6AUVWg3VxA82fSM/eMuzgbsfPWCp/t9vKmiBJyLQMpkiUcIAI+S69r2K8D5sM3Z3tpg49ZthqMB/cGY7nGHv366Q5AVVEuGZ8cJ1tQxcl6nAuBQ8jLTv0+k1rzhhXn7KkWad1Zb5HnOcDDAe0s2U5SUIArOCnNlQ34TkVfXRO89RWFBBK0NwvkGcK69eqN16Wr5xsQXwjC4hMs5SLh2Z/vfgBegy/v/CfKqvPVF+K0D/wuEbVpopn3ZBgAAAABJRU5ErkJggg==",
};
const RES_ICONS={money:"💰",food:"🌾",metal:"🔩",oil:"🛢️",manpower:"👥"};
const WARBOND_ICON="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAA9AD4DASIAAhEBAxEB/8QAHQAAAgEFAQEAAAAAAAAAAAAAAAgGAgMEBQcBCf/EAC4QAAEDAwIFAwMEAwAAAAAAAAECAwQABREGIQcSE1FhMUGBFCRxCBYioSNCUv/EABkBAAMBAQEAAAAAAAAAAAAAAAECBQQDAP/EACARAAICAgIDAQEAAAAAAAAAAAECAAMEEQUhEjFBUXH/2gAMAwEAAhEDEQA/AEyq5GZXIfQy2MqWcCrdSzQ9qeW4J3TKlZHTGPXf1pWZV7Yx0Qu2hPJOjZCUAsukqxnBGxrUS7Dc46sGOXPKN67VEZT0hzpwsjcEZI/NVPQmnGiC2k42AxtVV+PHgHqbYm1sRfhnAnWnGlFLjakKHsoYqiu6/tmHMHKYSAM7kDasKRwugS0rLLiWFpO43z8b1MvDUDbicDiv87nF6Kmuu9CO6ZgNzlSgttxfKlKscxqFUiWK42s4MpQ6My7OiI5dIyJ61IilwB1Q9Qn3pidLWjTsxtDdivMV9WAG2zkKPxil803Zp2oL3GtFtbDkqSvlQCrA+TTbcCeFthsVwRblSlSb8vIkSVpIQwPdCB39id6yZvjrs9zTiOUbYE0Vw0vPh4dfjqIHqR6fmscw0bBRCcf3TTT+H9jNmVHZQppwJIDoIyT3PzXIL1ox23S0iQW05JCkrQSR5BGxFbeJ5ZK6zVaf4ZsdwewJCbWqHHXzOoUtA3IA3zVE91p25tyosdTbI2WD7+amFw039HDbkOxHERlnZ5A6gP5CckfNaa/W96JYJci3gPOls9FA2UpXYA/NUMjHoyazYrDofsUWkCLtxt1CL1qkx2FfbRE9NIB2J71Aav3BElE15Ettxp8LPUQsEKB7EGrFTUUIoAkx2LsWMvwJcqBMamQ33GJDSgptxCsKSe4NMvwR40xbjcIsPUbjUG9NkBifslD5/wCXOxPc0sNegkHIOCKW2pbBozyuVOxPqxY7vGu7DSXnEsyFJCizzbL8p7g+O9bC4wYdzCosphKyEnkUpIJTnbINfP7g7xsn6fEezajdfk21Ch0ZKTl6N5HceDTjac4jw5dujyFvtPsOJHSnJP8AB0djj0PjFRb8ZqjN1docalCLFf8ATUiQmOBNhrClFB3QpI3xjcA49/etHqmVYL3bIs2PHahfQLK5biEhHRSM5Jx7Zxv5qaai13ATZiLMpE6c8oMpYTvgnYk+BS+fqUv8LSPCtVnt0tpy5354iQptWf8AHk84H4Ix80KVZ2A9bhY+KkxZeKOo06r13db6hoNtyXiW04/1Gw/oVGaKKvgADQk4ncKKKKM9Cpxwv4k3rREwoaxNtbx+4hOk8ix3HY1B6KDKGGjCCR6jKa74z6ZhaNKtDuvqvVzQUOdVJBgoIwoegBUfbGfSlvkPvSHC4+846tRJKlqJJJ3PrVuikrqWsaELOWPcKKKK6RZ//9k=";
function ResImg({k,size=20}){if(!RES_IMGS[k])return null;return React.createElement('img',{src:RES_IMGS[k],style:{width:size,height:size,objectFit:'contain',verticalAlign:'middle',imageRendering:'auto'}});}
const RES_KEYS=["money","food","metal","oil","manpower"];
const fmtC=(n)=>Math.round(n).toLocaleString("en-US");

function scaleCosts(costs,qty){const out={};for(const k of RES_KEYS)out[k]=(costs[k]||0)*qty;return out;}
function sumCosts(items){const total={money:0,food:0,metal:0,oil:0,manpower:0};for(const item of items){if(!item)continue;for(const k of RES_KEYS)total[k]+=(item[k]||0);}return total;}
function addCosts(a,b){const out={};for(const k of RES_KEYS)out[k]=(a[k]||0)+(b[k]||0);return out;}
function applyMult(costs,mult){const out={};for(const k of RES_KEYS)out[k]=Math.round((costs[k]||0)*mult);return out;}

function calcResearchCost(researchId,doctrine,qty){
  const chain=RESEARCH_CHAINS[researchId]||[];
  const allIds=[...chain,researchId];
  const total={money:0,food:0,metal:0,oil:0,manpower:0};
  for(const id of allIds){
    const unit=UNITS_RESEARCH.find(u=>u.id===id);
    if(!unit)continue;
    const base=unit.costs?unit.costs[doctrine]||unit.costs["Pan-Asian"]:{money:unit.money||0,food:unit.food||0,metal:unit.metal||0,oil:unit.oil||0};
    for(const k of RES_KEYS)total[k]+=(base[k]||0);
  }
  return scaleCosts(total,qty);
}

let nextId=1;
function makeCountry(preset){
  const name=preset?preset.name:"";
  const cities=(COUNTRY_CITIES[name]||[]).map(city=>({...city,buildings:[],selBuilding:"Barracks",selBuildingLvl:1,selBuildingQty:1}));
  return{
    id:nextId++,name,doctrine:preset?preset.doctrine:"Pan-Asian",
    buildings:[],items:[],tab:"cities",
    cities,
    capitals:[],
    selCapDay:1,
    selBuilding:"Barracks",selBuildingLvl:1,selBuildingQty:1,
    selProd:Object.keys(PRODUCTION[preset?preset.doctrine:"Pan-Asian"]||PRODUCTION["Pan-Asian"])[0],selProdQty:1,
    selUpgrade:Object.keys(UPGRADES[preset?preset.doctrine:"Pan-Asian"]||UPGRADES["Pan-Asian"])[0],selUpgradeQty:1,
    selResearch:UNITS_RESEARCH[0].id,selResearchQty:1,
    selUpkeepUnit:"",selUpkeepLvl:1,selUpkeepQty:1,
  };
}

// Berekent totale extra productie van alle cities, met morale per moment via capitals
function calcCityIncome(cities, capitals, warbonds){
  const income={money:0,food:0,metal:0,oil:0,manpower:0};
  if(!cities)return income;
  for(const city of cities){
    // Warbond basisinkomen: per warbond op deze stad +10% morale op dag 1
    // Basisinkomen stad = 6000/dag resource + 600/dag manpower + geld (via calcDynamicBudget)
    // Hier tellen we alleen het extra dat de warbond geeft bovenop de 70% basismorale
    const cityWb = city.warbond||0;
    if(cityWb>0){
      // Per warbond = +10% morale op dag 1
      // Uit de game: elke 10% morale geeft +457 resource, +457 geld en +46 manpower per stad per day
      // Warbonds gelden alleen dag 1, dus x1 dag
      if(city.res && RES_KEYS.includes(city.res)){
        income[city.res]=(income[city.res]||0)+(cityWb * WB_PER_10PCT_RESOURCE);
      }
      income.money=(income.money||0)+(cityWb * WB_PER_10PCT_MONEY);
      income.manpower=(income.manpower||0)+(cityWb * WB_PER_10PCT_MANPOWER);
    }
    for(const b of (city.buildings||[])){
      if(b.name==="Industry"&&b.incomeRes){
        const total=calcLeveledProduction(INDUSTRY_DATA,b.lvl,BASE_CITY_PRODUCTION,capitals||[],cityWb);
        income[b.incomeRes]=(income[b.incomeRes]||0)+total*b.qty;
      } else if(b.name==="Recruiting Station"){
        const total=calcLeveledProduction(RC_DATA,b.lvl,BASE_MANPOWER_PRODUCTION,capitals||[],cityWb);
        income.manpower=(income.manpower||0)+total*b.qty;
      } else if(b.income){
        for(const k of Object.keys(b.income)){income[k]=(income[k]||0)+b.income[k];}
      }
    }
  }
  return income;
}

function ResourceBar({costs}){
  costs=costs||{};
  return(
    <div className="afc-res" style={{display:"grid",gap:0}}>
      {RES_KEYS.map(k=>{
        const v=costs[k]||0;
        if(v===0)return <div key={k}/>;
        return(
          <div key={k} style={{display:"flex",alignItems:"center",gap:3}}>
            <ResImg k={k} size={15}/>
            <span style={{color:RES_COLORS[k],fontFamily:"monospace",fontWeight:600,fontSize:12,whiteSpace:"nowrap"}}>
              {fmtC(v)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function ItemRow({item,onRemove,onDayChange,docColor,cities,onPatch}){
  const typeColors={production:"#cbd5e1",upgrade:"#fbbf24",research:"#60a5fa",building:"#a78bfa",upkeep:"#34d399"};
  const day=item.day||1;
  const dayColors={1:"#3b82f6",2:"#a855f7",3:"#f97316"};
  return(
    <div style={{background:"#0d1117",borderRadius:4,padding:"7px 8px",marginBottom:4,borderLeft:`2px solid ${typeColors[item.type]||"#334155"}`}}>
    <div style={{display:"grid",gridTemplateColumns:"180px 1fr auto auto auto auto auto",alignItems:"center",gap:8}} className="afc-row">
      <div className="afc-lbl" style={{color:typeColors[item.type]||"#cbd5e1",fontSize:12,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
        <span style={{color:"#64748b",fontSize:11}}>×{item.qty} </span>{item.label}
      </div>
      <div>
        <ResourceBar costs={item.cost}/>
      </div>
      {onPatch&&item.type==="production"&&cities?<select value={item.city||""} onChange={e=>onPatch({city:e.target.value})} title="City that produces it" style={{background:"#1e293b",border:"1px solid #475569",borderRadius:4,color:item.city?"#e2e8f0":"#f59e0b",fontSize:11,fontWeight:700,padding:"2px 4px",width:110,minHeight:"auto",height:28}}><option value="">{cities.length?"City…":"No city with the factory"}</option>{cities.map(ci=><option key={ci.name} value={ci.name}>{ci.name}</option>)}{item.city&&!cities.some(ci=>ci.name===item.city)&&<option value={item.city}>{item.city} ⚠</option>}</select>:(item.type==="building"&&item.cityName?<span style={{fontSize:11,color:"#94a3b8",width:110}}>{item.cityName}</span>:<span/>)}
      <select value={day} onChange={e=>onDayChange&&onDayChange(Number(e.target.value))}
        style={{background:"#1e293b",border:`1px solid ${dayColors[day]}`,borderRadius:4,color:dayColors[day],fontSize:11,fontWeight:700,padding:"2px 4px",width:52,flexShrink:0,minHeight:"auto",height:28}}>
        <option value={1}>Day 1</option>
        <option value={2}>Day 2</option>
        <option value={3}>Day 3</option>
      </select>
      {onPatch&&(item.type==="production"||item.type==="building")?<select value={item.hour||0} onChange={e=>onPatch({hour:Number(e.target.value)})} title="Start hour" style={{background:"#1e293b",border:"1px solid #475569",borderRadius:4,color:"#cbd5e1",fontSize:11,fontWeight:700,padding:"2px 4px",width:64,minHeight:"auto",height:28}}>{Array.from({length:24},(_,h)=><option key={h} value={h}>{String(h).padStart(2,"0")}:00</option>)}</select>:<span/>}
      {window.AFBridge&&(item.type==="production"||item.type==="building")?<button onClick={()=>window.AFBridge.show(item.id)} title="Show on the map" style={{background:"#1e293b",color:"#b48c3c",fontSize:14,padding:"0 6px",minHeight:"auto",height:28,border:"1px solid #475569"}}>🗺</button>:<span/>}
      <button onClick={onRemove} style={{background:"none",color:"#ef4444",fontSize:18,padding:"0 4px",flexShrink:0,minHeight:"auto",lineHeight:1}}>×</button>
    </div>
    {window.AFBridge&&(item.type==="production"||item.type==="building")&&<div style={{fontSize:11,color:"#64748b",marginTop:3,paddingLeft:2}}>{window.AFBridge.info(item.id)}</div>}
    </div>
  );
}

// Helper: get unique unit names from PRODUCTION for a doctrine
function getUnitNames(doctrine){
  const keys=Object.keys(PRODUCTION[doctrine]||PRODUCTION["Pan-Asian"]);
  const names=new Set();
  keys.forEach(k=>{const m=k.match(/^(.+) Lv\d+$/);if(m)names.add(m[1]);});
  return [...names];
}
function getUnitLevels(doctrine,unitName){
  const keys=Object.keys(PRODUCTION[doctrine]||PRODUCTION["Pan-Asian"]);
  return keys.filter(k=>k===unitName+' Lv'+k.match(/Lv(\d+)/)?.[1]&&k.startsWith(unitName+' Lv')).map(k=>parseInt(k.match(/Lv(\d+)/)[1])).sort((a,b)=>a-b);
}
// Starting units of the EU22 countries
function getStartingUnits(countryName){
  return [
    {unit:"Infantry",lvl:1,qty:18},
    {unit:"Anti Tank",lvl:1,qty:3},
    {unit:"Anti Air",lvl:1,qty:3},
    {unit:"Aircraft Carrier",lvl:1,qty:1},
  ];
}
function getStartingUnitsLabel(countryName){
  return "18×Inf 3×AT 3×AA 1×AC";
}

function calcUpgradeCost(doctrine,unitName,fromLvl,toLvl,qty){
  const prod=PRODUCTION[doctrine]||PRODUCTION["Pan-Asian"];
  // Upgrade cost = 50% of the FROM level's production cost (Allies get 20% discount = 40%)
  const mult=doctrine==="Allies"?0.40:0.50;
  const fromCost=prod[unitName+' Lv'+fromLvl]||{};
  const diff={};
  const RES_KEYS2=["money","food","metal","oil","manpower"];
  for(const k of RES_KEYS2)diff[k]=Math.round((fromCost[k]||0)*mult)*qty;
  return diff;
}

function CountryCard({country:c,morale,onChange,onRemove}){
  const docColor=DOCTRINE_COLORS[c.doctrine];
  const prodOptions=Object.keys(PRODUCTION[c.doctrine]||PRODUCTION["Pan-Asian"]);
  // only units whose factory stands (or is planned) in one of this country's cities
  const afHasIn=(ci,f)=>(ci.buildings||[]).some(b=>b.name===f)||!!(window.AFBridge&&window.AFBridge.cityHas(ci.name,f));
  const afHas=f=>(c.cities||[]).some(ci=>afHasIn(ci,f));
  const afFac=u=>window.AFBridge?window.AFBridge.factory(u,c.doctrine):"";
  const prodOk=window.AFBridge?prodOptions.filter(u=>{const f=afFac(u);return f&&afHas(f);}):prodOptions;
  const selProdEff=prodOk.includes(c.selProd)?c.selProd:(prodOk[0]||"");
  const missingFac=window.AFBridge?[...new Set(prodOptions.map(afFac).filter(f=>f&&!afHas(f)))]:[];
  const upgradeOptions=Object.keys(UPGRADES[c.doctrine]||{});
  const selBldg=BUILDINGS.find(b=>b.name===c.selBuilding);
  const unitNames=getUnitNames(c.doctrine);
  const selUnitName=c.selUpgUnit||(unitNames[0]||"");
  const availLevels=selUnitName?Object.keys(PRODUCTION[c.doctrine]||PRODUCTION["Pan-Asian"]).filter(k=>k.startsWith(selUnitName+' Lv')).map(k=>parseInt(k.match(/Lv(\d+)/)[1])).sort((a,b)=>a-b):[];
  const selFromLvl=c.selUpgFrom||(availLevels[0]||1);
  const validToLevels=availLevels.filter(l=>l>selFromLvl);
  const selToLvl=c.selUpgTo||(validToLevels[0]||selFromLvl+1);

  const addBuilding=()=>{
    const bldg=BUILDINGS.find(b=>b.name===c.selBuilding);
    if(!bldg)return;
    const lvl=Math.min(c.selBuildingLvl,bldg.maxLvl);
    const cost={};
    for(let l=0;l<lvl;l++){
      bldg.res.forEach((r,i)=>{cost[r]=(cost[r]||0)+bldg.costs[l][i]*c.selBuildingQty;});
    }
    const label=lvl>1?`${bldg.name} Lv1→${lvl}`:`${bldg.name} Lv1`;
    onChange({...c,buildings:[...c.buildings,{id:nextId++,name:bldg.name,lvl,qty:c.selBuildingQty,cost,type:"building",label}]});
  };

  const addProduction=()=>{
    const prodData=PRODUCTION[c.doctrine]||PRODUCTION["Pan-Asian"];
    const base=prodData[selProdEff];
    if(!base)return;
    const cost=scaleCosts(base,c.selProdQty);
    const newItems=[{id:nextId++,label:selProdEff,qty:c.selProdQty,type:"production",cost,city:((c.cities||[]).find(ci=>afHasIn(ci,afFac(selProdEff)))||{}).name}];
    // Auto-add research indien nog niet aanwezig
    const match=selProdEff.match(/^(.+)\s+Lv(\d+)$/);
    if(match){
      const unitName=match[1];
      const lvl=parseInt(match[2]);
      const resEntry=UNITS_RESEARCH.find(u=>u.name===unitName+" "+lvl);
      if(resEntry){
        const alreadyHas=c.items.some(i=>i.type==="research"&&i.researchId===resEntry.id);
        const chain=RESEARCH_CHAINS[resEntry.id]||[];
        const chainSet2=new Set(chain);
        // Verwijder altijd lagere research (chain) die al bestaat
        c={...c,items:c.items.filter(i=>!(i.type==="research"&&chainSet2.has(i.researchId)))};
        if(!alreadyHas){
          const resCost=calcResearchCost(resEntry.id,c.doctrine,1);
          const chainStr=chain.length>0?" (incl. "+chain.join(", ")+")":"";
          newItems.push({id:nextId++,researchId:resEntry.id,label:"Research: "+resEntry.name+chainStr,qty:1,type:"research",cost:resCost});
        }
      }
    }
    onChange({...c,items:[...c.items,...newItems]});
  };

  const addUpgrade=()=>{
    const upg=UPGRADES[c.doctrine]||{};
    const base=upg[c.selUpgrade];
    if(!base)return;
    const cost=scaleCosts(base,c.selUpgradeQty);
    onChange({...c,items:[...c.items,{id:nextId++,label:`Upgrade: ${c.selUpgrade}`,qty:c.selUpgradeQty,type:"upgrade",cost}]});
  };

  const addUnitUpgrade=()=>{
    if(!selUnitName||validToLevels.length===0)return;
    const toL=c.selUpgTo||validToLevels[0];
    const fromL=c.selUpgFrom||(availLevels[0]||1);
    if(toL<=fromL)return;
    const qty=parseInt(c.selUpgUnitQty)||1;
    const cost=calcUpgradeCost(c.doctrine,selUnitName,fromL,toL,qty);
    const label=`${selUnitName} Lv${fromL}→Lv${toL}`;
    const newItems=[{id:nextId++,label,qty,type:"upgrade",cost}];
    // Also add research for the target level if available
    const UNIT_TO_RES={
      "Infantry":["INF1","INF2","INF3","INF4","INF5","INF6","INF7"],
      "Artillery":["ARTY1","ARTY2","ARTY3","ARTY4","ARTY5","ARTY6"],
      "Armored Car":["AC1","AC2","AC3","AC4","AC5"],
      "Light Tank":["LT1","LT2","LT3","LT4","LT5"],
      "Medium Tank":["MT1","MT2","MT3","MT4","MT5","MT6"],
      "Heavy Tank":["HT1","HT2","HT3","HT4"],
      "Tank Destroyer":["TD1","TD2","TD3","TD4","TD5","TD6"],
      "Anti Tank":["AT1","AT2","AT3","AT4","AT5","AT6"],
      "Anti Air":["AA1","AA2","AA3","AA4","AA5","AA6"],
      "SP Artillery":["SPA1","SPA2","SPA3","SPA4","SPA5"],
      "SP Anti Air":["SPAA1","SPAA2","SPAA3","SPAA4","SPAA5"],
      "SP Rocket Artillery":["SPRA1","SPRA2"],
      "Motorized Infantry":["MOT1","MOT2","MOT3","MOT4","MOT5","MOT6"],
      "Mechanized Infantry":["MI1","MI2","MI3","MI4","MI5"],
      "Militia":["MLT1","MLT2","MLT3","MLT4"],
      "Paratroopers":["PARA1","PARA2","PARA3","PARA4"],
      "Commandos":["CMD1","CMD2","CMD3","CMD4"],
      "Interceptor":["INT1","INT2","INT3","INT4","INT5","INT6","INT7"],
      "Tactical Bomber":["TB1","TB2","TB3","TB4","TB5","TB6","TB7"],
      "Attack Bomber":["AB1","AB2","AB3","AB4","AB5"],
      "Strategic Bomber":["SB1","SB2","SB3","SB4","SB5","SB6","SB7"],
      "Naval Bomber":["NB1","NB2","NB3","NB4","NB5","NB6","NB7"],
      "Rocket Fighter":["RF1","RF2"],
      "Nuclear Bomber":["NBMB1","NBMB2","NBMB3"],
      "Cruiser":["CL1","CL2","CL3","CL4","CL5","CL6"],
      "Destroyer":["DD1","DD2","DD3","DD4","DD5","DD6"],
      "Battleship":["BB1","BB2","BB3","BB4","BB5","BB6"],
      "Submarine":["SS1","SS2","SS3","SS4","SS5","SS6"],
      "Aircraft Carrier":["CV1","CV2","CV3","CV4","CV5","CV6"],
      "Rocket Artillery":["RA1","RA2","RA3"],
      "Railroad Gun":["RRG1","RRG2"],
      "Flying Bomb":["FB1"],
      "Rocket":["RKT1","RKT2","RKT3","RKT4"],
      "Nuclear Rocket":["NRKT1"],
      "Flame Tank":["NB1"],
    };
    const resArr=UNIT_TO_RES[selUnitName];
    if(resArr){
      // Alln het hoogste benodigde research level toevoegen (toL)
      const resId=resArr[toL-1];
      if(resId){
        const alreadyHasRes=c.items.some(i=>i.type==="research"&&i.researchId===resId)||newItems.some(i=>i.type==="research"&&i.researchId===resId);
        if(!alreadyHasRes){
          const resCost=calcResearchCost(resId,c.doctrine,1);
          const resUnit=UNITS_RESEARCH.find(u=>u.id===resId);
          const chain=RESEARCH_CHAINS[resId]||[];
          const chainStr=chain.length>0?` (incl. ${chain.join(", ")})`:"";
          // Verwijder alle lagere research voor dit unit uit c.items
          const allLowerIds=new Set(resArr.slice(0,toL-1));
          const chainSet=new Set(chain);
          const toRemove=new Set([...allLowerIds,...chainSet]);
          c={...c,items:c.items.filter(i=>!(i.type==="research"&&toRemove.has(i.researchId)))};
          newItems.push({id:nextId++,researchId:resId,label:`Research: ${resUnit?resUnit.name:resId}${chainStr}`,qty:1,type:"research",cost:resCost});
        } else {
          // Research bestaat al — verwijder wel lagere duplicaten
          const allLowerIds=new Set(resArr.slice(0,toL-1));
          c={...c,items:c.items.filter(i=>!(i.type==="research"&&allLowerIds.has(i.researchId)))};
        }
      }
    }
    onChange({...c,items:[...c.items,...newItems]});
  };

  const addResearch=()=>{
    // Blokkeer alleen als exact hetzelfde researchId al bestaat
    const alreadyAdded=c.items.some(i=>i.type==="research"&&i.researchId===c.selResearch);
    if(alreadyAdded)return;
    const cost=calcResearchCost(c.selResearch,c.doctrine,c.selResearchQty);
    const unit=UNITS_RESEARCH.find(u=>u.id===c.selResearch);
    const chain=RESEARCH_CHAINS[c.selResearch]||[];
    const chainStr=chain.length>0?` (incl. ${chain.join(", ")})`:"";
    // Verwijder lagere levels die al in de chain van dit item zitten
    const chainSet=new Set(chain);
    const filteredItems=c.items.filter(i=>!(i.type==="research"&&chainSet.has(i.researchId)));
    onChange({...c,items:[...filteredItems,{id:nextId++,researchId:c.selResearch,label:`Research: ${unit.name}${chainStr}`,qty:c.selResearchQty,type:"research",cost}]});
  };

  const removeBuilding=(id)=>onChange({...c,buildings:c.buildings.filter(b=>b.id!==id)});
  const removeItem=(id)=>onChange({...c,items:c.items.filter(i=>i.id!==id)});
  const cityBuildings=(c.cities||[]).flatMap(city=>city.buildings||[]);
  const allItems=[...c.buildings,...c.items];
  const grandTotal=sumCosts(allItems.map(i=>i.cost));
  const selDay=c.selDay||0;
  const filteredForBudget=selDay===0?allItems:allItems.filter(i=>(i.day||1)===selDay);
  const grandTotalFiltered=sumCosts(filteredForBudget.map(i=>i.cost));

  return(
    <div style={{background:"#1a1f2e",border:`1px solid ${docColor}44`,borderTop:`3px solid ${docColor}`,borderRadius:8,padding:16,marginBottom:16}}>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12,flexWrap:"wrap"}}>
        <select value={c.name} onChange={e=>{const preset=COUNTRIES.find(x=>x.name===e.target.value);const doc=preset?preset.doctrine:"Pan-Asian";const newName=e.target.value;const cities=(COUNTRY_CITIES[newName]||[]).map(city=>({...city,buildings:[],selBuilding:"Barracks",selBuildingLvl:1,selBuildingQty:1}));onChange({...c,name:newName,doctrine:doc,cities,selProd:Object.keys(PRODUCTION[doc])[0],selUpgrade:Object.keys(UPGRADES[doc])[0]});}}
          style={{background:"#0d1117",border:`1px solid ${docColor}`,borderRadius:4,color:"#fff",padding:"4px 10px",fontSize:14,fontWeight:700,flex:2}}>
          <option value="">-- Select a country --</option>
          {Object.keys(MAPS).map(mapKey=>
            <optgroup key={mapKey} label={MAPS[mapKey]}>
              {COUNTRIES.filter(ct=>ct.map===mapKey).map(ct=><option key={ct.name} value={ct.name}>{ct.name}</option>)}
            </optgroup>
          )}
        </select>
        <div style={{background:"#0d1117",border:`1px solid ${docColor}`,borderRadius:4,color:docColor,padding:"4px 10px",fontSize:13,fontWeight:600}}>{c.doctrine}</div>
        <button onClick={()=>onChange({...c,collapsed:!c.collapsed})} title={c.collapsed?"Open this country":"Collapse this country (everything is kept)"} style={{background:c.collapsed?docColor:"#1e293b",color:"#fff",padding:"4px 10px",fontSize:12,fontWeight:700}}>{c.collapsed?"▸ Open":"▾ Done"}</button>
        <button onClick={onRemove} style={{background:"#7f1d1d",color:"#fca5a5",padding:"4px 10px",fontSize:12,fontWeight:600}}>✕</button>
      </div>

      {c.collapsed?(()=>{const all=[...c.buildings,...c.items];const tot=sumCosts(all.map(i=>i.cost));const nU=c.items.filter(i=>i.type==="production").reduce((x,i)=>x+(+i.qty||1),0);const nB=c.buildings.length;const nR=c.items.filter(i=>i.type==="research").length;
        return <div onClick={()=>onChange({...c,collapsed:false})} title="Click to open" style={{cursor:"pointer",fontSize:12,color:"#94a3b8",display:"flex",gap:12,flexWrap:"wrap",alignItems:"center"}}>
          <span>✅ {nU} unit{nU===1?"":"s"} · {nB} building{nB===1?"":"s"} · {nR} research</span>
          <ResourceBar costs={tot}/>
        </div>;})():<>
      {/* Tabs */}
      <div className="tabs">
        {[["cities","🏙 Cities"],["production","⚔️ Production"],["upgrades","⬆️ Upgrades"],["research","🔬 Research"],["buildings","🏗 Buildings"]].map(([tab,label])=>(
          <button key={tab} onClick={()=>onChange({...c,tab})}
            style={{background:c.tab===tab?docColor:"#0d1117",border:`1px solid ${docColor}`,borderRadius:4,color:c.tab===tab?"#fff":docColor,padding:"6px 12px",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>
            {label}
          </button>
        ))}
      </div>

      {/* Buildings Tab */}
      {c.tab==="buildings"&&<div style={{background:"#0d1117",borderRadius:6,padding:10,marginBottom:12}}>
        <div className="add-bar">
          <select value={c.selBuilding} onChange={e=>onChange({...c,selBuilding:e.target.value,selBuildingLvl:1})} style={{flex:2}}>
            {BUILDINGS.map(b=><option key={b.name} value={b.name}>{b.name}</option>)}
          </select>
          <select value={c.selBuildingLvl} onChange={e=>onChange({...c,selBuildingLvl:Number(e.target.value)})} onFocus={e=>e.target.select()} onClick={e=>e.target.select()}>
            {selBldg&&Array.from({length:selBldg.maxLvl},(_,i)=>i+1).map(l=><option key={l} value={l}>Lvl {l}</option>)}
          </select>
          <input type="number" min={1} value={c.selBuildingQty} onChange={e=>onChange({...c,selBuildingQty:e.target.value})} onBlur={e=>{const v=parseInt(e.target.value);onChange({...c,selBuildingQty:isNaN(v)||v<1?1:v});}} onFocus={e=>e.target.select()} onClick={e=>e.target.select()} style={{width:60}}/>
          <button onClick={addBuilding} style={{background:docColor,color:"#fff",padding:"6px 14px",fontSize:13,fontWeight:700}}>+ Add</button>
        </div>
      </div>}

      {/* Production Tab */}
      {c.tab==="production"&&<div style={{background:"#0d1117",borderRadius:6,padding:10,marginBottom:12}}>
        {/* Production section */}
        <div style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:6}}>⚔️ Production</div>
        <div className="add-bar" style={{marginBottom:12}}>
          <select value={selProdEff} onChange={e=>onChange({...c,selProd:e.target.value})} style={{flex:2}} disabled={!prodOk.length}>
            {prodOk.length?prodOk.map(u=><option key={u} value={u}>{u}{window.AFBridge?"  ·  "+afFac(u):""}</option>):<option value="">No factory in your cities yet</option>}
          </select>
          <input type="number" min={1} value={c.selProdQty} onChange={e=>onChange({...c,selProdQty:e.target.value})} onBlur={e=>{const v=parseInt(e.target.value);onChange({...c,selProdQty:isNaN(v)||v<1?1:v});}} onFocus={e=>e.target.select()} onClick={e=>e.target.select()} style={{width:60}}/>
          <button onClick={addProduction} disabled={!prodOk.length} style={{background:prodOk.length?docColor:"#1e293b",color:prodOk.length?"#fff":"#475569",padding:"6px 14px",fontSize:13,fontWeight:700}}>+ Add</button>
        </div>
        {missingFac.length>0&&<div style={{fontSize:11,color:"#64748b",marginTop:-4}}>Only units from factories in your cities. Not built yet: {missingFac.join(", ")} — add them in the 🏙 Cities tab (or set the level in the planner).</div>}

      </div>}

      {/* Upgrades Tab */}
      {c.tab==="upgrades"&&<div style={{background:"#0d1117",borderRadius:6,padding:10,marginBottom:12}}>
        <div style={{fontSize:10,color:"#fbbf24",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:8}}>⬆️ Unit Upgrades</div>
        <div className="add-bar" style={{marginBottom:8}}>
          <select value={selUnitName} onChange={e=>{
            const newUnit=e.target.value;
            const lvls=Object.keys(PRODUCTION[c.doctrine]||PRODUCTION["Pan-Asian"]).filter(k=>k.startsWith(newUnit+' Lv')).map(k=>parseInt(k.match(/Lv(\d+)/)[1])).sort((a,b)=>a-b);
            const newFrom=lvls[0]||1;
            const newTo=lvls.find(l=>l>newFrom)||newFrom+1;
            onChange({...c,selUpgUnit:newUnit,selUpgFrom:newFrom,selUpgTo:newTo});
          }} style={{flex:3,minWidth:160}}>
            {unitNames.map(u=><option key={u} value={u}>{u}</option>)}
          </select>
        </div>
        <div className="add-bar" style={{marginBottom:8}}>
          <div style={{fontSize:11,color:"#64748b",flexShrink:0}}>From:</div>
          <select value={selFromLvl} onChange={e=>{
            const fl=Number(e.target.value);
            const newTo=availLevels.find(l=>l>fl)||(fl+1);
            onChange({...c,selUpgFrom:fl,selUpgTo:newTo});
          }} style={{width:80}}>
            {availLevels.slice(0,-1).map(l=><option key={l} value={l}>Lv {l}</option>)}
          </select>
          <div style={{fontSize:11,color:"#64748b",flexShrink:0}}>To:</div>
          <select value={selToLvl} onChange={e=>onChange({...c,selUpgTo:Number(e.target.value)})} style={{width:80}}>
            {validToLevels.map(l=><option key={l} value={l}>Lv {l}</option>)}
          </select>
          <div style={{fontSize:11,color:"#64748b",flexShrink:0}}>Qty:</div>
          <input type="number" min={1} value={c.selUpgUnitQty||1} onChange={e=>onChange({...c,selUpgUnitQty:e.target.value})} onBlur={e=>{const v=parseInt(e.target.value);onChange({...c,selUpgUnitQty:isNaN(v)||v<1?1:v});}} onFocus={e=>e.target.select()} style={{width:60}}/>
          <button onClick={addUnitUpgrade} disabled={validToLevels.length===0} style={{background:validToLevels.length===0?"#1e293b":"#92400e",color:validToLevels.length===0?"#475569":"#fde68a",padding:"6px 14px",fontSize:13,fontWeight:700}}>+ Add</button>
        </div>

      </div>}

      {/* Research Tab */}
      {c.tab==="research"&&<div style={{background:"#0d1117",borderRadius:6,padding:10,marginBottom:12}}>
        <div className="add-bar">
          <select value={c.selResearch} onChange={e=>onChange({...c,selResearch:e.target.value})} style={{flex:2}}>
            {UNITS_RESEARCH.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
          <input type="number" min={1} value={c.selResearchQty} onChange={e=>onChange({...c,selResearchQty:e.target.value})} onBlur={e=>{const v=parseInt(e.target.value);onChange({...c,selResearchQty:isNaN(v)||v<1?1:v});}} onFocus={e=>e.target.select()} onClick={e=>e.target.select()} style={{width:60}}/>
          {(()=>{
  const resExists=c.items.some(i=>i.type==="research"&&i.researchId===c.selResearch);
  return<button onClick={addResearch} disabled={resExists} style={{background:resExists?"#1e293b":docColor,color:resExists?"#475569":"#fff",padding:"6px 14px",fontSize:13,fontWeight:700}}>{resExists?"✓ Added":"+ Add"}</button>;
})()}
        </div>
        {(()=>{const chain=RESEARCH_CHAINS[c.selResearch]||[];return chain.length>0&&<div style={{fontSize:11,color:"#64748b",marginTop:6}}>⚠ Includes prerequisites: {chain.join(" + ")}</div>;})()}
      </div>}

      {/* Cities Tab */}
      {c.tab==="cities"&&<div style={{background:"#0d1117",borderRadius:6,padding:10,marginBottom:12}}>
        {(!c.cities||c.cities.length===0)&&<div style={{color:"#475569",fontSize:12}}>Select a country first to see cities.</div>}
        {(c.cities||[]).map((city,cityIdx)=>{
          const resColor=RES_COLORS[city.res]||"#94a3b8";
          const selBldgCity=BUILDINGS.find(b=>b.name===(city.selBuilding||"Barracks"))||BUILDINGS[0];
          const addCityBuilding=()=>{
            if(!city.selBuilding)return;
            const bldg=BUILDINGS.find(b=>b.name===city.selBuilding);
            if(!bldg)return;
            const lvl=Math.min(city.selBuildingLvl||1,bldg.maxLvl);
            const cost={};
            for(let l=0;l<lvl;l++){bldg.res.forEach((r,i)=>{cost[r]=(cost[r]||0)+bldg.costs[l][i]*(city.selBuildingQty||1);});}
            // Extra productie voor Industry en RC — income wordt live herberekend via calcCityIncome
            let income=null;
            let incomeRes=null;
            if(bldg.name==="Industry"){incomeRes=city.res;}
            if(bldg.name==="Recruiting Station"){incomeRes="manpower";}
            const label=`${city.name}: ${lvl>1?bldg.name+' Lv1→'+lvl:bldg.name+' Lv1'}`;
            const newBuilding={id:nextId++,name:bldg.name,lvl,qty:city.selBuildingQty||1,cost,type:"building",label,income,incomeRes,cityName:city.name};
            const newCities=[...c.cities];
            newCities[cityIdx]={...city,buildings:[...(city.buildings||[]),newBuilding]};
            onChange({...c,cities:newCities,buildings:[...c.buildings,newBuilding]});
          };
          const removeCityBuilding=(buildingId)=>{
            const newCities=[...c.cities];
            newCities[cityIdx]={...city,buildings:(city.buildings||[]).filter(b=>b.id!==buildingId)};
            onChange({...c,cities:newCities,buildings:c.buildings.filter(b=>b.id!==buildingId)});
          };
          // Bereken productie van deze stad — live via calcCityIncome zodat capitals meebewegen
          const cityIncome=calcCityIncome([city], c.capitals||[], 0); // warbond handled per-city inside calcCityIncome
          const hasCityIncome=Object.values(cityIncome).some(v=>v>0);
          return(
            <div key={cityIdx} style={{background:"#111827",borderRadius:6,padding:10,marginBottom:10,borderLeft:`3px solid ${resColor}`}}>
              {/* City header */}
              {(()=>{
                const totalWb=(c.cities||[]).reduce((s,ci)=>s+(ci.warbond||0),0);
                const cityWb=city.warbond||0;
                const canAdd=totalWb<3;
                const setWb=(v)=>{const nc=[...c.cities];nc[cityIdx]={...city,warbond:v};onChange({...c,cities:nc});};
                return(
                <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:8}}>
                  <span style={{fontWeight:700,fontSize:14,color:"#e2e8f0"}}>{city.name}</span>
                  <span style={{fontSize:11,color:resColor,textTransform:"uppercase",letterSpacing:1,display:"flex",alignItems:"center",gap:3}}><ResImg k={city.res} size={13}/> {city.res}</span>
                  <div style={{display:"flex",alignItems:"center",gap:4,marginLeft:4,background:"#2a1a28",borderRadius:5,padding:"3px 7px",border:"1px solid #52364d"}}>
                    <img src={WARBOND_ICON} style={{width:20,height:20,objectFit:"contain",verticalAlign:"middle"}}/>
                    <span style={{fontSize:10,color:"#c084b8",fontWeight:700,letterSpacing:0.5}}>Warbond 10% morale</span>
                    <button onClick={()=>cityWb>0&&setWb(cityWb-1)}
                      disabled={cityWb===0}
                      style={{background:cityWb>0?"#52364d":"#1e1020",color:cityWb>0?"#e9b8e0":"#3d2438",width:20,height:20,borderRadius:3,fontSize:13,fontWeight:700,border:`1px solid ${cityWb>0?"#7a4d72":"#2a1a28"}`,cursor:cityWb>0?"pointer":"not-allowed",lineHeight:1,padding:0,minHeight:"auto"}}>−</button>
                    <span style={{fontSize:13,fontWeight:700,color:cityWb>0?"#e9b8e0":"#3d2438",fontFamily:"monospace",minWidth:12,textAlign:"center"}}>{cityWb}</span>
                    <button onClick={()=>canAdd&&setWb(cityWb+1)}
                      disabled={!canAdd}
                      style={{background:canAdd?"#52364d":"#1e1020",color:canAdd?"#e9b8e0":"#3d2438",width:20,height:20,borderRadius:3,fontSize:13,fontWeight:700,border:`1px solid ${canAdd?"#7a4d72":"#2a1a28"}`,cursor:canAdd?"pointer":"not-allowed",lineHeight:1,padding:0,minHeight:"auto"}}>+</button>
                    
                  </div>
                  {hasCityIncome&&<span style={{fontSize:11,color:"#22c55e",marginLeft:"auto"}}>
                    {Object.entries(cityIncome).map(([k,v])=>v>0?<span key={k} style={{marginLeft:6,fontFamily:"monospace"}}>+{fmtC(v)} <ResImg k={k} size={13}/></span>:null)}
                  </span>}
                </div>
                );
              })()}
              {/* Add building to city */}
              {(()=>{
                const cityBldgSel=city.selBuilding||"";
                const cityBldgReady=!!cityBldgSel;
                const selBldgCityReady=BUILDINGS.find(b=>b.name===cityBldgSel)||null;
                return(
                <div className="add-bar" style={{marginBottom:8}}>
                  <select value={cityBldgSel} onChange={e=>{const nc=[...c.cities];nc[cityIdx]={...city,selBuilding:e.target.value,selBuildingLvl:1};onChange({...c,cities:nc});}} style={{flex:2}}>
                    <option value="">-- Kies gebouw --</option>
                    {BUILDINGS.filter(b=>!["Airfield","Local Industry","Fort","Harbor"].includes(b.name)).map(b=><option key={b.name} value={b.name}>{b.name}</option>)}
                  </select>
                  <select value={city.selBuildingLvl||1} disabled={!cityBldgReady} onChange={e=>{const nc=[...c.cities];nc[cityIdx]={...city,selBuildingLvl:Number(e.target.value)};onChange({...c,cities:nc});}}>
                    {cityBldgReady&&selBldgCityReady?Array.from({length:selBldgCityReady.maxLvl},(_,i)=>i+1).map(l=><option key={l} value={l}>Lv {l}</option>):<option>Lv 1</option>}
                  </select>
                  <input type="number" min={1} value={city.selBuildingQty||1} onChange={e=>{const nc=[...c.cities];nc[cityIdx]={...city,selBuildingQty:e.target.value};onChange({...c,cities:nc});}} onBlur={e=>{const v=parseInt(e.target.value);const nc=[...c.cities];nc[cityIdx]={...city,selBuildingQty:isNaN(v)||v<1?1:v};onChange({...c,cities:nc});}} onFocus={e=>e.target.select()} style={{width:55}}/>
                  <button onClick={addCityBuilding} disabled={!cityBldgReady} style={{background:cityBldgReady?docColor:"#1e293b",color:cityBldgReady?"#fff":"#475569",padding:"6px 12px",fontSize:12,fontWeight:700}}>+ Add</button>
                </div>);
              })()}
              {/* Buildings in this city */}
              {(city.buildings||[]).map(b=>{
                const typeColors={production:"#cbd5e1",upgrade:"#fbbf24",research:"#60a5fa",building:"#a78bfa",upkeep:"#34d399"};
                return(
                  <div key={b.id} style={{background:"#0d1117",borderRadius:4,padding:"5px 8px",marginBottom:4,display:"flex",alignItems:"center",gap:6,flexWrap:"wrap",borderLeft:"2px solid #a78bfa"}}>
                    <span style={{fontSize:12,color:"#a78bfa",flex:1}}><span style={{color:"#64748b",fontSize:11}}>×{b.qty} </span>{b.label.replace(city.name+": ","")}</span>
                    <ResourceBar costs={b.cost}/>
                    {b.income&&<span style={{fontSize:11,color:"#22c55e",fontFamily:"monospace",marginLeft:4}}>
                      {Object.entries(b.income).map(([k,v])=>v>0?<span key={k}>+{fmtC(v)} <ResImg k={k} size={13}/></span>:null)}
                    </span>}
                    <select value={b.day||1} onChange={e=>{const day=Number(e.target.value);const nc=[...c.cities];nc[cityIdx]={...city,buildings:(city.buildings||[]).map(x=>x.id===b.id?{...x,day}:x)};onChange({...c,cities:nc,buildings:c.buildings.map(x=>x.id===b.id?{...x,day}:x)});}}
                      style={{background:"#1e293b",border:`1px solid ${{1:"#3b82f6",2:"#a855f7",3:"#f97316"}[b.day||1]}`,borderRadius:4,color:{1:"#3b82f6",2:"#a855f7",3:"#f97316"}[b.day||1],fontSize:11,fontWeight:700,padding:"2px 4px",width:52,flexShrink:0}}>
                      <option value={1}>Day 1</option><option value={2}>Day 2</option><option value={3}>Day 3</option>
                    </select>
                    <button onClick={()=>removeCityBuilding(b.id)} style={{background:"none",color:"#ef4444",fontSize:18,padding:"0 4px",minHeight:"auto"}}>×</button>
                  </div>
                );
              })}
            </div>
          );
        })}
        {/* Show RC and Industry production separately */}
        {(()=>{
          // RC en Industry live herberekenen per stad met capitals en per-stad warbond
          const rcIncome={manpower:0};
          const indIncome={};
          for(const city of (c.cities||[])){
            const cWb=city.warbond||0;
            for(const b of (city.buildings||[])){
              if(b.name==="Recruiting Station"){
                const v=calcLeveledProduction(RC_DATA,b.lvl,BASE_MANPOWER_PRODUCTION,c.capitals||[],cWb)*b.qty;
                rcIncome.manpower=(rcIncome.manpower||0)+v;
              } else if(b.name==="Industry"&&b.incomeRes){
                const v=calcLeveledProduction(INDUSTRY_DATA,b.lvl,BASE_CITY_PRODUCTION,c.capitals||[],cWb)*b.qty;
                indIncome[b.incomeRes]=(indIncome[b.incomeRes]||0)+v;
              }
            }
          }
          const hasRC=rcIncome.manpower>0;
          const hasInd=Object.values(indIncome).some(v=>v>0);
          if(!hasRC&&!hasInd)return null;
          return(<div style={{display:"flex",flexDirection:"column",gap:6,marginTop:4}}>
            {hasRC&&<div style={{background:"#0d1a2e",borderRadius:6,padding:8,borderLeft:"3px solid #f97316"}}>
              <div style={{fontSize:10,color:"#f97316",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:4}}>👥 RC Extra Manpower (3 days)</div>
              <div className="total-grid">
                {Object.entries(rcIncome).map(([k,v])=>v>0?<div key={k} style={{textAlign:"center"}}>
                  <div><ResImg k={k} size={20}/></div>
                  <div style={{fontSize:13,fontWeight:700,color:"#f97316",fontFamily:"monospace"}}>+{fmtC(v)}</div>
                </div>:null)}
              </div>
            </div>}
            {hasInd&&<div style={{background:"#0d2211",borderRadius:6,padding:8,borderLeft:"3px solid #22c55e"}}>
              <div style={{fontSize:10,color:"#22c55e",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:4}}>🏭 Industry Extra Production (3 days)</div>
              <div className="total-grid">
                {Object.entries(indIncome).map(([k,v])=>v>0?<div key={k} style={{textAlign:"center"}}>
                  <div><ResImg k={k} size={20}/></div>
                  <div style={{fontSize:13,fontWeight:700,color:"#22c55e",fontFamily:"monospace"}}>+{fmtC(v)}</div>
                </div>:null)}
              </div>
            </div>}
          </div>);
        })()}
      </div>}

      {/* Items list */}
      {allItems.length>0&&<div style={{marginBottom:10}}>
        {c.buildings.map(b=><ItemRow key={b.id} item={b}
          onPatch={p=>onChange({...c,buildings:c.buildings.map(x=>x.id===b.id?{...x,...p}:x),cities:(c.cities||[]).map(ci=>({...ci,buildings:(ci.buildings||[]).map(x=>x.id===b.id?{...x,...p}:x)}))})}
          onRemove={()=>onChange({...c,buildings:c.buildings.filter(x=>x.id!==b.id),cities:(c.cities||[]).map(ci=>({...ci,buildings:(ci.buildings||[]).filter(x=>x.id!==b.id)}))})}
          onDayChange={day=>onChange({...c,buildings:c.buildings.map(x=>x.id===b.id?{...x,day}:x)})}
          docColor={docColor}/>)}
        {c.items.map(i=><ItemRow key={i.id} item={i} cities={(c.cities||[]).filter(ci=>{const f=afFac(i.label);return !f||afHasIn(ci,f);})}
          onPatch={p=>onChange({...c,items:c.items.map(x=>x.id===i.id?{...x,...p}:x)})}
          onRemove={()=>removeItem(i.id)}
          onDayChange={day=>onChange({...c,items:c.items.map(x=>x.id===i.id?{...x,day}:x)})}
          docColor={docColor}/>)}
      </div>}

      {/* Total with day filter */}
      {allItems.length>0&&(()=>{
        const selDay=c.selDay||0;
        const dayColors={0:"#64748b",1:"#3b82f6",2:"#a855f7",3:"#f97316"};
        const filteredItems=selDay===0?allItems:allItems.filter(i=>(i.day||1)===selDay);
        const filteredTotal=sumCosts(filteredItems.map(i=>i.cost));
        return(<div style={{background:"#0d1117",borderRadius:6,padding:10,borderLeft:`3px solid ${docColor}`}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8,flexWrap:"wrap"}}>
            <div style={{fontSize:10,color:"#64748b",fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginRight:4}}>Total Cost</div>
            {[0,1,2,3].map(d=><button key={d} onClick={()=>onChange({...c,selDay:d})}
              style={{padding:"2px 8px",fontSize:11,fontWeight:700,borderRadius:4,
                background:selDay===d?dayColors[d]:"#1e293b",
                color:selDay===d?"#fff":dayColors[d],
                border:`1px solid ${dayColors[d]}`}}>
              {d===0?"All":` Day ${d}`}
            </button>)}
          </div>
          <div className="total-grid">
            {RES_KEYS.map(k=>(filteredTotal[k]||0)>0?<div key={k} style={{textAlign:"center"}}>
              <div><ResImg k={k} size={24}/></div>
              <div style={{fontSize:14,fontWeight:700,color:RES_COLORS[k],fontFamily:"monospace"}}>{fmtC(filteredTotal[k])}</div>
            </div>:null)}
          </div>
        </div>);
      })()}

      {/* Capitals UI — onderin */}
      {c.name&&(()=>{
        const caps=c.capitals||[];
        const dayColors2={1:"#3b82f6",2:"#a855f7",3:"#f97316"};
        // Calculate effective morale per day for display
        // Display always shows full +10% per capital (no fraction) — budget calc still uses the fraction
        const baseMorale=[70,76,79];
        const dispMorale=baseMorale.map((base,di)=>{
          let bonus=0;
          for(const cap of caps){
            const cd=(cap.day||1)-1;
            if(cd<=di) bonus+=10;
          }
          return Math.min(100, base+bonus);
        });
        return(
          <div style={{background:"#0d1117",borderRadius:6,padding:10,marginTop:8,borderLeft:"3px solid #f59e0b"}}>

            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8,flexWrap:"wrap",gap:4}}>
              <div style={{fontSize:11,color:"#f59e0b",fontWeight:700,letterSpacing:1,textTransform:"uppercase"}}>🏛 Capitals (+10% morale)</div>
              <button onClick={()=>onChange({...c,capitals:[...caps,{id:nextId++,day:2,hour:0}]})}
                style={{background:"#92400e",color:"#fde68a",padding:"4px 12px",fontSize:12,fontWeight:700,borderRadius:4}}>
                + Capital
              </button>
            </div>
            {caps.length>0&&(
              <div style={{display:"flex",flexDirection:"column",gap:4,marginBottom:8}}>
                {caps.map((cap,ci)=>{
                  const dc=cap.day||1;
                  const hc=cap.hour||0;
                  const fracRemaining=((24-hc)/24*100).toFixed(0);
                  return(
                    <div key={cap.id} style={{display:"flex",alignItems:"center",gap:6,background:"#1a1f2e",borderRadius:5,padding:"5px 8px",border:`1px solid ${dayColors2[dc]}44`,flexWrap:"wrap"}}>
                      <span style={{fontSize:11,color:"#f59e0b",fontWeight:700,minWidth:20}}>🏛 {ci+1}</span>
                      <span style={{fontSize:10,color:"#64748b"}}>Day:</span>
                      <select value={dc} onChange={e=>{const nc=[...caps];nc[ci]={...cap,day:Number(e.target.value)};onChange({...c,capitals:nc});}}
                        style={{background:"#0d1117",border:`1px solid ${dayColors2[dc]}`,borderRadius:3,color:dayColors2[dc],fontWeight:700,fontSize:11,padding:"2px 4px",width:60}}>
                        <option value={2}>Day 2</option>
                        <option value={3}>Day 3</option>
                      </select>
                      <span style={{fontSize:10,color:"#64748b"}}>Uur:</span>
                      <input type="number" min={0} max={23} value={hc}
                        onChange={e=>{const v=Math.min(23,Math.max(0,parseInt(e.target.value)||0));const nc=[...caps];nc[ci]={...cap,hour:v};onChange({...c,capitals:nc});}}
                        onFocus={e=>e.target.select()}
                        style={{width:44,background:"#0d1117",border:`1px solid ${dayColors2[dc]}`,borderRadius:3,color:dayColors2[dc],fontWeight:700,fontSize:11,padding:"2px 4px",textAlign:"center"}}/>
                      <span style={{fontSize:10,color:"#475569",flex:1}}>({fracRemaining}% van dag {dc} telt mee)</span>
                      <button onClick={()=>onChange({...c,capitals:caps.filter((_,i)=>i!==ci)})}
                        style={{background:"none",color:"#ef4444",fontSize:16,padding:"0 3px",minHeight:"auto",lineHeight:1}}>×</button>
                    </div>
                  );
                })}
              </div>
            )}
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {[0,1,2].map(di=>{
                const col=dayColors2[di+1];
                const capBonusThisDay=dispMorale[di]-baseMorale[di];
                const hasBonus=capBonusThisDay>0.01;
                // Always show full base morale; show cap bonus separately
                return(
                  <div key={di} style={{background:hasBonus?"#1a1200":"#1a1f2e",borderRadius:6,padding:"6px 12px",border:`1px solid ${col}33`,flex:1,minWidth:70,textAlign:"center"}}>
                    <div style={{fontSize:9,color:col,fontWeight:700,letterSpacing:1,textTransform:"uppercase"}}>Day {di+1}</div>
                    <div style={{fontSize:15,fontWeight:700,color:hasBonus?"#f59e0b":col,fontFamily:"monospace"}}>
                      {hasBonus?dispMorale[di].toFixed(1):baseMorale[di]}%
                    </div>
                    <div style={{fontSize:9,color:"#475569"}}>
                      {hasBonus?`${baseMorale[di]}% + capitals`:"base"}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })()}

      {/* Budget remaining */}
      {(()=>{
        const budget=c.name?calcDynamicBudget(c.name,c.capitals||[],(c.cities||[]).reduce((s,ci)=>s+(ci.warbond||0),0)):null;
        if(!budget)return null;
        const cityIncome=calcCityIncome(c.cities, c.capitals||[], (c.cities||[]).reduce((s,ci)=>s+(ci.warbond||0),0));
        // Upkeep multiplier per productiedag: dag1=3 days, dag2=1.5, dag3=0.5
        const upkeepDayMult={1:2.5,2:1.5,3:0.5};
        const autoUpkeep={};
        // Starting units upkeep (varies by map, see getStartingUnits)
        const STARTING_UNITS=getStartingUnits(c.name);
        for(const su of STARTING_UNITS){
          const data=UPKEEP_COSTS[su.unit+" "+su.lvl];
          if(!data)continue;
          const costs=data[c.doctrine]||data["Axis"]||{};
          // Starting units are always there all 3 days = multiply by 3
          for(const k of RES_KEYS) autoUpkeep[k]=(autoUpkeep[k]||0)+(costs[k]||0)*su.qty*3;
        }
        for(const item of c.items.filter(i=>i.type==="production")){
          const match=item.label.match(/^(.+)\s+Lv(\d+)$/);
          if(!match)continue;
          const upkeepKey=match[1]+" "+parseInt(match[2]);
          const data=UPKEEP_COSTS[upkeepKey];
          if(!data)continue;
          const costs=data[c.doctrine]||data["Axis"]||{};
          const mult=upkeepDayMult[item.day||1]||3;
          for(const k of RES_KEYS) autoUpkeep[k]=(autoUpkeep[k]||0)+(costs[k]||0)*(item.qty||1)*mult;
        }
        const remaining={};
        let anyNegative=false;
        for(const k of RES_KEYS){remaining[k]=(budget[k]||0)+(cityIncome[k]||0)-(grandTotalFiltered[k]||0)-(autoUpkeep[k]||0);if(remaining[k]<0)anyNegative=true;}
        const _caps=c.capitals||[];
        const _bm=[70,76,79];
        const _dm=_bm.map((base,di)=>{let b=0;for(const cap of _caps){const cd=(cap.day||1)-1;if(cd<=di)b+=10;}return Math.min(100, base+b);});
        const moraleStr=`Day1:${_dm[0].toFixed(1)}% Day2:${_dm[1].toFixed(1)}% Day3:${_dm[2].toFixed(1)}%`;
        return(
          <div style={{background:"#0d1117",borderRadius:6,padding:10,borderLeft:`3px solid ${anyNegative?"#ef4444":"#22c55e"}`,marginTop:8}}>
            <div style={{fontSize:10,color:"#64748b",fontWeight:700,letterSpacing:1,marginBottom:6,textTransform:"uppercase"}}>
              Budget Remaining <span style={{color:"#475569",fontWeight:400}}>({moraleStr} + city production)</span>
            </div>
            <div className="total-grid">
              {RES_KEYS.map(k=>{
                const r=remaining[k];
                const hasCost=(grandTotal[k]||0)>0||(budget[k]||0)>0||(cityIncome[k]||0)>0;
                if(!hasCost)return null;
                return(<div key={k} style={{textAlign:"center"}}>
                  <div><ResImg k={k} size={24}/></div>
                  <div style={{fontSize:14,fontWeight:700,color:r<0?"#ef4444":"#22c55e",fontFamily:"monospace"}}>{r<0?"-":""}{fmtC(Math.abs(r))}</div>
                </div>);
              })}
            </div>
            {anyNegative&&<div style={{fontSize:11,color:"#ef4444",marginTop:6}}>⚠ Over budget on one or more resources!</div>}

            {/* Upkeep section */}
            {(()=>{
              // Starting units (varies by map, see getStartingUnits)
              const STARTING_UNITS=getStartingUnits(c.name);
              const startCost={};
              for(const su of STARTING_UNITS){
                const data=UPKEEP_COSTS[su.unit+" "+su.lvl];
                if(!data)continue;
                const uc=data[c.doctrine]||data["Axis"]||{};
                for(const k of RES_KEYS) startCost[k]=(startCost[k]||0)+(uc[k]||0)*su.qty*3;
              }
              // Produced units
              const prodItems=c.items.filter(i=>i.type==="production");
              const grouped={};
              for(const item of prodItems){
                const match=item.label.match(/^(.+)\s+Lv(\d+)$/);
                if(!match)continue;
                const unitName=match[1],lvl=parseInt(match[2]),day=item.day||1;
                const baseKey=unitName+" "+lvl;
                if(!UPKEEP_COSTS[baseKey])continue;
                const upkeepKey=unitName+" "+lvl+"-day"+day;
                if(!grouped[upkeepKey])grouped[upkeepKey]={unitName,lvl,qty:0,day,baseKey};
                grouped[upkeepKey].qty+=item.qty||1;
              }
              const entries=Object.entries(grouped);
              const upkeepMult={1:2.5,2:1.5,3:0.5};
              const prodCost={};
              for(const [,{unitName,lvl,qty,day,baseKey}] of entries){
                const data=UPKEEP_COSTS[baseKey];
                const uc=data[c.doctrine]||data["Axis"]||{};
                const mult=upkeepMult[day||1]||3;
                for(const k of RES_KEYS) prodCost[k]=(prodCost[k]||0)+(uc[k]||0)*qty*mult;
              }
              // Combined total
              const totalUpkeep={};
              for(const k of RES_KEYS) totalUpkeep[k]=(startCost[k]||0)+(prodCost[k]||0);
              const hasAny=RES_KEYS.some(k=>(totalUpkeep[k]||0)>0);
              if(!hasAny)return null;
              return(
                <div style={{marginTop:10,background:"#060c14",borderRadius:6,border:"1px solid #1e293b",overflow:"hidden"}}>
                  {/* Header */}
                  <div style={{background:"#0d1a1a",padding:"6px 10px",borderBottom:"1px solid #1e293b",display:"flex",alignItems:"center",gap:6}}>
                    <span style={{fontSize:10,color:"#34d399",fontWeight:700,letterSpacing:1,textTransform:"uppercase"}}>⚙️ Upkeep (3-day total)</span>
                  </div>
                  <div style={{padding:"8px 10px"}}>
                    {/* Starting units row */}
                    <div className="afc-kv" style={{display:"grid",alignItems:"center",gap:8,marginBottom:4}}>
                      <span style={{color:"#64748b",fontSize:11}}>Starting units ({getStartingUnitsLabel(c.name)})</span>
                      <ResourceBar costs={startCost}/>
                    </div>
                    {/* Produced units */}
                    {entries.map(([key,{unitName,lvl,qty,day,baseKey}])=>{
                      const data=UPKEEP_COSTS[baseKey];
                      const uc=data[c.doctrine]||data["Axis"]||{};
                      const mult=upkeepMult[day||1]||3;
                      const lineCost={};
                      for(const k of RES_KEYS) lineCost[k]=(uc[k]||0)*qty*mult;
                      return(
                        <div key={key} className="afc-kv" style={{display:"grid",alignItems:"center",gap:8,marginBottom:4}}>
                          <span style={{color:"#94a3b8",fontSize:11}}>{unitName} Lv{lvl} ×{qty} <span style={{color:"#475569",fontSize:10}}>×{mult}d</span></span>
                          <ResourceBar costs={lineCost}/>
                        </div>
                      );
                    })}
                    {/* Total row */}
                    <div className="afc-kv" style={{borderTop:"1px solid #1e293b",marginTop:6,paddingTop:6,display:"grid",alignItems:"center",gap:8}}>
                      <span style={{color:"#e2e8f0",fontWeight:700,fontSize:11}}>Total upkeep</span>
                      <ResourceBar costs={totalUpkeep}/>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        );
      })()}
      </>}
    </div>
  );
}

function App(){
  const[countries,setCountries]=useState(()=>afLoad());
  const[,afTick]=useState(0);
  React.useEffect(()=>{ if(window.AFBridge) window.AFBridge.save(countries); },[countries]);
  React.useEffect(()=>{ const onL=()=>setCountries(afLoad()); const onT=()=>afTick(x=>x+1); window.addEventListener('afcalc-load',onL); window.addEventListener('afcalc-tick',onT); return()=>{ window.removeEventListener('afcalc-load',onL); window.removeEventListener('afcalc-tick',onT); }; },[]);
  const[sidebarDay,setSidebarDay]=useState(0);
  const[mobilePanel,setMobilePanel]=useState('calc');
  const[screen,setScreen]=useState('calculator');
  const[saves,setSaves]=useState([]);
  const[currentSaveName,setCurrentSaveName]=useState('');
  const[newBuildName,setNewBuildName]=useState('');
  const[showTeamPanel,setShowTeamPanel]=useState(false);
  const[userNames,setUserNames]=useState({});
  const[userColors,setUserColors]=useState({}); // {sessionId: color}

  // Load saves list from Firebase
  React.useEffect(()=>{
    const init=()=>{
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      // Mark as connected
      setSyncStatus('synced');
      const dbRef=window._firebaseRef(db,'calculator/saves');
      window._firebaseOnValue(dbRef,(snapshot)=>{
        const data=snapshot.val();
        if(data){
          const list=Object.entries(data).map(([key,val])=>({key,...val}));
          list.sort((a,b)=>b.updatedAt-a.updatedAt);
          setSaves(list);
        } else {
          setSaves([]);
        }
      });
    };
    if(window._firebaseReady){init();}
    else{window.addEventListener('firebaseReady',init);}
    return()=>window.removeEventListener('firebaseReady',init);
  },[]);

  const saveBuild=(name)=>{
    if(!window._firebaseDb||!name.trim())return;
    const db=window._firebaseDb;
    const key=name.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
    const dbRef=window._firebaseRef(db,'calculator/saves/'+key);
    window._firebaseSet(dbRef,{
      name:name.trim(),
      countries:JSON.stringify(countries),
      updatedAt:Date.now()
    }).then(()=>{
      setCurrentSaveName(name.trim());
      setShowSaveDialog(false);
      setNewBuildName('');
    });
  };

  const loadBuild=(save)=>{
    try{
      const loaded=JSON.parse(save.countries);
      if(Array.isArray(loaded)){
        setCountries(loaded);
        setCurrentSaveName(save.name);
        setScreen('calculator');
      }
    }catch(e){console.error(e);}
  };

  const deleteBuild=(save,e)=>{
    e.stopPropagation();
    if(!confirm('Delete "'+save.name+'"?'))return;
    if(!window._firebaseDb)return;
    const db=window._firebaseDb;
    const dbRef=window._firebaseRef(db,'calculator/saves/'+save.key);
    window._firebaseSet(dbRef,null);
  };

  const newBuild=(name)=>{
    setCountries([makeCountry(null)]);
    setCurrentSaveName(name||'New Build');
    setScreen('calculator');
  };
  const[showSaveDialog,setShowSaveDialog]=useState(false);
  const[syncStatus,setSyncStatus]=useState('synced');
  const[lastSaved,setLastSaved]=useState(null);
  const isUpdatingFromDb=React.useRef(false);
  const[presentUsers,setPresentUsers]=useState([]);
  const myPresenceRef=React.useRef(null);
  const mySessionId=React.useRef('u_'+Math.random().toString(36).slice(2,8));

  // Presence: register this user and track others in the same build
  React.useEffect(()=>{
    if(!currentSaveName)return;
    const init=()=>{
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const presenceBase=window._firebaseRef(db,'calculator/presence/'+buildKey);
      const myRef=window._firebaseRef(db,'calculator/presence/'+buildKey+'/'+mySessionId.current);
      myPresenceRef.current=myRef;
      const initialData={sessionId:mySessionId.current,joinedAt:Date.now(),viewing:null,lastSeen:Date.now()};
      window._firebaseSet(myRef,initialData);
      window._firebaseOnDisconnect(myRef).remove();
      window._firebaseOnValue(presenceBase,(snap)=>{
        const data=snap.val();
        if(!data){setPresentUsers([]);return;}
        const now=Date.now();
        const users=Object.values(data).filter(u=>u.sessionId!==mySessionId.current&&(now-u.lastSeen)<20000);
        setPresentUsers(users);
      });
    };
    if(window._firebaseReady)init();
    else window.addEventListener('firebaseReady',init);
    return()=>{
      if(myPresenceRef.current)window._firebaseRemove(myPresenceRef.current);
      window.removeEventListener('firebaseReady',init);
    };
  },[currentSaveName]);

  // Heartbeat to keep presence alive + clean up stale users
  React.useEffect(()=>{
    const interval=setInterval(()=>{
      if(!myPresenceRef.current||!window._firebaseDb)return;
      window._firebaseOnValue(myPresenceRef.current,(snap)=>{
        const cur=snap.val();
        if(cur)window._firebaseSet(myPresenceRef.current,{...cur,lastSeen:Date.now()});
      },{onlyOnce:true});
    },5000);
    return()=>clearInterval(interval);
  },[]);

  // Remote cursors state: {sessionId: {x, y, name, color, lastSeen}}
  const[remoteCursors,setRemoteCursors]=useState({});
  const cursorColors=['#f87171','#fb923c','#facc15','#4ade80','#60a5fa','#c084fc','#f472b6'];
  const myColor=cursorColors[mySessionId.current.split('').reduce((a,c)=>a+c.charCodeAt(0),0)%cursorColors.length];
  const mouseThrottle=React.useRef(null);

  const myViewingName=React.useRef('User');

  // Load saved name from localStorage on mount
  React.useEffect(()=>{
    const saved=localStorage.getItem('af_username');
    if(saved){myUserName.current=saved;myViewingName.current=saved;}
  },[]);

  // Broadcast own mouse position - use pageX/pageY and send scrollY so receiver can compute correctly
  React.useEffect(()=>{
    if(!currentSaveName)return;
    const onMove=(e)=>{
      if(mouseThrottle.current)return;
      mouseThrottle.current=setTimeout(()=>{mouseThrottle.current=null;},50);
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const cursorRef=window._firebaseRef(db,'calculator/cursors/'+buildKey+'/'+mySessionId.current);
      window._firebaseSet(cursorRef,{
        x:Math.round(e.clientX/window.innerWidth*10000)/100,
        y:Math.round((e.clientY+window.scrollY)/Math.max(document.documentElement.scrollHeight,window.innerHeight)*10000)/100,
        color:myColor,
        name:myViewingName.current,
        lastSeen:Date.now()
      });
    };
    window.addEventListener('mousemove',onMove);
    return()=>window.removeEventListener('mousemove',onMove);
  },[currentSaveName]);

  // Listen to remote cursors
  React.useEffect(()=>{
    if(!currentSaveName)return;
    const init=()=>{
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const cursorsRef=window._firebaseRef(db,'calculator/cursors/'+buildKey);
      window._firebaseOnValue(cursorsRef,(snap)=>{
        const data=snap.val();
        if(!data){setRemoteCursors({});return;}
        const now=Date.now();
        const fresh={};
        for(const[sid,cur] of Object.entries(data)){
          if(sid===mySessionId.current)continue;
          if(now-cur.lastSeen>8000)continue;
          fresh[sid]=cur;
        }
        setRemoteCursors(fresh);
      });
    };
    if(window._firebaseReady)init();
    else window.addEventListener('firebaseReady',init);
  },[currentSaveName]);

  // Clean up own cursor on disconnect
  React.useEffect(()=>{
    if(!currentSaveName||!window._firebaseDb)return;
    const db=window._firebaseDb;
    const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
    const cursorRef=window._firebaseRef(db,'calculator/cursors/'+buildKey+'/'+mySessionId.current);
    window._firebaseOnDisconnect(cursorRef).remove();
  },[currentSaveName]);

  // Update detailed presence: country, tab, last action
  const myUserName=React.useRef('');

  const updateMyPresence=(info)=>{
    if(info.country)myViewingName.current=info.country;
    if(!myPresenceRef.current)return;
    window._firebaseSet(myPresenceRef.current,{
      sessionId:mySessionId.current,
      joinedAt:Date.now(),
      viewing:info.country||null,
      tab:info.tab||null,
      lastAction:info.lastAction||null,
      lastSeen:Date.now(),
      userName:myUserName.current||null,
      color:cursorColors[mySessionId.current.split('').reduce((a,c)=>a+c.charCodeAt(0),0)%cursorColors.length]
    });
  };
  // Keep backward compat
  const updateMyViewing=(name)=>updateMyPresence({country:name});

  // Sync userNames+colors from Firebase
  const myColorRef=React.useRef(cursorColors[mySessionId.current.split('').reduce((a,c)=>a+c.charCodeAt(0),0)%cursorColors.length]);
  React.useEffect(()=>{
    if(!currentSaveName)return;
    const init=()=>{
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const namesRef=window._firebaseRef(db,'calculator/usernames/'+buildKey);
      window._firebaseOnValue(namesRef,(snap)=>{
        const data=snap.val()||{};
        const names={},colors={};
        for(const[sid,val] of Object.entries(data)){
          if(typeof val==='string'){names[sid]=val;}
          else if(val&&typeof val==='object'){
            if(val.name)names[sid]=val.name;
            if(val.color){colors[sid]=val.color;if(sid===mySessionId.current)myColorRef.current=val.color;}
          }
        }
        setUserNames(names);
        setUserColors(colors);
        if(names[mySessionId.current]){
          myUserName.current=names[mySessionId.current];
        } else {
          // Auto-publish saved name from localStorage on first join
          const saved=localStorage.getItem('af_username');
          if(saved&&saved.trim()){
            myUserName.current=saved;
            const buildKey2=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
            const myRef=window._firebaseRef(db,'calculator/usernames/'+buildKey2+'/'+mySessionId.current);
            window._firebaseSet(myRef,{name:saved,color:myColorRef.current});
          }
        }
      });
    };
    if(window._firebaseReady)init();
    else window.addEventListener('firebaseReady',init);
  },[currentSaveName]);

  const saveMyProfile=(name,color)=>{
    if(!window._firebaseDb||!currentSaveName)return;
    const db=window._firebaseDb;
    const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
    const nameRef=window._firebaseRef(db,'calculator/usernames/'+buildKey+'/'+mySessionId.current);
    window._firebaseSet(nameRef,{name:name||myUserName.current||'',color:color||myColorRef.current});
    if(name)myUserName.current=name;
    if(color)myColorRef.current=color;
  };

  const setMyUserName=(name)=>{
    if(name)localStorage.setItem('af_username',name);
    saveMyProfile(name,null);
  };
  const setMyColor=(color)=>saveMyProfile(null,color);

  // Live sync: listen to live-changes from others for this build
  const lastBroadcastAt=React.useRef(0);
  React.useEffect(()=>{
    if(!currentSaveName)return;
    const init=()=>{
      if(!window._firebaseDb)return;
      const db=window._firebaseDb;
      const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const liveRef=window._firebaseRef(db,'calculator/live/'+buildKey);
      const unsub=window._firebaseOnValue(liveRef,(snap)=>{
        const data=snap.val();
        if(!data)return;
        if(data.by===mySessionId.current)return; // eigen broadcast, negeer
        if(data.at<=lastBroadcastAt.current)return; // ouder dan ons laatste, negeer
        if(data.countries){
          try{
            const loaded=JSON.parse(data.countries);
            if(Array.isArray(loaded)){
              isUpdatingFromDb.current=true;
              // Bewaar lokale tab-staat per country id
              setCountries(prev=>{
                const localTabs={};
                for(const c of prev) localTabs[c.id]=c.tab;
                return loaded.map(c=>({...c,tab:localTabs[c.id]??c.tab}));
              });
              setTimeout(()=>{isUpdatingFromDb.current=false;},200);
            }
          }catch(e){}
        }
      });
      return unsub;
    };
    let unsub;
    if(window._firebaseReady)unsub=init();
    else window.addEventListener('firebaseReady',()=>{unsub=init();});
    return()=>{if(typeof unsub==='function')unsub();};
  },[currentSaveName]);

  // Always keep a ref to latest countries for use in callbacks/timeouts
  const countriesRef=React.useRef(countries);
  React.useEffect(()=>{countriesRef.current=countries;},[countries]);

  // Auto-save current build when countries change
  const saveTimeout=React.useRef(null);
  React.useEffect(()=>{
    if(!window._firebaseDb||!currentSaveName||syncStatus==='connecting')return;
    if(isUpdatingFromDb.current)return; // ontvangen van iemand anders, niet opnieuw sturen
    setSyncStatus('saving');
    const now=Date.now();
    lastBroadcastAt.current=now;
    // Broadcast live naar anderen direct (geen debounce)
    const db=window._firebaseDb;
    const buildKey=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
    const liveRef=window._firebaseRef(db,'calculator/live/'+buildKey);
    window._firebaseSet(liveRef,{countries:JSON.stringify(countries),by:mySessionId.current,at:now});
    if(saveTimeout.current)clearTimeout(saveTimeout.current);
    saveTimeout.current=setTimeout(()=>{
      // Gebruik ref zodat we altijd de nieuwste state opslaan
      const latest=countriesRef.current;
      const key=currentSaveName.trim().replace(/[^a-zA-Z0-9_-]/g,'_');
      const dbRef=window._firebaseRef(db,'calculator/saves/'+key);
      window._firebaseSet(dbRef,{
        name:currentSaveName.trim(),
        countries:JSON.stringify(latest),
        updatedAt:Date.now()
      }).then(()=>setSyncStatus('synced')).catch(()=>setSyncStatus('error'));
    },2000);
  },[countries]);
  // Day 1 = 70%, Day 2 = 76%, Day 3 = 76% + capitals×10% (per country)
  const morale=[70,76,79];
  const updateCountry=(id,updated,actionHint)=>{
    // Detect what changed for presence
    const prev=countries.find(c=>c.id===id);
    let lastAction=actionHint||null;
    if(!lastAction&&prev){
      const prevItems=(prev.items||[]).length+(prev.buildings||[]).length;
      const newItems=(updated.items||[]).length+(updated.buildings||[]).length;
      if(newItems>prevItems){
        // Something was added — find the new item
        const allNew=[...(updated.items||[]),...(updated.buildings||[])];
        const allOld=new Set([...(prev.items||[]),...(prev.buildings||[])].map(i=>i.id));
        const added=allNew.filter(i=>!allOld.has(i.id));
        if(added.length>0){
          const a=added[0];
          const label=a.label||(a.name?`${a.name} Lv${a.lvl||1}`:'item');
          lastAction=`➕ ${label}${a.qty>1?' ×'+a.qty:''}`;
        }
      } else if(newItems<prevItems){
        lastAction='🗑 item verwijderd';
      } else if(updated.tab!==prev.tab){
        lastAction=null; // tab switch, don't show as action
      }
    }
    updateMyPresence({country:updated.name||null,tab:updated.tab||null,lastAction});
    setCountries(countries.map(c=>c.id===id?updated:c));
  };
  const removeCountry=(id)=>setCountries(countries.filter(c=>c.id!==id));
  const dayColors={0:"#64748b",1:"#3b82f6",2:"#a855f7",3:"#f97316"};

  const getFilteredItems=(c)=>{
    const all=[...c.buildings,...c.items];
    return sidebarDay===0?all:all.filter(i=>(i.day||1)<=sidebarDay);
  };
  const grandTotal=sumCosts(countries.flatMap(c=>getFilteredItems(c).map(i=>i.cost)));
  const grandIncome=(()=>{
    const inc={};
    for(const c of countries){
      const warbonds=(c.cities||[]).reduce((s,ci)=>s+(ci.warbond||0),0);
      const budget=c.name?(sidebarDay===0?calcDynamicBudget(c.name,c.capitals||[],warbonds):calcCumulativeBudget(c.name,c.capitals||[],warbonds,sidebarDay)):null;
      const cityIncTotal=calcCityIncome(c.cities||[], c.capitals||[], warbonds);
      const cityInc=sidebarDay===0?cityIncTotal:Object.fromEntries(Object.entries(cityIncTotal).map(([k,v])=>[k,Math.round(v/3*sidebarDay)]));
      if(budget){for(const k of RES_KEYS){inc[k]=(inc[k]||0)+(budget[k]||0)+(cityInc[k]||0);}}
    }
    return inc;
  })();

  // SPLASH SCREEN
  if(screen==='splash'){
    return(
      <div style={{minHeight:"100vh",background:"#0a0c10",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",fontFamily:"'Rajdhani',sans-serif",cursor:"pointer"}}
        onClick={()=>setScreen('home')}>
        <style>{`
          @keyframes fadeIn{from{opacity:0;transform:scale(0.9)}to{opacity:1;transform:scale(1)}}
          @keyframes glow{0%,100%{box-shadow:0 0 40px rgba(180,140,60,0.3)}50%{box-shadow:0 0 80px rgba(180,140,60,0.7)}}
          @keyframes blink{0%,100%{opacity:0.3}50%{opacity:1}}
          .af-logo-splash{animation:fadeIn 1.2s ease forwards, glow 3s ease-in-out 1.2s infinite}
          .enter-text{animation:blink 2s ease-in-out infinite}
        `}</style>
        <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCACwALcDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAcFBgMECAEC/8QAPhAAAQQBAwIFAgQEBQIFBQAAAQIDBBEFAAYhEjEHE0FRYRQiFXGBkQgjMlIWM0JiobHBJDRDktFjcoKT4f/EABkBAAMBAQEAAAAAAAAAAAAAAAADBAIBBf/EACkRAAMAAgEEAgEEAgMAAAAAAAABAgMRIQQSMUETUSIyQmGhFJEjcYH/2gAMAwEAAhEDEQA/AOMtGjRoANGjRoANGjRoANGjRoANGrhs3wy31u5CXsHtyY9GUa+pdSGmf/eukn9DppYP+GLKKUn/ABJvTC4xX+tiIhyW8n4ISAAf10q8+OP1MZOK68I590a6rH8P3hNjGenJ72zMuRVgJLMUfn0rClVqPHhL4NKT0/iO4UL/AKer61pSQem7sN3X6DSH12FDp6PLXg5k0a6pkfw7eGGRYH4Lv/KRZBH+W8y3K5r/AOn08d/21UM//DDulkOK21uHCZ7o/wDQDhjvn/8ABX/zrc9Xir2Yrpsi9CF0asG7tl7r2lILG48BPxpugt5o9CvyWPtP6HVf1QmmtoS01ww0aNGunA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0ayw40iZKbixGHH33VdKG20lSlH2AGm94beGEOLFTuXfY8qGg2xjySFPVza6/wBP+0Gz3NDWMmSYW2bjHVvSKp4a+F+598uh2CwmHjEqp2fJ+1oe/T/cfy4HqRp04bCeE3hsLEdO6c2yr75MkBTSCBdoT/TX7/CieNVvxD8R5zsZnF4yMuFi/wDJYaYSUJNGqNCgOBwO363rNDwTkPIPYbJPNycRuRkIhzaH8mTYUlJPNEK4I7kKB15+XLktc8Ivx4oj+WT+7PGKc1GabkzY+ML7RfjsdClKUgj7erggA1xYUao2QRqqbv3flI+18FuJt5U1jI9bDqJDqiGHEq7hIIFFNECq57emvMzsde+1w+iPNh5LERkQsiQxbKkt0lKvMJCUccfcQPa9X47C27F2wziNx5GNGx5kIlNtppTjf2dINqISbqz0BYsccaVrCkm+WM78tbS4KfmctOi+Lu28VGQyjEZBMZ8NhoUoKT9yb9U99Z9sYec9vTNfi0pwQfrXYsZJkJbI6h/WkWL6SocAdyPbV/nI8PGHcVJMfJZJ+GyluHIFjpT6dJ6E0PmyPnWy/l9juxmnjgpL8sOIJCZC1LJcLhJA6wLpIJ76U8k60l6/sZM3vb2c+4uXudrxQZ2nIlukpneQoLFkpu7N/HOr5k9xbkj74ewmBhtpgfWpjtPtTfMQEk196CVC+3oKA5GmC0nw5l7kOYkRsnjcqyekS3kBVUK7lCu1/wD91DYXw6wcLccrdG1smxNlNJd6UOr6aNcLtPUkV6FXQO1kem6yY7516/sWpyyvPsxMeMciHn17SmvtZ5AkGKuLLjlYfJ4BANgg8AUpP5HsdDcXhx4ZeIC1K28F7N3AvkxFD/wylHsnpVRSfj7T34Nar8fbrm1d0SNz7gflPzWY941EltIDrilcFCk2laU2TYVetjcOLW5kfwqLNMGJt9pb8/KST1qc80pXVAAHm6H53666msdr436BayL/AJEJ3f8AsTceyciYmbh9KCabkNHqac/I+h+DR1WNdM7U3vi9w4WRi8otOXxYdEdTklgoKSQem0kmwQlRFGx08HgJK38SfCx/GyPxHahVkcY8bDKTbrPqB/uHsR341dh6nb7cnDJc3S9q7sb2hXaNeqBSopUCCDRB7jXmqyMNGjRoANGjRoANGjRoANSG3MPOz+biYfHN+ZJlOhtAPAF+pPoALJPsNfOBxcrNZaPi4Ra+okK6UeYsITfyTwNdIfw9w4O2dsSoW7MEuLIVlFBb9D6hJDVfaO5SELUTXBC77gaXkvsnZvHHc9GorY+1PDxIXjckvIZJMciTNX0lBV6paTxSTwLJJP5EjVebzOM3rLkYuVuKTj5QQsthuN5iEpSCT2IN9+APb9JXxi2nu7zW3MFG/FMfPBMCVCAKHk2eALtKk109PoRXsNJnYicpH3pAEBhwzW3r8spIPHe/bUkRVy7t8llZfjaiPDHVtTbe5tqYKZADEPcGOeWHm1Bv6htw8WggfcgqTVHjkDnU6iFExYkL3FI8puW6JDeCZd6glYTVlVg1fcggAAfcoitYYjMfainUJLzk6WSt53rJLYJJ6EWPuPF2QbIJIHYQeMYm7v3UjBYOIiRIkOhT855Bc8hBISVqs0o2QLoC+OdRt1d8spUzjW2Se5d8SmIzS/rouFxaUBLKI5SlQF2On7RyQCCWwAeAVE6Xk/xTYiOPDEQlvqcUoqdfUR1X39Sv0HdRHxqgbpbzP4m+9mFSXnPPcZ890HpWpBpQBPtx+41Ea9DH0mOfPJDXVX4nguUrxD3TISpcZxmKhP8AUtiOnqonspZBJ/U6029+7tQ4HE5qQFjsbHtWp7wiMPHRMjl8ynrxUhxrHLZIsPFxX3WP9qbN+ho6ruQxDu3PEH8Jd6HTEnoSlRFpcT1ApPyCKP66YlG3OvAt1aSe/JKxfFDdTVec9Fkm7K3GE+Z/7x9w/fVgx3ifDly2XMnEkQnBYW6w6VpN+tH7h+h9BrD4nYTd726sxBibeWvGiUpMcs45HCQrjpUE9Q/Q6V6gUqKVAgg0QfTXPhx5J8GvnyQ/J03ht8Ll4wsypMfOY1SelSX1hS+f7lFPf2Kwb7AjvrFlduws5h8gjb0x1ceY0gSMd1W60E/0lAJ5A5AFkc8HsAkPDLG5PJ70wsCFIfhoyE9qEZKUnoBWoAg+h4PbTfYeyeMnxoWfaexmRLYcYcSoBp1JK0CjVIJKFpINg0RwNQ58Lwvcstw5ZzLTRBpxSUbXibT2tFfQh+eh3IZGcUMKW4jgNoBJoizxd+laucvOxcPuibhfxHHxm/M8iMn6jrXdDq4F9I674sVfAoGvl9qPlMhDzsSGyrKQXUvWtNIeIPZRHYiuDZIIHcHhB7vRkZO9ZgUy+Zz0iwgJPmFZPt73rsT/AJFcv1/Zm2+mXHKY+8/4TYHe7M6XGnKxu5lUporUlMeUrpP2rT3Sokf1g0eSRwdc15CJIgTnoUtotPsLLbiD6EGjrqLwwxu7Mpjm28pCVjH8cT9fJmUhptCVdJUSfW0lPrZFdxqG/iFibdy2CwmA2fhEzMt9WGUSWmrlSRSiSuuQCVfaD2AHpp/TXcvssV1ERS74Ob9GpbdeAm7azK8VkFMKkNpSpRZcC0ix2scGu2onVxCGjRo0AGjRo0AXLw8xMZ/qyLkxcaUyrqjkj7DXcK4JAPawDWmxk8rKMNljLRFSISF9TLjLw62SeLQsGiKA4NjjsDel5s6P9Jt5iYXEBwkqQ2r+lxJ7gn0Px6jWYT1pddbYdRHYe5Uw8A42e9Aggg9zRIJHpzpFruZRD7EMbbG79x7bStW358XLwVlD0iA6iw6Qe/lHlLgHctkjgE9uLltTfGzd0bkS9kMZFws9TZQXJIbdCl2KHX0ocBIB/rXyRXJJBSKlMPuioa1K5FwZNlR5N9Cgsg1zQA4HbWlk5qGn/qI891wtN+WUzmSCpJu0cKIrnuCPcAenHj2tGlXs6RneHOBy8mb9Jl5DDkOQVLblOFbLrVJJBXSQgEkgkk9jQNHWfa2xM5tmHGd227GyJS4txrqWGnVNLKHEhQVRtKkVwSCFccitc/7X37L2suUhnHxlofBUhaEKS60SKIQ6FJWAfYqI+L50y9geMkZyNEivORBLaIRHRLZT5TgVxdgoDRFcqTyTySdR5sLS48D8eV7+yX8XfBncu6dgMs4LDmTlYD6FMNechALBDinCCT0qWpakk83QA9Nch5KFLxuQkY+fHcjS47imnmXE0pCgaII99debk8ds5h4DmNx8RAyIWUofTJQ82k0UgpKBS6BsGzR5J9BzB4jtbmc3NIyu6YUtiZkVecHHmykPDt1JPZQ47jT+jt9vYxPU49Pu+yVye7lYbA4fBbYyDLjTDJemO/TAhchZNj+Ym6AAF/Otzdb3+JMZt3e7riUuNrRAy7iUcNONkFDhCR2Uj29U6iPD/wAOty7zeC4DDULHAnzcnPX5ERqu9uHgn4FnTCi+Euawsd7/AAv4n7IyT8hPluwm54Af9k9LqehfPbT2ol8eRK7q/wChZ+I+VZyO+8xkMdPVJiyJSnGXE9SQUnngGiK7dvTULh8bPzGUjYvFxHpk2U4G2GGk9SlqPYAazbkw+TwWZkYzMRfpZrSv5jdpIF88dPFflqb8KnN1Qd3xs3tKLIdm4+3S62i0spIIKlE8JFE8nTP0zwZ06rR1B4PeD+5NnbFbVncIGcyrIJlqZS+hwlKFtKaNhVJUKdF2KBN+mpfc+xMpnsE+nPLjQ0+Y0p5xsl1wNNFxdJSgElalvLBA4AHPPGoTC+Ou4c3jGoM2JHRP8yn3lvBptZB7HqBAvpFGvyI76gPEHxdjtxJ2PbdhGVJJMtmE00uIggAEkpK/NUo91cG+QQONeRqsmXZ6TVYo7eC0seHuIxS8dElbglSp0twLLTJS22w0EFayVnr6q6UpsWbUB6g61d0bp2TszcqsxicYxl30oMbz4wbC0LAtNPLKlKNEgqbSKpIJutJzcu+39yNR2FYqE3GZp1wuN0464AQAtyyspAJoWBfp66jYGQW9PGSlT2GnukIQWWiVoQAAAm6PAodx6XfGq8WLS21pk1W2tNjLyu7Nw7mjR05Mw8BgmyFNxkpIBI5CykkuPLrgLXQsmjya0o+4FtMuxsFDX0EdDsgqBffPeiokBCPcA1V2Txqhv5bGNPhQdfmlJP2uuhCSTX+hFqB+Ov21gazbkvpaCXCylYUGGR5aCR6kjv7Enkj19ndnOzE1pa9EL4o44NTkZNeREuRJV/NSlP2N8cBKibUPS6A9r1S9MDxCjuyMOJ7q2wULQEttABCE1QHv+1j5vS/06XtCLWmGjRo1oyGvQLNDXmpDbkT6/PwYdLV5z6E0hNqPPYD1OuN6BFtltzoGIjI+q6elpJLPQaFji+QDY5B/6HX0UsLjJdXGhvtkAFSHK59bBAIP6/qdbu/WvpZqogkB9tkkNuI4SsUAkj4IogeljVRbcdYf8xt1bJ7qUg0a9a9z+elYvynY/JLl6J1uLAJJ+lbBqwkyO3PagvUo1BU40A7MZaDaOkJdmFRQk80EWVV+SdfW3JEOe2ox38jJUgArS4tlsC/ckgn9BqcYZYKFOGJEQz2U67LLyUEequUIB+CSeeAdbOlREF3qcbEeU800QCponps3RpRBANHggdjrBjcUp+W2lsJBpS20lN8jmjRAo8myQAB8jVuXDnOxFv46Q7HRwgvBIQ2RZoIR0gL5JoBIPPBOtF9uK+0mQ5CUwIbo+pBdIUSACQD3BIs388c65T4aObaaY2vDrCbc3XjG0Fh1rISG1/TkoWhpEpAJLNqSASQOwUSADY5Goz+IlnPJ8KImO/BjLx7EhKxI8hQVEFdwLPR6oV6X35rS7RnFYWYcpg0/QpceQ8y6GyVxihZBAtR6QfXuTVXwTpo7X8bpqoKypuI/LbSA+pwgsSbBSCtrjk2BSACAkf1XQ8x46nIrXhF7pVHb9opWxvFTcre2I+LxCx9Di8d0rhlKfK6UpPWSCOCo3z/v1L7Jz07cIUnH7UiRoSrCilsFBc5ojg8d+BwfjV3mYjbGQelRcBAxzn4wOiT9FGEZkuJ6VlABJIQk2SbqkEj7gmt7Fpl4raUGJExbOPgh1BlPdJbdSaQkqSkgfeVkrSj1Sk3/AFABkTjqnSWhTqoSlnMfi43IOXhuSVLXI8nyFKVyVBBpP/Br9NdDeAmH3E14Pw8fkMAiBEekKWlIAbfnBRPQpaTyqyelPHHSDVaj8OtGH3GnJ7qx0KK5GaLzK5MTzm2nSCUnoBCwKCbAPBsc1zi3b415N2TOjtymGMkjqSqapaA01QolhsEiyB0gkqJBuwQNdyusuP40aiVOT5N+Tc8W2do7ahOYOJHSZsRhLkmSlkuIdkLFpaCgk9jZIsdwL72h1YoeallxIW+slxzmiCD2F9+4Ngngi9ScnLR8tMTNyXnTlpWXZEx4nznz2AJKqIFGhQI4FkUdSzrDMbHuPojuynJpUIqi91rSa4WSLohIskWOK407p47FoXmtt6bK99Cp2SxEW1IaaXyCoDpAA5UemyRXpR1KzUOtIMczoLzZF+WiUkEAdrSaIP6DUzi8XKa8tWTfS6+tFBMxCClY7gN3QUL9ErBIIJGtialLbqm34aGVXSQmYtlYA4vodA/4JHtx3pJ6eioNSUxwUx4ja+uwQHgtJvuCCog/Ng6xS5cpmGVqECKAKbSSSe/ACEgC7rm+Nb+45kTHFLcmdlkOLSVIS06ws18lNkDv+2qUrqedKlrWqzwXFEn3Fn40GdkpkWpj+3pb6n/OK0pW6lIPAB7nngA8Dj/jVL03PDzHDKx5cJx7oYLRVI4H9IFgi+5spA+VDSomMmPLeYN22tSDfwa1nHe219Hcs60zFo0aNNEhqT2o+I244D5f8jy3kq8zpvp+asX++ozX02elxKvYg641tHU9MdW9Ym3My4MhB3OXnFglxqRESytKjZsAOKBBJN8gi+AdVbMQPqi0phrGsBDQQQ1IQOuhwogmySCLIAsjsNTU3GNZDZjc9Ln0riJjTanh1UELQaJoEkApvgE86ko+zcdkoGSEPISWZEOCXipD5daK0IBJBBoNk39x7EgEAnUUUoWmy213vbQucng32Y7clgqUgNoUFJBNWkEgV7X7+h1d9gzoOTYWX4yOuAkKdl5GcVobPp0IIFk0eAQBXJPGs02CVY6AoSJKS5jUEoC10SGyCSAaBBr87rvxpd5z6vB7ifeYASpmUSgLSFjg2mweDxXfTsWTvFZJ7ORwTJy57Dj8VTrcNB6TOdTSlmrKGEccketAUbJIBOq7PhpxMyLk40VgyGFhaWXkgggEgA+6jd2eeL/KT2TuZjcaRImPrlZVpKUNtOkDrWeaQkfa20kCya5PJ7AayzGlOy1nq860F4roC0div4Cj0hI9r7EnW3xwZT3yQmXVKfL7wDBYkttuS4kEJ6GjZCEBXJsWCeebPfkCsMS2MPPTPajOomsdDsZ1RSW0OpUD1lJB6hwaFVZ541Kvl2C2qVEkKjuvrCyEgUQOQSK5oqAP5nVVzbrylqS8EOKoArA54FX+tXrKn36Nd70N3w33vIgYhAfCZHnkOPLUAokhQNKsiwaJ7gUT3JrTlyO78Q3iXckw55mVfZ6nwtIUhQJABPIAWBY6+CQAAAeNch450iC2gBYv7QQaF9+/Px+2p5eTWMWprqd8zy6C6ABHv+/Fd/041HlxPu3L0V4qlzuiyeJG9ZGUR5jT56ml9bay3R9xR9hVc32GqOkR8lk3HW4yyty1ENkBBcJuwOAEmxx6X7a1J6yYjpt1Yop61EkE9yAT6Ak8fOvrBSX0Oh1taGShJBUlPNGwTXvyPyoe2rMcanglq02XLFLVivKkPpjvRWHC43AfcSHHASUEBdWDXIqwCBxzepTA49eRyKsottKcg64XQIyAghaQLCABXmJACqHChfHrqGx0VhxxqfI6nXHepDyiQSQDR+LoEjjVsxB+ikPsyutTbRBeUyLW10cpdRYskAgkc2CB6VrWvoXVf6Jr6tiNC+jyaIsZqWAWnVs9cGVZrqF/5S77psC74Oln4h5RLUpzC49iXCeS5SgxkS7FcTX+hHSKv2vjkayeJW/Xg+9jMRIa/mJKJy2VByLLsCnEtqFIXXfi7HxqteGmMGTzrKXRbfTIUSLsdLKlcfqBofCbZyX3NI9g7bfDbinukW11C1CgD2JNkA16GuDqew2PbiRJLM2PjXRISAl1yQkloAEnpo2CTRvngVXOrFkoLUPbubUw8850JEdlSlkjlRAIs0eEiz3B16/tPEYp1cSc/OlP/Th0LfkllABSSFkk8DlJA7kihZItHyp+yj4deiR2K7tjbmIVkHN0M/iq2z5DKYZdDJHUAtZK0gHkVXXXerqkRl1+ZlZbnWF9Tyz1DseTzpoOY+PC8NfxAqcdffkSv5q76ihDbQAongWs9+e/tpS6ZhnW2JzUmkkGjRo1QIDRo0aAHZsmWJXh3M6FEy4oZlxxwq1IUQoEE0QEhRo8c6wR9wpj5yW4wiA7GktrQ40235cc9abBUg9iCEnpqr7GrOobwXnpW+vFOudCJAWwpXsHBQP7/wDF69dwmRSh9alKcYjOfTu2QotEHge4F2L7Cz241A5Stpl0tuU0vRcdqSDkNrY1RcQhqBJLMlSk9RQkGwqgQSeCAB3NCjqseKWNanKVLipX0uwW3mh08ks20q69ShBUfzGp3Z8FeDzMPFyZKEwc+ylUd4GktuggAkXYoiieOCdTWfxeXexLrcxK2ZUV11cdSm6Qvp4eSCR6oCTQ5poj10tV2ZN+hzj5I/k5+w+Tl4qX9RDcKFKSULFkBaD3Sa5o9tMaDvjFZLHrRkVFnJTXwZLvR0oQ2LCUIq6SE9XHuv4vVC3Ti/wzJqS1ZjPfeyT6D1SfYg8H9/XUTr0uKWzzHuXoaOYUlxRCTZShCuCD09aeE382B81qoZ7oTKdb6k9YPT0g3Zv01ZfDPb6puLVKlIhOR33OkJdygivCiB1tAqCVFPN9VjU3j/Bbck3dkVzGBWbxjj4DjzK0+c36kOJKgU9v6r6T76S8kTw2OU3STSLTnImAi/w3YmOMWljMB1axJ6KLnJJJXXobASO9j2FplzLlePDI6vP73wUg1XV+dcV29fjTj8XcN5OATDxEd1hXQ06iIJAcBZLYIcIBJCgQoqPbkVwBpH+Q4HfLBSFKHQBwRz6D9NZxuciT3sY1UcD0lYfBSP4bxHi4hK8q3JL7kqzZugFXzyaopNVRPtabwCUrLZbUFOFRQpJN8kUCR7cf86cHhpg5Uzaqly0OS3gytQhJfAIaFAuhINlSbA5NkH41S1eD26Y245f4lHfwWPYf6Q/LT0LWe4S2m/uPp1D7R3JrXceadtN+DFY70tLyZoWThYtp5uZKZbKmw80hz/UoJCgDxyF1V+hHyLgdy78eMpLWCWUMtNhpt9aaWUi+jj+5IUUk82NZPFPbRxEWLKZhRGo6SGfMbyiJbyuDRdCFqCSaJAFCuOavS/06dPlCabXB6SVEk8k6cnhZjFYuM9Ll202y0hlwoQFLDjqwpQ6TRJDaFggHigD3rS72Th15Cf8AVuJbMeOoUHFdKXXD/Si6r5N8UOSNP/bm28mMa3GjpWehThnSVOBXk/YFLWeKIShIQD2JQoA/dqbqciS7Snpsbb7iq7znLh4SDCU60lUmWHUnyqCEAivtHNWCSO5vnnUW3nUuTH5UhUBKywWmEPtB/wAsVwGkAUTaqBPCaJ415n4ytxS5uVaWlECIRGjNuC/MPFi/cAgdqOsUDbuTk5XHQlOOmPNdQ2wjqFKTYBWa9LJNE8VzZGlqYS1vlDqqtvjg2PFJz8L8O8BjUkBSoAcVXqp5wrN+5CUpH5aTemL455ePP3GqPDWFRkLJart5aQEN18dIv9dLrVWFahEWV7oNGjRposNGjRoAldrTlQcwy4lXSFKAu6o3wf0Om/n3IKpjGaKEtoybPQtYkKZCHQKWDQIN/IIuye96RemfsSfH3Fg3ttT10p2lMLJoIeAoc/7xx+YGp88fuKunv9obhefbiBlwLbWysKjAEdBPYklJINggcdgR7abm2N1Obw2cy/D+nGZhdKZ6HVdB6EkdElBvhQIAX3ugaIURpMSXcnESnGTluyI8a20tKJ6mgL7DsSP+grtr4x06VtzIN5fHFQkNr+9CgChxBFVVc2mwQfQnU1Ye6eP/AApnK97LV4g7dbdbcQ70IiOOgBSVFxMJwiwByf5SgCQRdjg2QNJ3JwZWOmLizGlNupo89lA8hQPqCOQddS7bZxe9cNNz2GyIRISzcjHvkrUyCAFjk/zGjZUCCCDfIIB1QNz7Wi5dv7ChyMEqKFJJU43VX5aqpwVZ6eCBVivuOsObs/GzGbAr/KRXbQiP5/PYvAO5D6SM490l0i/KSTaj8+prTUxm9ts4AycPtNmR1Nxnw5KlJDkiWroPQjtSU9ZJITyQKJPbSqnYjI4V9vIwXVOsoX1NSW0lJSR/ck8pI9fTWvhI7ub3RFjqUA7LkgKKUgck80BWqrici58Ek3WN6LbvjPHP4rGOyYzkfLsNFh5aFEIdaSAGx01wQBXrfe7J1WfPYMAMiOoSSoJUocAjvY9jXGrRlMI4qU+otkho+TSRZBFcenHI/wCxOsP+H3A0l1TagSCokduAP+xOuTMpJI1VW3slfDTOQcK219hVLfTJYnreJCfpltBASg3weokkkeiaPBBlIe89sbhiRcLvdM5yen+QnJxEpS80m6AWkgpcCQAR2ULIBA1XMVg5P1zKC2m3VBIHVVk2CB7kgHgaqm4Iz2392y47a0qciSD0KNLHexfodY+CKrZt5rmdHxueO9is3ksN9WuQ1HlKR1q46+kkBVWa4OvnbuFk5mX5bZDTCCPOfWQEoHtZoEn0H/QWRs4HESc7kvMkKfdLq+pSWx1PPEnnpB/Xk8fnpybe2zFiQ2UzYbCkMuERoyEFaQokV5lGnFWACBx6KJ5Qe5c841r2Zw4Hke/QbC299MGnw0mOwhI+kjrISoJPJfWSP6lUCK5sWAAhIMt4p7nkbZ225tKOuP8AiswBM4x/6Y6AftaBHc3yrng0BXOtvdm4sdsjHuynnHpG5ZYpqI70lMS+Q4scguHigAKqzQ40mmm1ZHzsjNeecmuOWoqPWCCbN+pJ5N33POoscPJXfRZVTE9sk/tWI/kW4WODEh5oEocQXB3JskEg1RJsAHmiB31Z4T0SBEyu50MJi9LasdCuQt8uL6P5roWsAnoQRVAC1oIHB1V8GjcGWl/4fxUsxYs1XS82hxKUFFkkrWkkhASLPPFH8taHi5nY6GYu3sUophRWvKaT69N/cs/7lqsn4odgNP8AjdVpiKtKRf5machk35RFJWr7EjslI4A/bWno0auS0RBo0aNABo0aNABrcxE5zHzUSEE0D9wBqxrT0aGtnU9PaHJJWjeOKGUhuKOYYQFP9Ndb6RX8wACiocWBzdH14qgYlSHw290rCyQlaUBJCzx2FAk8363qv7Vz0nCZBt9pxSQlXUCO6T7/APyPUXpoTcTjt64o5HCpDeUQjzJMFB/zQKt1mhyKslPcUe47S843p+yru+RbXkgYTWX2POj5TE5xhMqwsMtLPWL5okjpPpxZv0vTW21u/ae9cemA+mLt3O9dLBSEsyCa5KaPTRBNAUSTyNKbb+JkZCejFocRESEOKQUtguPuJQVBBKjySRQHYcCrPOhl8a4mG1OdiuJiOlRZkpSaIBAJKbsAEgWLTZAA0q4jI9N8m4up9DZ3zs15Jmys5HZCUrSW8iy4VIdJ4AC0g2eOesKIPFp4BU+5NqKjFEuM6pxhR+14ilFXeuPUf7gPQmr1J7X33vHbbam8blzKiHhTL58xCwPQ/HFUa9RXJ1KS/EPGZIA5raTbTgSR1w1FCCSeT0jjn2FD5J12Vkx+OUdpxk88MqOG3HmsBi5mORHhvqed8xLz56nGlAUSOa9R39hqfR4ghHh2MErBRhmqLX4mXbKmj2+3+7ir7fGsb2R2BJZCS7lIqrJP2ggn5ocj8zrH1bD8jq/EZyTQCVlgkhQ59B2+NO+Tf7RSx/TIbNZ3NZ3BQsc8xFaTEWCp9qwt1VBKSquLofr318YLbLcqQgy3HHVuLpKE/wCtXtfJuyPTU+jMbEhpBix50t9RpSugJSR60LBFn5/fW+x4juweNs7djxV9NCRNV5rgHAHSTVEelc/Oh1bWkg+OVy3svOzdrs4xKn3IjMPGpaWHZkzhBNcEAm1gmuOQavp9tDcXinBwUdzHbUdXkJxNrybwA8riv5QHCAOeRyfQgcaXGbyu5tzTUrzuUlS3Fk9LIUaPwE1ZHbsCOO47gwGByGTjzTjIbi1wEJW40U04sFVEJTzyACTdkUedI+Cd7tjPmetSjLDwc3OJVk38ow/NcKiGCtXmcWSRYoAn1J5OsTeKekyW4QSQAoIbaSCSsngWBwSe3b1A18QMa/lHmoMWEt+StfSwpsEuKJPIIF9V+nY366vX1WN8MMK5brEvciwUF5BC0QbFKQ36Ke5IKxwiuLPIbtb1/oxX2zHuOVC8Ptqu4tCwrNzElE7oUCGkcERgR62AVkdqCb7jSSlyHZUlyQ+srccVaidbObycnLTlypKuSftSOyRrR07HHauSe77mGjRo0wwGjRo0AGjRo0AGjRo0AGpTb+cm4aW2/GcUAhQWAFEFKh6g+h1F6Nca35OptcofuB3phdzMtvTHWsVnGk/y8m3HCkuLPYvNjlCh28xAPoSCResucYlQ4ZYyUPphTkNwlSo4D0VqIkXbbgJslwhwk1ygX3I0gWHnWHQ6y4ptY7FJrV62V4nZzbrhSh9XlKILiOkLbcr+9tQKVakvp9cyVxmlrVExvHG7da+hl4+PIWiWpaUqZWE9DTSg2DQHK1BJWSewIA7E6iN14RzD/SlUtUhb8Zt6nY1AFaOspC7NkApvseRxq9xN3bG3EhYyGK+hlO2fMxLnlJSSKJLC7F8AUkgEE8jWpujCQs5Iclw9xQVrWSo/VNGOtZoCgeUelUOkel65NuWlR2sar9JQYiS44VyWy610EhKFGjXparAPx/xqckY3b6cC1MaMtT7iykpDyC3wLAFN3fuDXOtmTszeCYjTqRFfjoV1oCZjIB+QAefzN+nB1oBiaphMBmCvzfMKylRAokV3Jr9vfsPTbbb4ZlTrh7IfIoCHHEx0MlAAITajYoCyLA7/AB+V6n8BhsfMhJnOZl9hlEuOxJQlkIBQ5Zc6Vg39gBJsVXPbvuI2Ru5cBpUxTLUMkAKdmMpQObAJKgQBfa/01Y4WHg4jBqxeQ31CYhkqL0fFMmQ4u66kldIB4A7rrtx66Lr8dJ8glzyuCHyuNg4xttsoVi5aMmWXXGiViREBC0OiybqqsEA2BydWJhOakZ5/cWJfXhMRIe856fkWwPq1EqJ6EAEqFK6ehFihZPc6gMjvTYu3VJ/w1gg/ISKMnJLTKcsCgUtgBtHxfVXxqg7s3znNwSVOSJb9EdIUtwqWE/2g/wCkfAoaXOK78+DVZJj+S9Z7euF2nGfx21GVee8Oh6YuhIdFCx9vDST/AGpJJAAJrjSlyc+VkZJkSnStR7D0SPYDWsSSbJsnXmq4xqSW7deQ0aNGtmA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA1txclkIv/AJeY+2PYLNftrU0aNbOptE01ufMt95CF/wD3tpP/AG1kO7cyTZdZ/wD1DUDo1ntX0a+SvslpG4ss8rqMkJPe0oAP71rRkzZckkyJLzt/3LJ1r6NdUpGXTflho0aNdOBo0aNABo0aNABo0aNABo0aNAH/2Q=="
          className="af-logo-splash"
          style={{width:220,height:220,borderRadius:"50%",objectFit:"cover",marginBottom:28,border:"3px solid rgba(180,140,60,0.6)"}}
          alt="AF Logo"/>
        <div style={{fontSize:38,fontWeight:700,letterSpacing:8,color:"#e2e8f0",textTransform:"uppercase",marginBottom:6,textAlign:"center"}}>
          Amicitia Ferox
        </div>
        <div style={{fontSize:14,letterSpacing:5,color:"#b48c3c",textTransform:"uppercase",marginBottom:50}}>
          Build Calculator
        </div>
        <div className="enter-text" style={{fontSize:12,color:"#475569",letterSpacing:3,textTransform:"uppercase"}}>
          ✦ Click to enter ✦
        </div>
      </div>
    );
  }

  // BUILDS SCREEN
  if(screen==='home'){
    return(
      <div style={{minHeight:"100vh",background:"#0a0c10",color:"#e2e8f0",fontFamily:"'Rajdhani',sans-serif"}}>
        <div style={{background:"#0d1117",borderBottom:"1px solid #1e293b",padding:"12px 20px",display:"flex",alignItems:"center",gap:14}}>
          <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCACwALcDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAcFBgMECAEC/8QAPhAAAQQBAwIFAgQEBQIFBQAAAQIDBBEFAAYhEjEHE0FRYRQiFXGBkQgjMlIWM0JiobHBJDRDktFjcoKT4f/EABkBAAMBAQEAAAAAAAAAAAAAAAADBAIBBf/EACkRAAMAAgEEAgEEAgMAAAAAAAABAgMRIQQSMUETUSIyQmGhFJEjcYH/2gAMAwEAAhEDEQA/AOMtGjRoANGjRoANGjRoANGjRoANGrhs3wy31u5CXsHtyY9GUa+pdSGmf/eukn9DppYP+GLKKUn/ABJvTC4xX+tiIhyW8n4ISAAf10q8+OP1MZOK68I590a6rH8P3hNjGenJ72zMuRVgJLMUfn0rClVqPHhL4NKT0/iO4UL/AKer61pSQem7sN3X6DSH12FDp6PLXg5k0a6pkfw7eGGRYH4Lv/KRZBH+W8y3K5r/AOn08d/21UM//DDulkOK21uHCZ7o/wDQDhjvn/8ABX/zrc9Xir2Yrpsi9CF0asG7tl7r2lILG48BPxpugt5o9CvyWPtP6HVf1QmmtoS01ww0aNGunA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0ayw40iZKbixGHH33VdKG20lSlH2AGm94beGEOLFTuXfY8qGg2xjySFPVza6/wBP+0Gz3NDWMmSYW2bjHVvSKp4a+F+598uh2CwmHjEqp2fJ+1oe/T/cfy4HqRp04bCeE3hsLEdO6c2yr75MkBTSCBdoT/TX7/CieNVvxD8R5zsZnF4yMuFi/wDJYaYSUJNGqNCgOBwO363rNDwTkPIPYbJPNycRuRkIhzaH8mTYUlJPNEK4I7kKB15+XLktc8Ivx4oj+WT+7PGKc1GabkzY+ML7RfjsdClKUgj7erggA1xYUao2QRqqbv3flI+18FuJt5U1jI9bDqJDqiGHEq7hIIFFNECq57emvMzsde+1w+iPNh5LERkQsiQxbKkt0lKvMJCUccfcQPa9X47C27F2wziNx5GNGx5kIlNtppTjf2dINqISbqz0BYsccaVrCkm+WM78tbS4KfmctOi+Lu28VGQyjEZBMZ8NhoUoKT9yb9U99Z9sYec9vTNfi0pwQfrXYsZJkJbI6h/WkWL6SocAdyPbV/nI8PGHcVJMfJZJ+GyluHIFjpT6dJ6E0PmyPnWy/l9juxmnjgpL8sOIJCZC1LJcLhJA6wLpIJ76U8k60l6/sZM3vb2c+4uXudrxQZ2nIlukpneQoLFkpu7N/HOr5k9xbkj74ewmBhtpgfWpjtPtTfMQEk196CVC+3oKA5GmC0nw5l7kOYkRsnjcqyekS3kBVUK7lCu1/wD91DYXw6wcLccrdG1smxNlNJd6UOr6aNcLtPUkV6FXQO1kem6yY7516/sWpyyvPsxMeMciHn17SmvtZ5AkGKuLLjlYfJ4BANgg8AUpP5HsdDcXhx4ZeIC1K28F7N3AvkxFD/wylHsnpVRSfj7T34Nar8fbrm1d0SNz7gflPzWY941EltIDrilcFCk2laU2TYVetjcOLW5kfwqLNMGJt9pb8/KST1qc80pXVAAHm6H53666msdr436BayL/AJEJ3f8AsTceyciYmbh9KCabkNHqac/I+h+DR1WNdM7U3vi9w4WRi8otOXxYdEdTklgoKSQem0kmwQlRFGx08HgJK38SfCx/GyPxHahVkcY8bDKTbrPqB/uHsR341dh6nb7cnDJc3S9q7sb2hXaNeqBSopUCCDRB7jXmqyMNGjRoANGjRoANGjRoANSG3MPOz+biYfHN+ZJlOhtAPAF+pPoALJPsNfOBxcrNZaPi4Ra+okK6UeYsITfyTwNdIfw9w4O2dsSoW7MEuLIVlFBb9D6hJDVfaO5SELUTXBC77gaXkvsnZvHHc9GorY+1PDxIXjckvIZJMciTNX0lBV6paTxSTwLJJP5EjVebzOM3rLkYuVuKTj5QQsthuN5iEpSCT2IN9+APb9JXxi2nu7zW3MFG/FMfPBMCVCAKHk2eALtKk109PoRXsNJnYicpH3pAEBhwzW3r8spIPHe/bUkRVy7t8llZfjaiPDHVtTbe5tqYKZADEPcGOeWHm1Bv6htw8WggfcgqTVHjkDnU6iFExYkL3FI8puW6JDeCZd6glYTVlVg1fcggAAfcoitYYjMfainUJLzk6WSt53rJLYJJ6EWPuPF2QbIJIHYQeMYm7v3UjBYOIiRIkOhT855Bc8hBISVqs0o2QLoC+OdRt1d8spUzjW2Se5d8SmIzS/rouFxaUBLKI5SlQF2On7RyQCCWwAeAVE6Xk/xTYiOPDEQlvqcUoqdfUR1X39Sv0HdRHxqgbpbzP4m+9mFSXnPPcZ890HpWpBpQBPtx+41Ea9DH0mOfPJDXVX4nguUrxD3TISpcZxmKhP8AUtiOnqonspZBJ/U6029+7tQ4HE5qQFjsbHtWp7wiMPHRMjl8ynrxUhxrHLZIsPFxX3WP9qbN+ho6ruQxDu3PEH8Jd6HTEnoSlRFpcT1ApPyCKP66YlG3OvAt1aSe/JKxfFDdTVec9Fkm7K3GE+Z/7x9w/fVgx3ifDly2XMnEkQnBYW6w6VpN+tH7h+h9BrD4nYTd726sxBibeWvGiUpMcs45HCQrjpUE9Q/Q6V6gUqKVAgg0QfTXPhx5J8GvnyQ/J03ht8Ll4wsypMfOY1SelSX1hS+f7lFPf2Kwb7AjvrFlduws5h8gjb0x1ceY0gSMd1W60E/0lAJ5A5AFkc8HsAkPDLG5PJ70wsCFIfhoyE9qEZKUnoBWoAg+h4PbTfYeyeMnxoWfaexmRLYcYcSoBp1JK0CjVIJKFpINg0RwNQ58Lwvcstw5ZzLTRBpxSUbXibT2tFfQh+eh3IZGcUMKW4jgNoBJoizxd+laucvOxcPuibhfxHHxm/M8iMn6jrXdDq4F9I674sVfAoGvl9qPlMhDzsSGyrKQXUvWtNIeIPZRHYiuDZIIHcHhB7vRkZO9ZgUy+Zz0iwgJPmFZPt73rsT/AJFcv1/Zm2+mXHKY+8/4TYHe7M6XGnKxu5lUporUlMeUrpP2rT3Sokf1g0eSRwdc15CJIgTnoUtotPsLLbiD6EGjrqLwwxu7Mpjm28pCVjH8cT9fJmUhptCVdJUSfW0lPrZFdxqG/iFibdy2CwmA2fhEzMt9WGUSWmrlSRSiSuuQCVfaD2AHpp/TXcvssV1ERS74Ob9GpbdeAm7azK8VkFMKkNpSpRZcC0ix2scGu2onVxCGjRo0AGjRo0AXLw8xMZ/qyLkxcaUyrqjkj7DXcK4JAPawDWmxk8rKMNljLRFSISF9TLjLw62SeLQsGiKA4NjjsDel5s6P9Jt5iYXEBwkqQ2r+lxJ7gn0Px6jWYT1pddbYdRHYe5Uw8A42e9Aggg9zRIJHpzpFruZRD7EMbbG79x7bStW358XLwVlD0iA6iw6Qe/lHlLgHctkjgE9uLltTfGzd0bkS9kMZFws9TZQXJIbdCl2KHX0ocBIB/rXyRXJJBSKlMPuioa1K5FwZNlR5N9Cgsg1zQA4HbWlk5qGn/qI891wtN+WUzmSCpJu0cKIrnuCPcAenHj2tGlXs6RneHOBy8mb9Jl5DDkOQVLblOFbLrVJJBXSQgEkgkk9jQNHWfa2xM5tmHGd227GyJS4txrqWGnVNLKHEhQVRtKkVwSCFccitc/7X37L2suUhnHxlofBUhaEKS60SKIQ6FJWAfYqI+L50y9geMkZyNEivORBLaIRHRLZT5TgVxdgoDRFcqTyTySdR5sLS48D8eV7+yX8XfBncu6dgMs4LDmTlYD6FMNechALBDinCCT0qWpakk83QA9Nch5KFLxuQkY+fHcjS47imnmXE0pCgaII99debk8ds5h4DmNx8RAyIWUofTJQ82k0UgpKBS6BsGzR5J9BzB4jtbmc3NIyu6YUtiZkVecHHmykPDt1JPZQ47jT+jt9vYxPU49Pu+yVye7lYbA4fBbYyDLjTDJemO/TAhchZNj+Ym6AAF/Otzdb3+JMZt3e7riUuNrRAy7iUcNONkFDhCR2Uj29U6iPD/wAOty7zeC4DDULHAnzcnPX5ERqu9uHgn4FnTCi+Euawsd7/AAv4n7IyT8hPluwm54Af9k9LqehfPbT2ol8eRK7q/wChZ+I+VZyO+8xkMdPVJiyJSnGXE9SQUnngGiK7dvTULh8bPzGUjYvFxHpk2U4G2GGk9SlqPYAazbkw+TwWZkYzMRfpZrSv5jdpIF88dPFflqb8KnN1Qd3xs3tKLIdm4+3S62i0spIIKlE8JFE8nTP0zwZ06rR1B4PeD+5NnbFbVncIGcyrIJlqZS+hwlKFtKaNhVJUKdF2KBN+mpfc+xMpnsE+nPLjQ0+Y0p5xsl1wNNFxdJSgElalvLBA4AHPPGoTC+Ou4c3jGoM2JHRP8yn3lvBptZB7HqBAvpFGvyI76gPEHxdjtxJ2PbdhGVJJMtmE00uIggAEkpK/NUo91cG+QQONeRqsmXZ6TVYo7eC0seHuIxS8dElbglSp0twLLTJS22w0EFayVnr6q6UpsWbUB6g61d0bp2TszcqsxicYxl30oMbz4wbC0LAtNPLKlKNEgqbSKpIJutJzcu+39yNR2FYqE3GZp1wuN0464AQAtyyspAJoWBfp66jYGQW9PGSlT2GnukIQWWiVoQAAAm6PAodx6XfGq8WLS21pk1W2tNjLyu7Nw7mjR05Mw8BgmyFNxkpIBI5CykkuPLrgLXQsmjya0o+4FtMuxsFDX0EdDsgqBffPeiokBCPcA1V2Txqhv5bGNPhQdfmlJP2uuhCSTX+hFqB+Ov21gazbkvpaCXCylYUGGR5aCR6kjv7Enkj19ndnOzE1pa9EL4o44NTkZNeREuRJV/NSlP2N8cBKibUPS6A9r1S9MDxCjuyMOJ7q2wULQEttABCE1QHv+1j5vS/06XtCLWmGjRo1oyGvQLNDXmpDbkT6/PwYdLV5z6E0hNqPPYD1OuN6BFtltzoGIjI+q6elpJLPQaFji+QDY5B/6HX0UsLjJdXGhvtkAFSHK59bBAIP6/qdbu/WvpZqogkB9tkkNuI4SsUAkj4IogeljVRbcdYf8xt1bJ7qUg0a9a9z+elYvynY/JLl6J1uLAJJ+lbBqwkyO3PagvUo1BU40A7MZaDaOkJdmFRQk80EWVV+SdfW3JEOe2ox38jJUgArS4tlsC/ckgn9BqcYZYKFOGJEQz2U67LLyUEequUIB+CSeeAdbOlREF3qcbEeU800QCponps3RpRBANHggdjrBjcUp+W2lsJBpS20lN8jmjRAo8myQAB8jVuXDnOxFv46Q7HRwgvBIQ2RZoIR0gL5JoBIPPBOtF9uK+0mQ5CUwIbo+pBdIUSACQD3BIs388c65T4aObaaY2vDrCbc3XjG0Fh1rISG1/TkoWhpEpAJLNqSASQOwUSADY5Goz+IlnPJ8KImO/BjLx7EhKxI8hQVEFdwLPR6oV6X35rS7RnFYWYcpg0/QpceQ8y6GyVxihZBAtR6QfXuTVXwTpo7X8bpqoKypuI/LbSA+pwgsSbBSCtrjk2BSACAkf1XQ8x46nIrXhF7pVHb9opWxvFTcre2I+LxCx9Di8d0rhlKfK6UpPWSCOCo3z/v1L7Jz07cIUnH7UiRoSrCilsFBc5ojg8d+BwfjV3mYjbGQelRcBAxzn4wOiT9FGEZkuJ6VlABJIQk2SbqkEj7gmt7Fpl4raUGJExbOPgh1BlPdJbdSaQkqSkgfeVkrSj1Sk3/AFABkTjqnSWhTqoSlnMfi43IOXhuSVLXI8nyFKVyVBBpP/Br9NdDeAmH3E14Pw8fkMAiBEekKWlIAbfnBRPQpaTyqyelPHHSDVaj8OtGH3GnJ7qx0KK5GaLzK5MTzm2nSCUnoBCwKCbAPBsc1zi3b415N2TOjtymGMkjqSqapaA01QolhsEiyB0gkqJBuwQNdyusuP40aiVOT5N+Tc8W2do7ahOYOJHSZsRhLkmSlkuIdkLFpaCgk9jZIsdwL72h1YoeallxIW+slxzmiCD2F9+4Ngngi9ScnLR8tMTNyXnTlpWXZEx4nznz2AJKqIFGhQI4FkUdSzrDMbHuPojuynJpUIqi91rSa4WSLohIskWOK407p47FoXmtt6bK99Cp2SxEW1IaaXyCoDpAA5UemyRXpR1KzUOtIMczoLzZF+WiUkEAdrSaIP6DUzi8XKa8tWTfS6+tFBMxCClY7gN3QUL9ErBIIJGtialLbqm34aGVXSQmYtlYA4vodA/4JHtx3pJ6eioNSUxwUx4ja+uwQHgtJvuCCog/Ng6xS5cpmGVqECKAKbSSSe/ACEgC7rm+Nb+45kTHFLcmdlkOLSVIS06ws18lNkDv+2qUrqedKlrWqzwXFEn3Fn40GdkpkWpj+3pb6n/OK0pW6lIPAB7nngA8Dj/jVL03PDzHDKx5cJx7oYLRVI4H9IFgi+5spA+VDSomMmPLeYN22tSDfwa1nHe219Hcs60zFo0aNNEhqT2o+I244D5f8jy3kq8zpvp+asX++ozX02elxKvYg641tHU9MdW9Ym3My4MhB3OXnFglxqRESytKjZsAOKBBJN8gi+AdVbMQPqi0phrGsBDQQQ1IQOuhwogmySCLIAsjsNTU3GNZDZjc9Ln0riJjTanh1UELQaJoEkApvgE86ko+zcdkoGSEPISWZEOCXipD5daK0IBJBBoNk39x7EgEAnUUUoWmy213vbQucng32Y7clgqUgNoUFJBNWkEgV7X7+h1d9gzoOTYWX4yOuAkKdl5GcVobPp0IIFk0eAQBXJPGs02CVY6AoSJKS5jUEoC10SGyCSAaBBr87rvxpd5z6vB7ifeYASpmUSgLSFjg2mweDxXfTsWTvFZJ7ORwTJy57Dj8VTrcNB6TOdTSlmrKGEccketAUbJIBOq7PhpxMyLk40VgyGFhaWXkgggEgA+6jd2eeL/KT2TuZjcaRImPrlZVpKUNtOkDrWeaQkfa20kCya5PJ7AayzGlOy1nq860F4roC0div4Cj0hI9r7EnW3xwZT3yQmXVKfL7wDBYkttuS4kEJ6GjZCEBXJsWCeebPfkCsMS2MPPTPajOomsdDsZ1RSW0OpUD1lJB6hwaFVZ541Kvl2C2qVEkKjuvrCyEgUQOQSK5oqAP5nVVzbrylqS8EOKoArA54FX+tXrKn36Nd70N3w33vIgYhAfCZHnkOPLUAokhQNKsiwaJ7gUT3JrTlyO78Q3iXckw55mVfZ6nwtIUhQJABPIAWBY6+CQAAAeNch450iC2gBYv7QQaF9+/Px+2p5eTWMWprqd8zy6C6ABHv+/Fd/041HlxPu3L0V4qlzuiyeJG9ZGUR5jT56ml9bay3R9xR9hVc32GqOkR8lk3HW4yyty1ENkBBcJuwOAEmxx6X7a1J6yYjpt1Yop61EkE9yAT6Ak8fOvrBSX0Oh1taGShJBUlPNGwTXvyPyoe2rMcanglq02XLFLVivKkPpjvRWHC43AfcSHHASUEBdWDXIqwCBxzepTA49eRyKsottKcg64XQIyAghaQLCABXmJACqHChfHrqGx0VhxxqfI6nXHepDyiQSQDR+LoEjjVsxB+ikPsyutTbRBeUyLW10cpdRYskAgkc2CB6VrWvoXVf6Jr6tiNC+jyaIsZqWAWnVs9cGVZrqF/5S77psC74Oln4h5RLUpzC49iXCeS5SgxkS7FcTX+hHSKv2vjkayeJW/Xg+9jMRIa/mJKJy2VByLLsCnEtqFIXXfi7HxqteGmMGTzrKXRbfTIUSLsdLKlcfqBofCbZyX3NI9g7bfDbinukW11C1CgD2JNkA16GuDqew2PbiRJLM2PjXRISAl1yQkloAEnpo2CTRvngVXOrFkoLUPbubUw8850JEdlSlkjlRAIs0eEiz3B16/tPEYp1cSc/OlP/Th0LfkllABSSFkk8DlJA7kihZItHyp+yj4deiR2K7tjbmIVkHN0M/iq2z5DKYZdDJHUAtZK0gHkVXXXerqkRl1+ZlZbnWF9Tyz1DseTzpoOY+PC8NfxAqcdffkSv5q76ihDbQAongWs9+e/tpS6ZhnW2JzUmkkGjRo1QIDRo0aAHZsmWJXh3M6FEy4oZlxxwq1IUQoEE0QEhRo8c6wR9wpj5yW4wiA7GktrQ40235cc9abBUg9iCEnpqr7GrOobwXnpW+vFOudCJAWwpXsHBQP7/wDF69dwmRSh9alKcYjOfTu2QotEHge4F2L7Cz241A5Stpl0tuU0vRcdqSDkNrY1RcQhqBJLMlSk9RQkGwqgQSeCAB3NCjqseKWNanKVLipX0uwW3mh08ks20q69ShBUfzGp3Z8FeDzMPFyZKEwc+ylUd4GktuggAkXYoiieOCdTWfxeXexLrcxK2ZUV11cdSm6Qvp4eSCR6oCTQ5poj10tV2ZN+hzj5I/k5+w+Tl4qX9RDcKFKSULFkBaD3Sa5o9tMaDvjFZLHrRkVFnJTXwZLvR0oQ2LCUIq6SE9XHuv4vVC3Ti/wzJqS1ZjPfeyT6D1SfYg8H9/XUTr0uKWzzHuXoaOYUlxRCTZShCuCD09aeE382B81qoZ7oTKdb6k9YPT0g3Zv01ZfDPb6puLVKlIhOR33OkJdygivCiB1tAqCVFPN9VjU3j/Bbck3dkVzGBWbxjj4DjzK0+c36kOJKgU9v6r6T76S8kTw2OU3STSLTnImAi/w3YmOMWljMB1axJ6KLnJJJXXobASO9j2FplzLlePDI6vP73wUg1XV+dcV29fjTj8XcN5OATDxEd1hXQ06iIJAcBZLYIcIBJCgQoqPbkVwBpH+Q4HfLBSFKHQBwRz6D9NZxuciT3sY1UcD0lYfBSP4bxHi4hK8q3JL7kqzZugFXzyaopNVRPtabwCUrLZbUFOFRQpJN8kUCR7cf86cHhpg5Uzaqly0OS3gytQhJfAIaFAuhINlSbA5NkH41S1eD26Y245f4lHfwWPYf6Q/LT0LWe4S2m/uPp1D7R3JrXceadtN+DFY70tLyZoWThYtp5uZKZbKmw80hz/UoJCgDxyF1V+hHyLgdy78eMpLWCWUMtNhpt9aaWUi+jj+5IUUk82NZPFPbRxEWLKZhRGo6SGfMbyiJbyuDRdCFqCSaJAFCuOavS/06dPlCabXB6SVEk8k6cnhZjFYuM9Ll202y0hlwoQFLDjqwpQ6TRJDaFggHigD3rS72Th15Cf8AVuJbMeOoUHFdKXXD/Si6r5N8UOSNP/bm28mMa3GjpWehThnSVOBXk/YFLWeKIShIQD2JQoA/dqbqciS7Snpsbb7iq7znLh4SDCU60lUmWHUnyqCEAivtHNWCSO5vnnUW3nUuTH5UhUBKywWmEPtB/wAsVwGkAUTaqBPCaJ415n4ytxS5uVaWlECIRGjNuC/MPFi/cAgdqOsUDbuTk5XHQlOOmPNdQ2wjqFKTYBWa9LJNE8VzZGlqYS1vlDqqtvjg2PFJz8L8O8BjUkBSoAcVXqp5wrN+5CUpH5aTemL455ePP3GqPDWFRkLJart5aQEN18dIv9dLrVWFahEWV7oNGjRposNGjRoAldrTlQcwy4lXSFKAu6o3wf0Om/n3IKpjGaKEtoybPQtYkKZCHQKWDQIN/IIuye96RemfsSfH3Fg3ttT10p2lMLJoIeAoc/7xx+YGp88fuKunv9obhefbiBlwLbWysKjAEdBPYklJINggcdgR7abm2N1Obw2cy/D+nGZhdKZ6HVdB6EkdElBvhQIAX3ugaIURpMSXcnESnGTluyI8a20tKJ6mgL7DsSP+grtr4x06VtzIN5fHFQkNr+9CgChxBFVVc2mwQfQnU1Ye6eP/AApnK97LV4g7dbdbcQ70IiOOgBSVFxMJwiwByf5SgCQRdjg2QNJ3JwZWOmLizGlNupo89lA8hQPqCOQddS7bZxe9cNNz2GyIRISzcjHvkrUyCAFjk/zGjZUCCCDfIIB1QNz7Wi5dv7ChyMEqKFJJU43VX5aqpwVZ6eCBVivuOsObs/GzGbAr/KRXbQiP5/PYvAO5D6SM490l0i/KSTaj8+prTUxm9ts4AycPtNmR1Nxnw5KlJDkiWroPQjtSU9ZJITyQKJPbSqnYjI4V9vIwXVOsoX1NSW0lJSR/ck8pI9fTWvhI7ub3RFjqUA7LkgKKUgck80BWqrici58Ek3WN6LbvjPHP4rGOyYzkfLsNFh5aFEIdaSAGx01wQBXrfe7J1WfPYMAMiOoSSoJUocAjvY9jXGrRlMI4qU+otkho+TSRZBFcenHI/wCxOsP+H3A0l1TagSCokduAP+xOuTMpJI1VW3slfDTOQcK219hVLfTJYnreJCfpltBASg3weokkkeiaPBBlIe89sbhiRcLvdM5yen+QnJxEpS80m6AWkgpcCQAR2ULIBA1XMVg5P1zKC2m3VBIHVVk2CB7kgHgaqm4Iz2392y47a0qciSD0KNLHexfodY+CKrZt5rmdHxueO9is3ksN9WuQ1HlKR1q46+kkBVWa4OvnbuFk5mX5bZDTCCPOfWQEoHtZoEn0H/QWRs4HESc7kvMkKfdLq+pSWx1PPEnnpB/Xk8fnpybe2zFiQ2UzYbCkMuERoyEFaQokV5lGnFWACBx6KJ5Qe5c841r2Zw4Hke/QbC299MGnw0mOwhI+kjrISoJPJfWSP6lUCK5sWAAhIMt4p7nkbZ225tKOuP8AiswBM4x/6Y6AftaBHc3yrng0BXOtvdm4sdsjHuynnHpG5ZYpqI70lMS+Q4scguHigAKqzQ40mmm1ZHzsjNeecmuOWoqPWCCbN+pJ5N33POoscPJXfRZVTE9sk/tWI/kW4WODEh5oEocQXB3JskEg1RJsAHmiB31Z4T0SBEyu50MJi9LasdCuQt8uL6P5roWsAnoQRVAC1oIHB1V8GjcGWl/4fxUsxYs1XS82hxKUFFkkrWkkhASLPPFH8taHi5nY6GYu3sUophRWvKaT69N/cs/7lqsn4odgNP8AjdVpiKtKRf5machk35RFJWr7EjslI4A/bWno0auS0RBo0aNABo0aNABrcxE5zHzUSEE0D9wBqxrT0aGtnU9PaHJJWjeOKGUhuKOYYQFP9Ndb6RX8wACiocWBzdH14qgYlSHw290rCyQlaUBJCzx2FAk8363qv7Vz0nCZBt9pxSQlXUCO6T7/APyPUXpoTcTjt64o5HCpDeUQjzJMFB/zQKt1mhyKslPcUe47S843p+yru+RbXkgYTWX2POj5TE5xhMqwsMtLPWL5okjpPpxZv0vTW21u/ae9cemA+mLt3O9dLBSEsyCa5KaPTRBNAUSTyNKbb+JkZCejFocRESEOKQUtguPuJQVBBKjySRQHYcCrPOhl8a4mG1OdiuJiOlRZkpSaIBAJKbsAEgWLTZAA0q4jI9N8m4up9DZ3zs15Jmys5HZCUrSW8iy4VIdJ4AC0g2eOesKIPFp4BU+5NqKjFEuM6pxhR+14ilFXeuPUf7gPQmr1J7X33vHbbam8blzKiHhTL58xCwPQ/HFUa9RXJ1KS/EPGZIA5raTbTgSR1w1FCCSeT0jjn2FD5J12Vkx+OUdpxk88MqOG3HmsBi5mORHhvqed8xLz56nGlAUSOa9R39hqfR4ghHh2MErBRhmqLX4mXbKmj2+3+7ir7fGsb2R2BJZCS7lIqrJP2ggn5ocj8zrH1bD8jq/EZyTQCVlgkhQ59B2+NO+Tf7RSx/TIbNZ3NZ3BQsc8xFaTEWCp9qwt1VBKSquLofr318YLbLcqQgy3HHVuLpKE/wCtXtfJuyPTU+jMbEhpBix50t9RpSugJSR60LBFn5/fW+x4juweNs7djxV9NCRNV5rgHAHSTVEelc/Oh1bWkg+OVy3svOzdrs4xKn3IjMPGpaWHZkzhBNcEAm1gmuOQavp9tDcXinBwUdzHbUdXkJxNrybwA8riv5QHCAOeRyfQgcaXGbyu5tzTUrzuUlS3Fk9LIUaPwE1ZHbsCOO47gwGByGTjzTjIbi1wEJW40U04sFVEJTzyACTdkUedI+Cd7tjPmetSjLDwc3OJVk38ow/NcKiGCtXmcWSRYoAn1J5OsTeKekyW4QSQAoIbaSCSsngWBwSe3b1A18QMa/lHmoMWEt+StfSwpsEuKJPIIF9V+nY366vX1WN8MMK5brEvciwUF5BC0QbFKQ36Ke5IKxwiuLPIbtb1/oxX2zHuOVC8Ptqu4tCwrNzElE7oUCGkcERgR62AVkdqCb7jSSlyHZUlyQ+srccVaidbObycnLTlypKuSftSOyRrR07HHauSe77mGjRo0wwGjRo0AGjRo0AGjRo0AGpTb+cm4aW2/GcUAhQWAFEFKh6g+h1F6Nca35OptcofuB3phdzMtvTHWsVnGk/y8m3HCkuLPYvNjlCh28xAPoSCResucYlQ4ZYyUPphTkNwlSo4D0VqIkXbbgJslwhwk1ygX3I0gWHnWHQ6y4ptY7FJrV62V4nZzbrhSh9XlKILiOkLbcr+9tQKVakvp9cyVxmlrVExvHG7da+hl4+PIWiWpaUqZWE9DTSg2DQHK1BJWSewIA7E6iN14RzD/SlUtUhb8Zt6nY1AFaOspC7NkApvseRxq9xN3bG3EhYyGK+hlO2fMxLnlJSSKJLC7F8AUkgEE8jWpujCQs5Iclw9xQVrWSo/VNGOtZoCgeUelUOkel65NuWlR2sar9JQYiS44VyWy610EhKFGjXparAPx/xqckY3b6cC1MaMtT7iykpDyC3wLAFN3fuDXOtmTszeCYjTqRFfjoV1oCZjIB+QAefzN+nB1oBiaphMBmCvzfMKylRAokV3Jr9vfsPTbbb4ZlTrh7IfIoCHHEx0MlAAITajYoCyLA7/AB+V6n8BhsfMhJnOZl9hlEuOxJQlkIBQ5Zc6Vg39gBJsVXPbvuI2Ru5cBpUxTLUMkAKdmMpQObAJKgQBfa/01Y4WHg4jBqxeQ31CYhkqL0fFMmQ4u66kldIB4A7rrtx66Lr8dJ8glzyuCHyuNg4xttsoVi5aMmWXXGiViREBC0OiybqqsEA2BydWJhOakZ5/cWJfXhMRIe856fkWwPq1EqJ6EAEqFK6ehFihZPc6gMjvTYu3VJ/w1gg/ISKMnJLTKcsCgUtgBtHxfVXxqg7s3znNwSVOSJb9EdIUtwqWE/2g/wCkfAoaXOK78+DVZJj+S9Z7euF2nGfx21GVee8Oh6YuhIdFCx9vDST/AGpJJAAJrjSlyc+VkZJkSnStR7D0SPYDWsSSbJsnXmq4xqSW7deQ0aNGtmA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA1txclkIv/AJeY+2PYLNftrU0aNbOptE01ufMt95CF/wD3tpP/AG1kO7cyTZdZ/wD1DUDo1ntX0a+SvslpG4ss8rqMkJPe0oAP71rRkzZckkyJLzt/3LJ1r6NdUpGXTflho0aNdOBo0aNABo0aNABo0aNABo0aNAH/2Q=="
            style={{height:40,width:40,borderRadius:"50%",objectFit:"cover",border:"2px solid rgba(180,140,60,0.5)"}}
            alt="AF Logo"/>
          <div>
            <div style={{fontSize:18,fontWeight:700,letterSpacing:3,color:"#e2e8f0",lineHeight:1}}>AF Build Calculator</div>
            <div style={{fontSize:10,letterSpacing:2,color:"#b48c3c",textTransform:"uppercase"}}>Amicitia Ferox</div>
          </div>
        </div>
        <div className="home-inner" style={{maxWidth:860,margin:"48px auto",padding:"0 24px"}}>
          <div className="home-card" style={{background:"#0d1117",borderRadius:14,padding:28,marginBottom:24,border:"1px solid #1e293b"}}>
            <div style={{fontSize:11,fontWeight:700,color:"#b48c3c",letterSpacing:3,textTransform:"uppercase",marginBottom:14}}>➕ New Build</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              <input placeholder="Name your build..." value={newBuildName}
                onChange={e=>setNewBuildName(e.target.value)}
                onKeyDown={e=>e.key==='Enter'&&newBuildName.trim()&&newBuild(newBuildName)}
                style={{flex:1,minWidth:200,fontSize:16,padding:'10px 14px',minHeight:44}} autoFocus/>
              <button onClick={()=>newBuildName.trim()&&newBuild(newBuildName)} disabled={!newBuildName.trim()}
                style={{background:newBuildName.trim()?"#16a34a":"#1a2330",color:newBuildName.trim()?"#fff":"#475569",
                  padding:"0 28px",fontWeight:700,fontSize:15,borderRadius:6,minHeight:44}}>
                Create →
              </button>
            </div>
          </div>
          <div style={{background:"#0d1117",borderRadius:14,padding:28,border:"1px solid #1e293b"}}>
            <div style={{fontSize:11,fontWeight:700,color:"#b48c3c",letterSpacing:3,textTransform:"uppercase",marginBottom:14}}>
              💾 Saved Builds <span style={{color:"#334155",fontWeight:400}}>({saves.length})</span>
            </div>
            {saves.length===0&&<div style={{color:"#334155",fontSize:13,padding:"24px 0",textAlign:"center",borderTop:"1px solid #1e293b"}}>No builds yet — create your first build above</div>}
            {saves.map((save,i)=>{
              const arr=save.countries?JSON.parse(save.countries):[];
              const docs=[...new Set(arr.map(c=>c.doctrine))];
              return(
                <div key={save.key} style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,
                  padding:"18px 20px",marginBottom:i<saves.length-1?8:0,borderRadius:8,cursor:"pointer",
                  background:"#111827",border:"1px solid #1e293b",borderLeft:"3px solid #b48c3c"}}
                  onMouseEnter={e=>{e.currentTarget.style.background="#151e2d";}}
                  onMouseLeave={e=>{e.currentTarget.style.background="#111827";}}>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:18,fontWeight:700,color:"#e2e8f0",marginBottom:4}}>{save.name}</div>
                    <div style={{fontSize:11,color:"#475569",display:"flex",gap:10,flexWrap:"wrap"}}>
                      <span>🕒 {save.updatedAt?new Date(save.updatedAt).toLocaleString('en-GB',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—'}</span>
                      <span>🌍 {arr.length} {arr.length===1?'country':'countries'}</span>
                      {docs.length>0&&<span style={{color:"#64748b"}}>{docs.join(', ')}</span>}
                    </div>
                  </div>
                  <div style={{display:"flex",gap:6,flexShrink:0}}>
                    <button onClick={()=>loadBuild(save)} style={{background:"#1e3a5f",color:"#60a5fa",padding:"9px 22px",fontSize:13,fontWeight:700,borderRadius:6,border:"1px solid #1e40af"}}>Open</button>
                    <button onClick={e=>deleteBuild(save,e)} style={{background:"#1a0a0a",color:"#f87171",padding:"9px 14px",fontSize:14,borderRadius:6,border:"1px solid #7f1d1d"}}>🗑</button>
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{textAlign:"center",marginTop:24,fontSize:10,color:"#1e293b",letterSpacing:2,textTransform:"uppercase"}}>Amicitia Ferox · Since 2024</div>
        </div>
      </div>
    );
  }

  
  return(
    <div style={{minHeight:"100vh",background:"#0d1117",color:"#e2e8f0",fontFamily:"'Rajdhani',sans-serif",position:"relative"}}>
      {/* Remote cursor overlay */}
      {Object.entries(remoteCursors).map(([sid,cur],i)=>(
        <div key={sid} style={{
          position:"absolute",
          left:`${cur.x}%`,
          top:`${cur.y}%`,
          pointerEvents:"none",
          zIndex:9999,
          transform:"translate(0,-2px)",
          transition:"left 0.05s linear,top 0.05s linear"
        }}>
          {/* SVG cursor */}
          <svg width="18" height="22" viewBox="0 0 18 22" fill="none" style={{filter:`drop-shadow(0 1px 2px rgba(0,0,0,0.7))`}}>
            <path d="M0 0L0 16L4.5 12L7 18L9 17L6.5 11L12 11Z" fill={cur.color} stroke="#000" strokeWidth="1"/>
          </svg>
          {/* Name label */}
          <div style={{
            position:"absolute",
            left:14,top:12,
            background:cur.color,
            color:"#000",
            fontSize:10,
            fontWeight:700,
            padding:"1px 5px",
            borderRadius:3,
            whiteSpace:"nowrap",
            fontFamily:"'Rajdhani',sans-serif",
            letterSpacing:0.5,
            boxShadow:"0 1px 4px rgba(0,0,0,0.5)"
          }}>{userNames[sid]||cur.name||'User'}</div>
        </div>
      ))}
      {/* Team panel */}
      {showTeamPanel&&(
        <div style={{position:"fixed",top:70,right:16,zIndex:500,background:"#111827",border:"1px solid #1e3a5f",borderRadius:10,padding:16,minWidth:280,boxShadow:"0 8px 32px rgba(0,0,0,0.6)"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
            <div style={{fontSize:11,fontWeight:700,color:"#60a5fa",letterSpacing:2,textTransform:"uppercase"}}>👥 Team Names</div>
            <button onClick={()=>setShowTeamPanel(false)} style={{background:"none",border:"none",color:"#475569",fontSize:18,cursor:"pointer",lineHeight:1,padding:"0 2px"}}>✕</button>
          </div>
          {/* Own name */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:10,color:"#475569",marginBottom:4}}>Your name <span style={{color:"#334155"}}>(press Enter to save)</span></div>
            <input
              placeholder="Your name..."
              defaultValue={userNames[mySessionId.current]||localStorage.getItem('af_username')||''}
              onBlur={e=>setMyUserName(e.target.value.trim())}
              onKeyDown={e=>e.key==='Enter'&&(setMyUserName(e.target.value.trim()),e.target.blur())}
              style={{width:"100%",background:"#0d1117",border:"1px solid #1e3a5f",borderRadius:4,color:"#e2e8f0",padding:"6px 8px",fontSize:12}}
            />
          </div>
          {/* Other users - read only */}
          {[...presentUsers].map((u,i)=>{
            const dotColor=u.color||"#22c55e";
            const displayName=u.userName||userNames[u.sessionId]||u.viewing||`User ${i+1}`;
            return(
              <div key={u.sessionId} style={{display:"flex",alignItems:"center",gap:6,marginBottom:6,background:"#0d1f35",borderRadius:5,padding:"5px 8px",border:`1px solid ${dotColor}33`}}>
                <span style={{width:7,height:7,borderRadius:"50%",background:dotColor,display:"inline-block",flexShrink:0}}/>
                <span style={{fontSize:12,color:dotColor,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{displayName}</span>
                {u.tab&&<span style={{fontSize:10,color:"#475569",marginLeft:"auto",flexShrink:0}}>{u.tab}</span>}
              </div>
            );
          })}
          {presentUsers.length===0&&<div style={{fontSize:11,color:"#334155",fontStyle:"italic"}}>No other users online</div>}
          <button onClick={()=>setShowTeamPanel(false)} style={{marginTop:10,width:"100%",background:"#1e293b",color:"#94a3b8",padding:"7px",fontSize:11,fontWeight:700,borderRadius:5,border:"1px solid #334155",cursor:"pointer",letterSpacing:1}}>Close</button>
        </div>
      )}
      <div className="app-header">
        <style>{`
          @media(max-width:768px){
            .hdr-row1{flex-wrap:nowrap!important}
            .hdr-logo img{height:32px!important;width:32px!important}
            .hdr-title{font-size:15px!important;letter-spacing:1px!important}
            .hdr-row2{display:flex!important;width:100%!important}
            .hdr-savename{display:none!important}
            .hdr-userpill .hdr-lastaction{display:none!important}
            .hdr-userpill{max-width:90px!important}
            .hdr-add-btn{padding:6px 10px!important;font-size:11px!important;letter-spacing:0!important}
          }
        `}</style>
        {/* Row 1: back + logo + title + add-btn */}
        <div className="hdr-row1" style={{display:"flex",alignItems:"center",gap:8,width:"100%"}}>
          <div className="hdr-logo" style={{display:"flex",alignItems:"center",gap:8,minWidth:0,flex:1}}>
          <button onClick={()=>window.AFBridge&&window.AFBridge.toPlanner()}
            style={{background:"#1e293b",color:"#94a3b8",padding:"6px 10px",fontSize:12,fontWeight:700,borderRadius:6,flexShrink:0,whiteSpace:"nowrap"}}>
            🗺 Map
          </button>
          <img src="data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCACwALcDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAAcFBgMECAEC/8QAPhAAAQQBAwIFAgQEBQIFBQAAAQIDBBEFAAYhEjEHE0FRYRQiFXGBkQgjMlIWM0JiobHBJDRDktFjcoKT4f/EABkBAAMBAQEAAAAAAAAAAAAAAAADBAIBBf/EACkRAAMAAgEEAgEEAgMAAAAAAAABAgMRIQQSMUETUSIyQmGhFJEjcYH/2gAMAwEAAhEDEQA/AOMtGjRoANGjRoANGjRoANGjRoANGrhs3wy31u5CXsHtyY9GUa+pdSGmf/eukn9DppYP+GLKKUn/ABJvTC4xX+tiIhyW8n4ISAAf10q8+OP1MZOK68I590a6rH8P3hNjGenJ72zMuRVgJLMUfn0rClVqPHhL4NKT0/iO4UL/AKer61pSQem7sN3X6DSH12FDp6PLXg5k0a6pkfw7eGGRYH4Lv/KRZBH+W8y3K5r/AOn08d/21UM//DDulkOK21uHCZ7o/wDQDhjvn/8ABX/zrc9Xir2Yrpsi9CF0asG7tl7r2lILG48BPxpugt5o9CvyWPtP6HVf1QmmtoS01ww0aNGunA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0ayw40iZKbixGHH33VdKG20lSlH2AGm94beGEOLFTuXfY8qGg2xjySFPVza6/wBP+0Gz3NDWMmSYW2bjHVvSKp4a+F+598uh2CwmHjEqp2fJ+1oe/T/cfy4HqRp04bCeE3hsLEdO6c2yr75MkBTSCBdoT/TX7/CieNVvxD8R5zsZnF4yMuFi/wDJYaYSUJNGqNCgOBwO363rNDwTkPIPYbJPNycRuRkIhzaH8mTYUlJPNEK4I7kKB15+XLktc8Ivx4oj+WT+7PGKc1GabkzY+ML7RfjsdClKUgj7erggA1xYUao2QRqqbv3flI+18FuJt5U1jI9bDqJDqiGHEq7hIIFFNECq57emvMzsde+1w+iPNh5LERkQsiQxbKkt0lKvMJCUccfcQPa9X47C27F2wziNx5GNGx5kIlNtppTjf2dINqISbqz0BYsccaVrCkm+WM78tbS4KfmctOi+Lu28VGQyjEZBMZ8NhoUoKT9yb9U99Z9sYec9vTNfi0pwQfrXYsZJkJbI6h/WkWL6SocAdyPbV/nI8PGHcVJMfJZJ+GyluHIFjpT6dJ6E0PmyPnWy/l9juxmnjgpL8sOIJCZC1LJcLhJA6wLpIJ76U8k60l6/sZM3vb2c+4uXudrxQZ2nIlukpneQoLFkpu7N/HOr5k9xbkj74ewmBhtpgfWpjtPtTfMQEk196CVC+3oKA5GmC0nw5l7kOYkRsnjcqyekS3kBVUK7lCu1/wD91DYXw6wcLccrdG1smxNlNJd6UOr6aNcLtPUkV6FXQO1kem6yY7516/sWpyyvPsxMeMciHn17SmvtZ5AkGKuLLjlYfJ4BANgg8AUpP5HsdDcXhx4ZeIC1K28F7N3AvkxFD/wylHsnpVRSfj7T34Nar8fbrm1d0SNz7gflPzWY941EltIDrilcFCk2laU2TYVetjcOLW5kfwqLNMGJt9pb8/KST1qc80pXVAAHm6H53666msdr436BayL/AJEJ3f8AsTceyciYmbh9KCabkNHqac/I+h+DR1WNdM7U3vi9w4WRi8otOXxYdEdTklgoKSQem0kmwQlRFGx08HgJK38SfCx/GyPxHahVkcY8bDKTbrPqB/uHsR341dh6nb7cnDJc3S9q7sb2hXaNeqBSopUCCDRB7jXmqyMNGjRoANGjRoANGjRoANSG3MPOz+biYfHN+ZJlOhtAPAF+pPoALJPsNfOBxcrNZaPi4Ra+okK6UeYsITfyTwNdIfw9w4O2dsSoW7MEuLIVlFBb9D6hJDVfaO5SELUTXBC77gaXkvsnZvHHc9GorY+1PDxIXjckvIZJMciTNX0lBV6paTxSTwLJJP5EjVebzOM3rLkYuVuKTj5QQsthuN5iEpSCT2IN9+APb9JXxi2nu7zW3MFG/FMfPBMCVCAKHk2eALtKk109PoRXsNJnYicpH3pAEBhwzW3r8spIPHe/bUkRVy7t8llZfjaiPDHVtTbe5tqYKZADEPcGOeWHm1Bv6htw8WggfcgqTVHjkDnU6iFExYkL3FI8puW6JDeCZd6glYTVlVg1fcggAAfcoitYYjMfainUJLzk6WSt53rJLYJJ6EWPuPF2QbIJIHYQeMYm7v3UjBYOIiRIkOhT855Bc8hBISVqs0o2QLoC+OdRt1d8spUzjW2Se5d8SmIzS/rouFxaUBLKI5SlQF2On7RyQCCWwAeAVE6Xk/xTYiOPDEQlvqcUoqdfUR1X39Sv0HdRHxqgbpbzP4m+9mFSXnPPcZ890HpWpBpQBPtx+41Ea9DH0mOfPJDXVX4nguUrxD3TISpcZxmKhP8AUtiOnqonspZBJ/U6029+7tQ4HE5qQFjsbHtWp7wiMPHRMjl8ynrxUhxrHLZIsPFxX3WP9qbN+ho6ruQxDu3PEH8Jd6HTEnoSlRFpcT1ApPyCKP66YlG3OvAt1aSe/JKxfFDdTVec9Fkm7K3GE+Z/7x9w/fVgx3ifDly2XMnEkQnBYW6w6VpN+tH7h+h9BrD4nYTd726sxBibeWvGiUpMcs45HCQrjpUE9Q/Q6V6gUqKVAgg0QfTXPhx5J8GvnyQ/J03ht8Ll4wsypMfOY1SelSX1hS+f7lFPf2Kwb7AjvrFlduws5h8gjb0x1ceY0gSMd1W60E/0lAJ5A5AFkc8HsAkPDLG5PJ70wsCFIfhoyE9qEZKUnoBWoAg+h4PbTfYeyeMnxoWfaexmRLYcYcSoBp1JK0CjVIJKFpINg0RwNQ58Lwvcstw5ZzLTRBpxSUbXibT2tFfQh+eh3IZGcUMKW4jgNoBJoizxd+laucvOxcPuibhfxHHxm/M8iMn6jrXdDq4F9I674sVfAoGvl9qPlMhDzsSGyrKQXUvWtNIeIPZRHYiuDZIIHcHhB7vRkZO9ZgUy+Zz0iwgJPmFZPt73rsT/AJFcv1/Zm2+mXHKY+8/4TYHe7M6XGnKxu5lUporUlMeUrpP2rT3Sokf1g0eSRwdc15CJIgTnoUtotPsLLbiD6EGjrqLwwxu7Mpjm28pCVjH8cT9fJmUhptCVdJUSfW0lPrZFdxqG/iFibdy2CwmA2fhEzMt9WGUSWmrlSRSiSuuQCVfaD2AHpp/TXcvssV1ERS74Ob9GpbdeAm7azK8VkFMKkNpSpRZcC0ix2scGu2onVxCGjRo0AGjRo0AXLw8xMZ/qyLkxcaUyrqjkj7DXcK4JAPawDWmxk8rKMNljLRFSISF9TLjLw62SeLQsGiKA4NjjsDel5s6P9Jt5iYXEBwkqQ2r+lxJ7gn0Px6jWYT1pddbYdRHYe5Uw8A42e9Aggg9zRIJHpzpFruZRD7EMbbG79x7bStW358XLwVlD0iA6iw6Qe/lHlLgHctkjgE9uLltTfGzd0bkS9kMZFws9TZQXJIbdCl2KHX0ocBIB/rXyRXJJBSKlMPuioa1K5FwZNlR5N9Cgsg1zQA4HbWlk5qGn/qI891wtN+WUzmSCpJu0cKIrnuCPcAenHj2tGlXs6RneHOBy8mb9Jl5DDkOQVLblOFbLrVJJBXSQgEkgkk9jQNHWfa2xM5tmHGd227GyJS4txrqWGnVNLKHEhQVRtKkVwSCFccitc/7X37L2suUhnHxlofBUhaEKS60SKIQ6FJWAfYqI+L50y9geMkZyNEivORBLaIRHRLZT5TgVxdgoDRFcqTyTySdR5sLS48D8eV7+yX8XfBncu6dgMs4LDmTlYD6FMNechALBDinCCT0qWpakk83QA9Nch5KFLxuQkY+fHcjS47imnmXE0pCgaII99debk8ds5h4DmNx8RAyIWUofTJQ82k0UgpKBS6BsGzR5J9BzB4jtbmc3NIyu6YUtiZkVecHHmykPDt1JPZQ47jT+jt9vYxPU49Pu+yVye7lYbA4fBbYyDLjTDJemO/TAhchZNj+Ym6AAF/Otzdb3+JMZt3e7riUuNrRAy7iUcNONkFDhCR2Uj29U6iPD/wAOty7zeC4DDULHAnzcnPX5ERqu9uHgn4FnTCi+Euawsd7/AAv4n7IyT8hPluwm54Af9k9LqehfPbT2ol8eRK7q/wChZ+I+VZyO+8xkMdPVJiyJSnGXE9SQUnngGiK7dvTULh8bPzGUjYvFxHpk2U4G2GGk9SlqPYAazbkw+TwWZkYzMRfpZrSv5jdpIF88dPFflqb8KnN1Qd3xs3tKLIdm4+3S62i0spIIKlE8JFE8nTP0zwZ06rR1B4PeD+5NnbFbVncIGcyrIJlqZS+hwlKFtKaNhVJUKdF2KBN+mpfc+xMpnsE+nPLjQ0+Y0p5xsl1wNNFxdJSgElalvLBA4AHPPGoTC+Ou4c3jGoM2JHRP8yn3lvBptZB7HqBAvpFGvyI76gPEHxdjtxJ2PbdhGVJJMtmE00uIggAEkpK/NUo91cG+QQONeRqsmXZ6TVYo7eC0seHuIxS8dElbglSp0twLLTJS22w0EFayVnr6q6UpsWbUB6g61d0bp2TszcqsxicYxl30oMbz4wbC0LAtNPLKlKNEgqbSKpIJutJzcu+39yNR2FYqE3GZp1wuN0464AQAtyyspAJoWBfp66jYGQW9PGSlT2GnukIQWWiVoQAAAm6PAodx6XfGq8WLS21pk1W2tNjLyu7Nw7mjR05Mw8BgmyFNxkpIBI5CykkuPLrgLXQsmjya0o+4FtMuxsFDX0EdDsgqBffPeiokBCPcA1V2Txqhv5bGNPhQdfmlJP2uuhCSTX+hFqB+Ov21gazbkvpaCXCylYUGGR5aCR6kjv7Enkj19ndnOzE1pa9EL4o44NTkZNeREuRJV/NSlP2N8cBKibUPS6A9r1S9MDxCjuyMOJ7q2wULQEttABCE1QHv+1j5vS/06XtCLWmGjRo1oyGvQLNDXmpDbkT6/PwYdLV5z6E0hNqPPYD1OuN6BFtltzoGIjI+q6elpJLPQaFji+QDY5B/6HX0UsLjJdXGhvtkAFSHK59bBAIP6/qdbu/WvpZqogkB9tkkNuI4SsUAkj4IogeljVRbcdYf8xt1bJ7qUg0a9a9z+elYvynY/JLl6J1uLAJJ+lbBqwkyO3PagvUo1BU40A7MZaDaOkJdmFRQk80EWVV+SdfW3JEOe2ox38jJUgArS4tlsC/ckgn9BqcYZYKFOGJEQz2U67LLyUEequUIB+CSeeAdbOlREF3qcbEeU800QCponps3RpRBANHggdjrBjcUp+W2lsJBpS20lN8jmjRAo8myQAB8jVuXDnOxFv46Q7HRwgvBIQ2RZoIR0gL5JoBIPPBOtF9uK+0mQ5CUwIbo+pBdIUSACQD3BIs388c65T4aObaaY2vDrCbc3XjG0Fh1rISG1/TkoWhpEpAJLNqSASQOwUSADY5Goz+IlnPJ8KImO/BjLx7EhKxI8hQVEFdwLPR6oV6X35rS7RnFYWYcpg0/QpceQ8y6GyVxihZBAtR6QfXuTVXwTpo7X8bpqoKypuI/LbSA+pwgsSbBSCtrjk2BSACAkf1XQ8x46nIrXhF7pVHb9opWxvFTcre2I+LxCx9Di8d0rhlKfK6UpPWSCOCo3z/v1L7Jz07cIUnH7UiRoSrCilsFBc5ojg8d+BwfjV3mYjbGQelRcBAxzn4wOiT9FGEZkuJ6VlABJIQk2SbqkEj7gmt7Fpl4raUGJExbOPgh1BlPdJbdSaQkqSkgfeVkrSj1Sk3/AFABkTjqnSWhTqoSlnMfi43IOXhuSVLXI8nyFKVyVBBpP/Br9NdDeAmH3E14Pw8fkMAiBEekKWlIAbfnBRPQpaTyqyelPHHSDVaj8OtGH3GnJ7qx0KK5GaLzK5MTzm2nSCUnoBCwKCbAPBsc1zi3b415N2TOjtymGMkjqSqapaA01QolhsEiyB0gkqJBuwQNdyusuP40aiVOT5N+Tc8W2do7ahOYOJHSZsRhLkmSlkuIdkLFpaCgk9jZIsdwL72h1YoeallxIW+slxzmiCD2F9+4Ngngi9ScnLR8tMTNyXnTlpWXZEx4nznz2AJKqIFGhQI4FkUdSzrDMbHuPojuynJpUIqi91rSa4WSLohIskWOK407p47FoXmtt6bK99Cp2SxEW1IaaXyCoDpAA5UemyRXpR1KzUOtIMczoLzZF+WiUkEAdrSaIP6DUzi8XKa8tWTfS6+tFBMxCClY7gN3QUL9ErBIIJGtialLbqm34aGVXSQmYtlYA4vodA/4JHtx3pJ6eioNSUxwUx4ja+uwQHgtJvuCCog/Ng6xS5cpmGVqECKAKbSSSe/ACEgC7rm+Nb+45kTHFLcmdlkOLSVIS06ws18lNkDv+2qUrqedKlrWqzwXFEn3Fn40GdkpkWpj+3pb6n/OK0pW6lIPAB7nngA8Dj/jVL03PDzHDKx5cJx7oYLRVI4H9IFgi+5spA+VDSomMmPLeYN22tSDfwa1nHe219Hcs60zFo0aNNEhqT2o+I244D5f8jy3kq8zpvp+asX++ozX02elxKvYg641tHU9MdW9Ym3My4MhB3OXnFglxqRESytKjZsAOKBBJN8gi+AdVbMQPqi0phrGsBDQQQ1IQOuhwogmySCLIAsjsNTU3GNZDZjc9Ln0riJjTanh1UELQaJoEkApvgE86ko+zcdkoGSEPISWZEOCXipD5daK0IBJBBoNk39x7EgEAnUUUoWmy213vbQucng32Y7clgqUgNoUFJBNWkEgV7X7+h1d9gzoOTYWX4yOuAkKdl5GcVobPp0IIFk0eAQBXJPGs02CVY6AoSJKS5jUEoC10SGyCSAaBBr87rvxpd5z6vB7ifeYASpmUSgLSFjg2mweDxXfTsWTvFZJ7ORwTJy57Dj8VTrcNB6TOdTSlmrKGEccketAUbJIBOq7PhpxMyLk40VgyGFhaWXkgggEgA+6jd2eeL/KT2TuZjcaRImPrlZVpKUNtOkDrWeaQkfa20kCya5PJ7AayzGlOy1nq860F4roC0div4Cj0hI9r7EnW3xwZT3yQmXVKfL7wDBYkttuS4kEJ6GjZCEBXJsWCeebPfkCsMS2MPPTPajOomsdDsZ1RSW0OpUD1lJB6hwaFVZ541Kvl2C2qVEkKjuvrCyEgUQOQSK5oqAP5nVVzbrylqS8EOKoArA54FX+tXrKn36Nd70N3w33vIgYhAfCZHnkOPLUAokhQNKsiwaJ7gUT3JrTlyO78Q3iXckw55mVfZ6nwtIUhQJABPIAWBY6+CQAAAeNch450iC2gBYv7QQaF9+/Px+2p5eTWMWprqd8zy6C6ABHv+/Fd/041HlxPu3L0V4qlzuiyeJG9ZGUR5jT56ml9bay3R9xR9hVc32GqOkR8lk3HW4yyty1ENkBBcJuwOAEmxx6X7a1J6yYjpt1Yop61EkE9yAT6Ak8fOvrBSX0Oh1taGShJBUlPNGwTXvyPyoe2rMcanglq02XLFLVivKkPpjvRWHC43AfcSHHASUEBdWDXIqwCBxzepTA49eRyKsottKcg64XQIyAghaQLCABXmJACqHChfHrqGx0VhxxqfI6nXHepDyiQSQDR+LoEjjVsxB+ikPsyutTbRBeUyLW10cpdRYskAgkc2CB6VrWvoXVf6Jr6tiNC+jyaIsZqWAWnVs9cGVZrqF/5S77psC74Oln4h5RLUpzC49iXCeS5SgxkS7FcTX+hHSKv2vjkayeJW/Xg+9jMRIa/mJKJy2VByLLsCnEtqFIXXfi7HxqteGmMGTzrKXRbfTIUSLsdLKlcfqBofCbZyX3NI9g7bfDbinukW11C1CgD2JNkA16GuDqew2PbiRJLM2PjXRISAl1yQkloAEnpo2CTRvngVXOrFkoLUPbubUw8850JEdlSlkjlRAIs0eEiz3B16/tPEYp1cSc/OlP/Th0LfkllABSSFkk8DlJA7kihZItHyp+yj4deiR2K7tjbmIVkHN0M/iq2z5DKYZdDJHUAtZK0gHkVXXXerqkRl1+ZlZbnWF9Tyz1DseTzpoOY+PC8NfxAqcdffkSv5q76ihDbQAongWs9+e/tpS6ZhnW2JzUmkkGjRo1QIDRo0aAHZsmWJXh3M6FEy4oZlxxwq1IUQoEE0QEhRo8c6wR9wpj5yW4wiA7GktrQ40235cc9abBUg9iCEnpqr7GrOobwXnpW+vFOudCJAWwpXsHBQP7/wDF69dwmRSh9alKcYjOfTu2QotEHge4F2L7Cz241A5Stpl0tuU0vRcdqSDkNrY1RcQhqBJLMlSk9RQkGwqgQSeCAB3NCjqseKWNanKVLipX0uwW3mh08ks20q69ShBUfzGp3Z8FeDzMPFyZKEwc+ylUd4GktuggAkXYoiieOCdTWfxeXexLrcxK2ZUV11cdSm6Qvp4eSCR6oCTQ5poj10tV2ZN+hzj5I/k5+w+Tl4qX9RDcKFKSULFkBaD3Sa5o9tMaDvjFZLHrRkVFnJTXwZLvR0oQ2LCUIq6SE9XHuv4vVC3Ti/wzJqS1ZjPfeyT6D1SfYg8H9/XUTr0uKWzzHuXoaOYUlxRCTZShCuCD09aeE382B81qoZ7oTKdb6k9YPT0g3Zv01ZfDPb6puLVKlIhOR33OkJdygivCiB1tAqCVFPN9VjU3j/Bbck3dkVzGBWbxjj4DjzK0+c36kOJKgU9v6r6T76S8kTw2OU3STSLTnImAi/w3YmOMWljMB1axJ6KLnJJJXXobASO9j2FplzLlePDI6vP73wUg1XV+dcV29fjTj8XcN5OATDxEd1hXQ06iIJAcBZLYIcIBJCgQoqPbkVwBpH+Q4HfLBSFKHQBwRz6D9NZxuciT3sY1UcD0lYfBSP4bxHi4hK8q3JL7kqzZugFXzyaopNVRPtabwCUrLZbUFOFRQpJN8kUCR7cf86cHhpg5Uzaqly0OS3gytQhJfAIaFAuhINlSbA5NkH41S1eD26Y245f4lHfwWPYf6Q/LT0LWe4S2m/uPp1D7R3JrXceadtN+DFY70tLyZoWThYtp5uZKZbKmw80hz/UoJCgDxyF1V+hHyLgdy78eMpLWCWUMtNhpt9aaWUi+jj+5IUUk82NZPFPbRxEWLKZhRGo6SGfMbyiJbyuDRdCFqCSaJAFCuOavS/06dPlCabXB6SVEk8k6cnhZjFYuM9Ll202y0hlwoQFLDjqwpQ6TRJDaFggHigD3rS72Th15Cf8AVuJbMeOoUHFdKXXD/Si6r5N8UOSNP/bm28mMa3GjpWehThnSVOBXk/YFLWeKIShIQD2JQoA/dqbqciS7Snpsbb7iq7znLh4SDCU60lUmWHUnyqCEAivtHNWCSO5vnnUW3nUuTH5UhUBKywWmEPtB/wAsVwGkAUTaqBPCaJ415n4ytxS5uVaWlECIRGjNuC/MPFi/cAgdqOsUDbuTk5XHQlOOmPNdQ2wjqFKTYBWa9LJNE8VzZGlqYS1vlDqqtvjg2PFJz8L8O8BjUkBSoAcVXqp5wrN+5CUpH5aTemL455ePP3GqPDWFRkLJart5aQEN18dIv9dLrVWFahEWV7oNGjRposNGjRoAldrTlQcwy4lXSFKAu6o3wf0Om/n3IKpjGaKEtoybPQtYkKZCHQKWDQIN/IIuye96RemfsSfH3Fg3ttT10p2lMLJoIeAoc/7xx+YGp88fuKunv9obhefbiBlwLbWysKjAEdBPYklJINggcdgR7abm2N1Obw2cy/D+nGZhdKZ6HVdB6EkdElBvhQIAX3ugaIURpMSXcnESnGTluyI8a20tKJ6mgL7DsSP+grtr4x06VtzIN5fHFQkNr+9CgChxBFVVc2mwQfQnU1Ye6eP/AApnK97LV4g7dbdbcQ70IiOOgBSVFxMJwiwByf5SgCQRdjg2QNJ3JwZWOmLizGlNupo89lA8hQPqCOQddS7bZxe9cNNz2GyIRISzcjHvkrUyCAFjk/zGjZUCCCDfIIB1QNz7Wi5dv7ChyMEqKFJJU43VX5aqpwVZ6eCBVivuOsObs/GzGbAr/KRXbQiP5/PYvAO5D6SM490l0i/KSTaj8+prTUxm9ts4AycPtNmR1Nxnw5KlJDkiWroPQjtSU9ZJITyQKJPbSqnYjI4V9vIwXVOsoX1NSW0lJSR/ck8pI9fTWvhI7ub3RFjqUA7LkgKKUgck80BWqrici58Ek3WN6LbvjPHP4rGOyYzkfLsNFh5aFEIdaSAGx01wQBXrfe7J1WfPYMAMiOoSSoJUocAjvY9jXGrRlMI4qU+otkho+TSRZBFcenHI/wCxOsP+H3A0l1TagSCokduAP+xOuTMpJI1VW3slfDTOQcK219hVLfTJYnreJCfpltBASg3weokkkeiaPBBlIe89sbhiRcLvdM5yen+QnJxEpS80m6AWkgpcCQAR2ULIBA1XMVg5P1zKC2m3VBIHVVk2CB7kgHgaqm4Iz2392y47a0qciSD0KNLHexfodY+CKrZt5rmdHxueO9is3ksN9WuQ1HlKR1q46+kkBVWa4OvnbuFk5mX5bZDTCCPOfWQEoHtZoEn0H/QWRs4HESc7kvMkKfdLq+pSWx1PPEnnpB/Xk8fnpybe2zFiQ2UzYbCkMuERoyEFaQokV5lGnFWACBx6KJ5Qe5c841r2Zw4Hke/QbC299MGnw0mOwhI+kjrISoJPJfWSP6lUCK5sWAAhIMt4p7nkbZ225tKOuP8AiswBM4x/6Y6AftaBHc3yrng0BXOtvdm4sdsjHuynnHpG5ZYpqI70lMS+Q4scguHigAKqzQ40mmm1ZHzsjNeecmuOWoqPWCCbN+pJ5N33POoscPJXfRZVTE9sk/tWI/kW4WODEh5oEocQXB3JskEg1RJsAHmiB31Z4T0SBEyu50MJi9LasdCuQt8uL6P5roWsAnoQRVAC1oIHB1V8GjcGWl/4fxUsxYs1XS82hxKUFFkkrWkkhASLPPFH8taHi5nY6GYu3sUophRWvKaT69N/cs/7lqsn4odgNP8AjdVpiKtKRf5machk35RFJWr7EjslI4A/bWno0auS0RBo0aNABo0aNABrcxE5zHzUSEE0D9wBqxrT0aGtnU9PaHJJWjeOKGUhuKOYYQFP9Ndb6RX8wACiocWBzdH14qgYlSHw290rCyQlaUBJCzx2FAk8363qv7Vz0nCZBt9pxSQlXUCO6T7/APyPUXpoTcTjt64o5HCpDeUQjzJMFB/zQKt1mhyKslPcUe47S843p+yru+RbXkgYTWX2POj5TE5xhMqwsMtLPWL5okjpPpxZv0vTW21u/ae9cemA+mLt3O9dLBSEsyCa5KaPTRBNAUSTyNKbb+JkZCejFocRESEOKQUtguPuJQVBBKjySRQHYcCrPOhl8a4mG1OdiuJiOlRZkpSaIBAJKbsAEgWLTZAA0q4jI9N8m4up9DZ3zs15Jmys5HZCUrSW8iy4VIdJ4AC0g2eOesKIPFp4BU+5NqKjFEuM6pxhR+14ilFXeuPUf7gPQmr1J7X33vHbbam8blzKiHhTL58xCwPQ/HFUa9RXJ1KS/EPGZIA5raTbTgSR1w1FCCSeT0jjn2FD5J12Vkx+OUdpxk88MqOG3HmsBi5mORHhvqed8xLz56nGlAUSOa9R39hqfR4ghHh2MErBRhmqLX4mXbKmj2+3+7ir7fGsb2R2BJZCS7lIqrJP2ggn5ocj8zrH1bD8jq/EZyTQCVlgkhQ59B2+NO+Tf7RSx/TIbNZ3NZ3BQsc8xFaTEWCp9qwt1VBKSquLofr318YLbLcqQgy3HHVuLpKE/wCtXtfJuyPTU+jMbEhpBix50t9RpSugJSR60LBFn5/fW+x4juweNs7djxV9NCRNV5rgHAHSTVEelc/Oh1bWkg+OVy3svOzdrs4xKn3IjMPGpaWHZkzhBNcEAm1gmuOQavp9tDcXinBwUdzHbUdXkJxNrybwA8riv5QHCAOeRyfQgcaXGbyu5tzTUrzuUlS3Fk9LIUaPwE1ZHbsCOO47gwGByGTjzTjIbi1wEJW40U04sFVEJTzyACTdkUedI+Cd7tjPmetSjLDwc3OJVk38ow/NcKiGCtXmcWSRYoAn1J5OsTeKekyW4QSQAoIbaSCSsngWBwSe3b1A18QMa/lHmoMWEt+StfSwpsEuKJPIIF9V+nY366vX1WN8MMK5brEvciwUF5BC0QbFKQ36Ke5IKxwiuLPIbtb1/oxX2zHuOVC8Ptqu4tCwrNzElE7oUCGkcERgR62AVkdqCb7jSSlyHZUlyQ+srccVaidbObycnLTlypKuSftSOyRrR07HHauSe77mGjRo0wwGjRo0AGjRo0AGjRo0AGpTb+cm4aW2/GcUAhQWAFEFKh6g+h1F6Nca35OptcofuB3phdzMtvTHWsVnGk/y8m3HCkuLPYvNjlCh28xAPoSCResucYlQ4ZYyUPphTkNwlSo4D0VqIkXbbgJslwhwk1ygX3I0gWHnWHQ6y4ptY7FJrV62V4nZzbrhSh9XlKILiOkLbcr+9tQKVakvp9cyVxmlrVExvHG7da+hl4+PIWiWpaUqZWE9DTSg2DQHK1BJWSewIA7E6iN14RzD/SlUtUhb8Zt6nY1AFaOspC7NkApvseRxq9xN3bG3EhYyGK+hlO2fMxLnlJSSKJLC7F8AUkgEE8jWpujCQs5Iclw9xQVrWSo/VNGOtZoCgeUelUOkel65NuWlR2sar9JQYiS44VyWy610EhKFGjXparAPx/xqckY3b6cC1MaMtT7iykpDyC3wLAFN3fuDXOtmTszeCYjTqRFfjoV1oCZjIB+QAefzN+nB1oBiaphMBmCvzfMKylRAokV3Jr9vfsPTbbb4ZlTrh7IfIoCHHEx0MlAAITajYoCyLA7/AB+V6n8BhsfMhJnOZl9hlEuOxJQlkIBQ5Zc6Vg39gBJsVXPbvuI2Ru5cBpUxTLUMkAKdmMpQObAJKgQBfa/01Y4WHg4jBqxeQ31CYhkqL0fFMmQ4u66kldIB4A7rrtx66Lr8dJ8glzyuCHyuNg4xttsoVi5aMmWXXGiViREBC0OiybqqsEA2BydWJhOakZ5/cWJfXhMRIe856fkWwPq1EqJ6EAEqFK6ehFihZPc6gMjvTYu3VJ/w1gg/ISKMnJLTKcsCgUtgBtHxfVXxqg7s3znNwSVOSJb9EdIUtwqWE/2g/wCkfAoaXOK78+DVZJj+S9Z7euF2nGfx21GVee8Oh6YuhIdFCx9vDST/AGpJJAAJrjSlyc+VkZJkSnStR7D0SPYDWsSSbJsnXmq4xqSW7deQ0aNGtmA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA0aNGgA1txclkIv/AJeY+2PYLNftrU0aNbOptE01ufMt95CF/wD3tpP/AG1kO7cyTZdZ/wD1DUDo1ntX0a+SvslpG4ss8rqMkJPe0oAP71rRkzZckkyJLzt/3LJ1r6NdUpGXTflho0aNdOBo0aNABo0aNABo0aNABo0aNAH/2Q==" style={{height:52,width:52,borderRadius:"50%",objectFit:"cover"}} alt="AF Logo"/>
          <div className="hdr-title" style={{fontSize:26,fontWeight:700,letterSpacing:3,color:"#e2e8f0"}}>AF Build Calculator</div>
          </div>{/* end hdr-logo */}
          <button className="hdr-add-btn" onClick={()=>{if(countries.length>=5)return;setCountries([...countries,makeCountry(null)]);}}
            disabled={countries.length>=5}
            style={{background:countries.length>=5?"#1e293b":"#16a34a",color:countries.length>=5?"#475569":"#fff",padding:"8px 16px",fontSize:13,fontWeight:700,letterSpacing:1,textTransform:"uppercase",borderRadius:6,flexShrink:0}}>
            + Country ({countries.length}/5)
          </button>
        </div>{/* end hdr-row1 */}
        <div className="hdr-row2" style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
          <div className="hdr-savename" style={{fontSize:11,color:"#94a3b8",fontWeight:600}}>{currentSaveName}</div>
          <div style={{display:"flex",alignItems:"center",gap:6,fontSize:11,color:syncStatus==='synced'?"#22c55e":syncStatus==='saving'?"#f59e0b":syncStatus==='error'?"#ef4444":"#64748b"}}>
            <div style={{width:8,height:8,borderRadius:"50%",background:syncStatus==='synced'?"#22c55e":syncStatus==='saving'?"#f59e0b":syncStatus==='error'?"#ef4444":"#475569"}}/>
            Saved with the farm
          </div>
          {(presentUsers.length>0||currentSaveName)&&(
            <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
              <span style={{fontSize:10,color:"#60a5fa",fontWeight:700,letterSpacing:1,textTransform:"uppercase"}}>
                👥 {presentUsers.length+1} online:
              </span>
              {/* Own session */}
              <div style={{background:"#0d2a1a",border:"1px solid #14532d",borderRadius:6,padding:"3px 8px",fontSize:11,color:"#4ade80",display:"flex",alignItems:"center",gap:4}}>
                <span style={{width:6,height:6,borderRadius:"50%",background:"#22c55e",display:"inline-block"}}/>
                <span style={{fontWeight:700}}>You</span>
              </div>
              {presentUsers.map((u,i)=>{
                const tabIcons={"cities":"🏙","production":"⚔️","upgrades":"⬆️","research":"🔬","buildings":"🏗"};
                const tabIcon=u.tab?tabIcons[u.tab]||"📋":"";
                const displayName=u.userName||userNames[u.sessionId]||u.viewing||`User ${i+1}`;
                const dotColor=u.color||"#22c55e";
                return(
                  <div key={u.sessionId} className="hdr-userpill" style={{background:"#0d1f35",border:`1px solid ${dotColor}44`,borderRadius:6,padding:"3px 8px",fontSize:11,color:"#93c5fd",display:"flex",flexDirection:"column",gap:1,maxWidth:200}}>
                    <div style={{display:"flex",alignItems:"center",gap:4}}>
                      <span style={{width:6,height:6,borderRadius:"50%",background:dotColor,display:"inline-block",flexShrink:0}}/>
                      <span style={{fontWeight:700,color:dotColor,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                        {displayName}
                      </span>
                      {u.tab&&<span style={{color:"#64748b",fontSize:10}}>{tabIcon} {u.tab}</span>}
                    </div>
                    {u.lastAction&&<div className="hdr-lastaction" style={{fontSize:10,color:"#94a3b8",paddingLeft:10,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{u.lastAction}</div>}
                  </div>
                );
              })}
              <button onClick={()=>setShowTeamPanel(p=>!p)}
                style={{background:showTeamPanel?"#1e3a5f":"#0d1f35",border:"1px solid #1e3a5f",borderRadius:6,padding:"3px 8px",fontSize:11,color:"#60a5fa",fontWeight:700,cursor:"pointer"}}>
                ✏️ Names
              </button>
            </div>
          )}
        </div>{/* end hdr-row2 */}
      </div>{/* end app-header */}

      {/* Mobile nav */}
      <div className="mobile-nav">
        <button onClick={()=>setMobilePanel('calc')}
          style={{background:mobilePanel==='calc'?'#1e40af':'transparent',color:mobilePanel==='calc'?'#fff':'#64748b'}}>
          ⚔️ Calculator
        </button>
        <button onClick={()=>setMobilePanel('overview')}
          style={{background:mobilePanel==='overview'?'#1e40af':'transparent',color:mobilePanel==='overview'?'#fff':'#64748b'}}>
          📊 Overview
        </button>
      </div>

      <div className="app-layout">
        <div className="app-main" style={{display:mobilePanel==='calc'?'block':'none'}} id="panel-calc">
          <style>{`@media(min-width:769px){#panel-calc{display:block!important}}`}</style>
          {countries.length===0&&<div style={{textAlign:"center",color:"#475569",padding:60,fontSize:16}}>Add a country to get started</div>}
          {countries.map(c=><CountryCard key={c.id} country={c} morale={morale} onChange={updated=>updateCountry(c.id,updated)} onRemove={()=>removeCountry(c.id)}/>)}
        </div>

        <div className="app-sidebar" id="panel-overview" style={{display:mobilePanel==='overview'?'block':'none'}}>
          <style>{`@media(min-width:769px){#panel-overview{display:block!important}}`}</style>
          {/* Header */}
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16,paddingBottom:10,borderBottom:"1px solid #1e293b"}}>
            <div style={{fontSize:13,fontWeight:700,letterSpacing:2,color:"#64748b",textTransform:"uppercase"}}>📊 Overview</div>
            <div style={{display:"flex",gap:4}}>
              {[0,1,2,3].map(d=><button key={d} onClick={()=>setSidebarDay(d)}
                style={{padding:"3px 8px",fontSize:11,fontWeight:700,borderRadius:4,cursor:"pointer",
                  background:sidebarDay===d?dayColors[d]:"#1e293b",
                  color:sidebarDay===d?"#fff":dayColors[d],
                  border:`1px solid ${dayColors[d]}`}}>
                {d===0?"All":`D${d}`}
              </button>)}
            </div>
          </div>

          {/* Per country */}
          {countries.map(c=>{
            const filtItems=getFilteredItems(c);
            const cost=sumCosts(filtItems.map(i=>i.cost));
            const warbonds=(c.cities||[]).reduce((s,ci)=>s+(ci.warbond||0),0);
            const budget=c.name?(sidebarDay===0?calcDynamicBudget(c.name,c.capitals||[],warbonds):calcCumulativeBudget(c.name,c.capitals||[],warbonds,sidebarDay)):null;
            const cityIncTotal=calcCityIncome(c.cities||[], c.capitals||[], warbonds);
            const cityInc=sidebarDay===0?cityIncTotal:Object.fromEntries(Object.entries(cityIncTotal).map(([k,v])=>[k,Math.round(v/3*sidebarDay)]));
            const docColor=DOCTRINE_COLORS[c.doctrine];
            const hasAny=RES_KEYS.some(k=>(cost[k]||0)>0||(budget&&budget[k]||0)>0||(cityInc[k]||0)>0);
            return<div key={c.id} style={{background:"#0d1117",borderRadius:8,padding:12,marginBottom:10,borderLeft:`3px solid ${docColor}`}}>
              {/* Country name + doctrine */}
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
                <div style={{fontSize:13,fontWeight:700,color:"#e2e8f0"}}>{c.name||"— no country —"}</div>
                <div style={{fontSize:9,color:docColor,textTransform:"uppercase",letterSpacing:1,fontWeight:700,background:"#1e293b",padding:"2px 6px",borderRadius:3}}>{c.doctrine}</div>
              </div>
              {!hasAny&&<div style={{fontSize:11,color:"#334155",fontStyle:"italic"}}>No items added</div>}
              {/* Resource rows */}
              {hasAny&&<div style={{display:"grid",gridTemplateColumns:"auto 1fr 1fr 1fr",alignItems:"center",gap:"3px 8px"}}>
                {RES_KEYS.map(k=>{
                  const inc=((budget&&budget[k])||0)+(cityInc[k]||0);
                  const c2=cost[k]||0;
                  const netto=inc-c2;
                  if(inc===0&&c2===0)return null;
                  return([
                    <ResImg key={k+"i"} k={k} size={14}/>,
                    <span key={k+"inc"} style={{color:"#22c55e",fontFamily:"monospace",fontSize:15,textAlign:"right"}}>+{fmtC(inc)}</span>,
                    <span key={k+"cost"} style={{color:"#ef4444",fontFamily:"monospace",fontSize:15,textAlign:"right"}}>-{fmtC(c2)}</span>,
                    <span key={k+"net"} style={{color:netto>=0?"#facc15":"#ef4444",fontFamily:"monospace",fontWeight:700,fontSize:15,textAlign:"right"}}>{netto>=0?"+":""}{fmtC(netto)}</span>
                  ]);
                })}
              </div>}
            </div>;
          })}

          {/* Grand Total */}
          {countries.length>1&&<div style={{background:"#0f172a",borderRadius:8,padding:12,marginTop:4,border:"1px solid #334155"}}>
            <div style={{fontSize:11,fontWeight:700,color:"#94a3b8",marginBottom:10,textTransform:"uppercase",letterSpacing:2}}>⚖️ Grand Total</div>
            <div style={{display:"grid",gridTemplateColumns:"auto 1fr 1fr 1fr",alignItems:"center",gap:"4px 8px"}}>
              {RES_KEYS.filter(k=>k!=="manpower").map(k=>{
                const inc=grandIncome[k]||0;
                const cost=grandTotal[k]||0;
                const netto=inc-cost;
                if(inc===0&&cost===0)return null;
                return([
                  <ResImg key={k+"i"} k={k} size={16}/>,
                  <span key={k+"inc"} style={{color:"#22c55e",fontFamily:"monospace",fontSize:15,textAlign:"right"}}>+{fmtC(inc)}</span>,
                  <span key={k+"cost"} style={{color:"#ef4444",fontFamily:"monospace",fontSize:15,textAlign:"right"}}>-{fmtC(cost)}</span>,
                  <span key={k+"net"} style={{color:netto>=0?"#facc15":"#ef4444",fontFamily:"monospace",fontWeight:700,fontSize:17,textAlign:"right"}}>{netto>=0?"+":""}{fmtC(netto)}</span>
                ]);
              })}
            </div>
          </div>}
        </div>
      </div>
    </div>
  );
}
function afLoad(){ const l=window.AFBridge&&window.AFBridge.load(); if(!Array.isArray(l)||!l.length) return [makeCountry(null)]; let m=0; JSON.stringify(l,(k,v)=>{ if(k==='id'&&typeof v==='number'&&v>m) m=v; return v; }); if(nextId<=m) nextId=m+1; return l; }
window.AFCalcApp=App;
