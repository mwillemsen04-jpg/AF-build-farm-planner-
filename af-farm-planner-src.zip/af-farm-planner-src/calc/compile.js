const B=require('/tmp/claude-0/cdn/node_modules/@babel/standalone'); const fs=require('fs');
const out=B.transform(fs.readFileSync('calc_app.jsx','utf8'),{presets:[['react']]}).code; fs.writeFileSync('calc_app.js',out); console.log('ok',out.length);
